export const aliases={Consumer:'consumer',Consumer_Payee:'payee',CSP_Member:'member',History:'payment_history',Payee_Nickname:'payee_nickname',Recurring_Payment:'recurring_payments',Single_Payment:'single_payments'};
export function identify(name){
 if(/(^|_)ebills(_|\.)/i.test(name))return 'excluded';
 return Object.entries(aliases).sort((a,b)=>b[0].length-a[0].length).find(([token])=>new RegExp('(^|_)'+token+'(_|\\.)','i').test(name))?.[1]||'';
}
export function validDate(v){if(!/^\d{8}$/.test(v))return false;const d=new Date(`${v.slice(0,4)}-${v.slice(4,6)}-${v.slice(6,8)}T00:00:00Z`);return Number.isFinite(+d)&&d.toISOString().slice(0,10).replaceAll('-','')===v;}

/** Incremental aggregation. No raw records are retained. Memory scales with distinct keys. */
export function createAnalyzer(catalog,asOf,blankModels=false){
 if(!validDate(asOf))throw Error('Choose a valid analysis date.');
 const files=[],issues=[],seen=new Set(),consumerIds=new Set(),cspIds=new Set(),payees=new Set(),customers=new Map(),historyDates={};
 let issueCount=0,current=null;
 const metrics={customers:0,accounts:0,cspMembers:0,payees:0,uniqueRelationships:0,duplicateSurplus:0,nicknames:0,single:0,singleMinor:0n,pendingApproval:0,models:0,instances:0,instanceMinor:0n,future:0,today:0,history:0,historyMinor:0n,unmatchedRelationships:0};
 const key=r=>JSON.stringify([r['Sponsor Id']||r['Sponsor ID'],r['Sponsor Member ID']||r['Sponsor Member id']||r['Sponsor member id']]);
 const relation=r=>JSON.stringify([key(r),r['Payee Relationship Number']]);
 const ensure=r=>{const k=key(r);let c=customers.get(k);if(!c){c={key:k,id:r['Sponsor Member ID']||r['Sponsor Member id']||r['Sponsor member id'],sponsor:r['Sponsor Id']||r['Sponsor ID'],accounts:0,payees:0,single:0,models:0,instances:0,history:0,historyMinor:0n};customers.set(k,c);}return c;};
 const needed=new Set(['Member ID','Sponsor Id','Sponsor ID','Sponsor Member ID','Sponsor Member id','Sponsor member id','Payee Relationship Number','Payment Amount','Payment Schedule Date','Payment Date','Recurring / Single Payment Identifier','Payment Frequency','Payment Status','Primary Account Indicator','FI Account Type']);
 function begin(input){
  const id=identify(input.name)==='excluded'?'excluded':input.layout??identify(input.name);
  const f={name:input.name,layout:id,rows:0,rejected:0,state:id==='excluded'?'Ebills excluded':!id?'Unrecognized — skipped':'Parsed'};
  files.push(f);current=null;
  if(!id||id==='excluded')return false;
  if(seen.has(id))throw Error('More than one file is assigned to '+id+'. Select one delivery at a time.');
  const layout=catalog.layouts.find(l=>l.id===id);if(!layout)throw Error('Unknown file layout.');
  seen.add(id);current={id,f,width:layout.listed_field_length_total,fields:layout.fields.filter(f=>needed.has(f.name)),line:0};return true;
 }
 function line(text){
  if(!current)throw Error('No active file.');
  const {id,f,width,fields}=current;current.line++;
  const reject=message=>{f.rejected++;f.state='Partial — review required';issueCount++;if(issues.length<100)issues.push({file:f.name,line:current.line,message});};
  if(text.length!==width||/[^\x20-\x7e]/.test(text)){reject('Record width or encoding mismatch; row excluded.');return;}
  const r={};for(const field of fields)r[field.name]=text.slice(field.start-1,field.end).trim();
   const memberField=id==='consumer'?'Sponsor member id':id==='payee'?'Sponsor Member id':'Sponsor Member ID';
   if(id!=='payee_nickname'&&(!r[memberField]||!(r['Sponsor Id']||r['Sponsor ID']))){reject('Missing sponsor/member key; row excluded.');return;}
   if(['single_payments','recurring_payments','payment_history'].includes(id)){
    if(!/^\d+$/.test(r['Payment Amount'])||!r['Payee Relationship Number']){reject('Invalid amount or missing relationship; row excluded.');return;}
    const date=r['Payment Schedule Date']??r['Payment Date'];if(!validDate(date)){reject('Invalid process/schedule date; row excluded.');return;}
   }
   if(id==='recurring_payments'){
    const code=r['Recurring / Single Payment Identifier'];
    if(code!=='1'&&!(code===''&&blankModels)){reject('Unconfirmed recurring discriminator; row excluded. Confirm blank-as-model if applicable.');return;}
    if((code==='1'&&r['Payment Frequency']!=='')||(code===''&&!/^[0-8]$/.test(r['Payment Frequency']))){reject('Recurring frequency contradicts record classification; row excluded.');return;}
   }
   if(id==='single_payments'&&!['1','50'].includes(r['Payment Status'])){reject('Unknown single-payment status; row excluded.');return;}
   if(id==='consumer'&&(!r['Member ID']||!['Y','N'].includes(r['Primary Account Indicator'])||!['DDA','SV'].includes(r['FI Account Type']))){reject('Missing Member ID or unknown funding-account code; row excluded.');return;}

  f.rows++;
  if(id==='consumer'){metrics.accounts++;consumerIds.add(JSON.stringify([r['Sponsor Id'],r['Member ID']]));ensure(r).accounts++;}
  if(id==='member'){cspIds.add(key(r));}
  if(id==='payee'){metrics.payees++;payees.add(relation(r));ensure(r).payees++;}
  if(id==='payee_nickname')metrics.nicknames++;
  if(id==='single_payments'){metrics.single++;metrics.singleMinor+=BigInt(r['Payment Amount']);metrics.pendingApproval+=Number(r['Payment Status']==='50');ensure(r).single++;}
  if(id==='recurring_payments'){
   if(r['Recurring / Single Payment Identifier']===''){metrics.models++;ensure(r).models++;}
   else{metrics.instances++;metrics.instanceMinor+=BigInt(r['Payment Amount']);ensure(r).instances++;}
  }
  if(id==='payment_history'){metrics.history++;const c=ensure(r),amount=BigInt(r['Payment Amount']);metrics.historyMinor+=amount;c.history++;c.historyMinor+=amount;historyDates[r['Payment Date']]=(historyDates[r['Payment Date']]||0)+1;}
  const scheduled=id==='single_payments'||(id==='recurring_payments'&&r['Recurring / Single Payment Identifier']==='1');
  if(scheduled){metrics.future+=Number(r['Payment Schedule Date']>asOf);metrics.today+=Number(r['Payment Schedule Date']===asOf);}
  if((scheduled||id==='payment_history')&&!payees.has(relation(r)))metrics.unmatchedRelationships++;
 }
 function finish(){
  metrics.customers=consumerIds.size;metrics.cspMembers=cspIds.size;metrics.uniqueRelationships=payees.size;metrics.duplicateSurplus=metrics.payees-payees.size;
  const resultMetrics={...metrics,singleMinor:String(metrics.singleMinor),instanceMinor:String(metrics.instanceMinor),historyMinor:String(metrics.historyMinor),unmatchedRelationships:seen.has('payee')?metrics.unmatchedRelationships:null};
  const customerRows=[];for(const c of customers.values()){c.historyMinor=String(c.historyMinor);customerRows.push(c);}
  consumerIds.clear();cspIds.clear();payees.clear();customers.clear();
  return {asOf,blankModels,metrics:resultMetrics,files,issues,issueCount,customers:customerRows,historyDates,missing:catalog.layouts.filter(l=>!seen.has(l.id)).map(l=>l.title),partial:issueCount>0||seen.size<catalog.layouts.length};
 }
 return {begin,line,finish,get records(){return files.reduce((n,f)=>n+f.rows+f.rejected,0);}};
}
export function orderInputs(inputs){
 // Load the payee key index before payment rows; retain no payment records for joins.
 return [...inputs].sort((a,b)=>Number((b.layout??identify(b.name))==='payee')-Number((a.layout??identify(a.name))==='payee'));
}
export function analyze(inputs,catalog,asOf,blankModels=false){
 const engine=createAnalyzer(catalog,asOf,blankModels);
 for(const input of orderInputs(inputs)){
  if(!engine.begin(input))continue;
  const lines=input.text.split(/\r?\n/);if(lines.at(-1)==='')lines.pop();for(const line of lines)engine.line(line);
 }
 return engine.finish();
}
