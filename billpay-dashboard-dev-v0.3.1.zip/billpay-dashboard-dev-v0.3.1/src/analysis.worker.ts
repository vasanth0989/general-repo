import {analyzeFiles} from './core/stream.mjs';
import catalog from './layouts.json';
let result:any=null;
self.onmessage=async({data})=>{try{
 if(data.type==='page'){
  if(!result)return;
  const query=String(data.query||''),page=Math.max(0,Math.floor(Number(data.page)||0)),rows=[];let total=0;
  for(const c of result.customers){if(!c.id.includes(query))continue;if(total>=page*500&&rows.length<500)rows.push(c);total++;}
  self.postMessage({type:'page',rows,total,page,requestId:data.requestId});return;
 }
 if(data.type==='export'){
  if(!result)return;
  const blob=new Blob([JSON.stringify({version:'0.3.1',note:'Provisional layouts and joins; history is not settlement evidence; amounts have two implied decimals, currency unspecified.',...result})],{type:'application/json'});
  self.postMessage({type:'export',blob});return;
 }
 result=null;
 result=await analyzeFiles(data.files,catalog,data.asOf,data.blankModels,progress=>self.postMessage({type:'progress',...progress}));
 self.postMessage({type:'complete',result:{...result,customerCount:result.customers.length,customers:result.customers.slice(0,500)}});
}catch(e){self.postMessage({type:'error',message:e instanceof Error?e.message:'Analysis failed.'});}};
