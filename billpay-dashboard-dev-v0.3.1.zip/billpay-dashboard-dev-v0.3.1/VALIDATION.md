# Validation scope
Clean `npm ci --ignore-scripts` succeeded in this independent package directory. `npm run check` passed all 15 packaged tests and compiled the application with TypeScript and Vite 8.3.1. The install audit reported zero vulnerabilities. Version 0.3.1 packages the existing streaming behavior for development; it does not introduce new business rules.


This development package uses the streaming implementation validated with 700,000 fabricated records across seven files (297.74 MiB and 100,000 distinct customers). That release took 2.4 seconds in a Windows browser on an Intel i9-13900KS; it is not a Mac timing guarantee. Exact counts, amounts, joins, paging, search and full report export were verified. Sample inputs remain outside this package.

This archive's standalone tests cover line framing, encoding observations, bounded carry on an 80 MiB malformed line, cancellation stopping reads, duplicate delivery refusal before reads, skipped-file non-reading and loopback-server restrictions. They require no external fixture directory. The broader fixture-dependent tests and benchmark are intentionally excluded rather than shipped with broken external paths.

Development dependencies are pinned; Vite is 8.3.1. The clean install is tested with lifecycle scripts disabled via .npmrc. Enterprise Artifactory availability and macOS installation remain environment-specific and cannot be verified on this Windows host.
