# Billpay dashboard — development package 0.3.1

Editable React/TypeScript source, streaming analysis worker, source layout catalog, Node server, build configuration, dependency lockfile, standalone tests and a prebuilt app. No sample datasets, demo customer records, benchmark files, secrets, or node_modules are included.

## First setup on your Mac

Extract into a new folder. Keep your existing installation as a backup. Open Terminal in this folder. Requires Node 22.12 or newer; use your enterprise-approved Node/npm installation.

To run the included build immediately, no dependency installation is required:

```sh
npm start
```

Open http://127.0.0.1:4173. Stop with Ctrl+C before switching servers.

To install development dependencies, first check that npm uses your approved Artifactory registry:

```sh
npm config get registry
npm ci
npm run dev
```

If the registry is not your approved one, apply your organization's npm setup before installing. This package does not supply credentials or override your registry. The lockfile uses public npm registry URLs, which npm normally substitutes with the configured registry; an enterprise registry policy or unavailable pinned package may still require your npm administrator's help. Do not bypass Artifactory or use force/legacy-peer-deps to hide a resolution error.

Open http://127.0.0.1:5173 for development. Save edits under src/ and the browser updates automatically. Vite is pinned to 8.3.1, matching the previously observed available version. The reference npm version is recorded in package.json; no global installation is needed just to run the application. The project .npmrc disables dependency lifecycle scripts. Clean installation and build are verified under that setting on Windows.

## Build and test

```sh
npm test
npm run build
npm start
```

Or run `npm run check` to test and build together. `npm start` serves the files in dist/; it does not rebuild source changes. `npm run dev` serves the editable source instead. Neither the run-only server nor development mode sends chosen records to an external service; parsing runs in a local browser worker. Keep input files outside this project's public/, dist/ and source folders, especially during development: public/ and dist/ are web-served content.

## Updating an existing development folder

Stop the running server and back up or commit your local edits before applying updated source. Preserve your enterprise npm settings and credentials. Prefer comparing/merging new source over deleting the entire project. Never copy Windows node_modules to a Mac.

- When only application source changes and package.json/package-lock.json are unchanged, you can keep the existing Mac node_modules and run `npm run dev` or rebuild.
- When dependency files change, run `npm ci` against the approved registry. It intentionally replaces node_modules with the exact locked dependencies.
- The safest first transition from the older prototype/run-only ZIP is this separate folder; install dependencies here for development.

## Project map

- src/AnalysisApp.tsx: interface, file selection, progress, customer pages and report download.
- src/analysis.worker.ts: background run, paging and report generation.
- src/core/analysis.mjs: validation, classifications, joins, counts and exact minor-unit aggregation.
- src/core/stream.mjs: 1 MiB file reads and bounded line framing.
- src/layouts.json: seven supplied layouts, evidence status and derived-versus-printed offsets.
- src/styles.css and src/Icon.tsx: visual styling and icons.
- server/index.mjs: loopback-only static server for the compiled app.
- tests/: standalone parser/stream framing and server checks. No dataset files needed.

The packaged tests use small in-memory utility values and malformed bytes; they do not create sample deconversion datasets. The larger seven-file reconciliation and 700,000-record benchmark remain only in the Windows development workspace and are excluded from this archive.

## Analysis scope

Seven file types; Ebills excluded. File-size caps removed. One delivery at a time and one file per layout, up to 300 selected files. Incremental totals and payee-key index; only aggregate customer data and distinct keys remain in memory. Customer pages contain 500 rows. Memory still grows with unique customers/relationships and report export; this is not an unlimited-memory engine.

Provisional ASCII contiguous fixed-width profile, spaces for padding, LF/CRLF lines, no automatic header/trailer stripping. Approval/current applicability of the source layout revision remains unknown. Except Nickname, positions are derived from field lengths. Alias and customer-join assumptions are labeled. Blank recurring identifiers require explicitly selecting the provisional blank-as-model convention. Missing files and invalid rows produce partial results. Nickname cross-file identifier semantics are not guessed. Monetary totals use integer minor units; currency is unspecified. Models are excluded from payment instances. History does not establish success, ACH transmission or settlement; scheduled dates do not establish payment ownership or cutover rules.

Raw inputs stay unchanged and are not uploaded. Results stay in browser memory until refresh; optional exports contain customer identifiers. No database, persistent browser storage or telemetry is configured.
