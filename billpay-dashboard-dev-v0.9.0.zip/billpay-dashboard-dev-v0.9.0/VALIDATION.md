# Validation — 0.9.0

2026-10-05, Windows. All 44 tests pass. TypeScript/Vite build passes; npm lockfile audit reports zero vulnerabilities.

New tests cover exact 2/3/4 and 5+ segmentation, two separate pairs counting as four, repeated-row exclusion, CIF search composition, empty intersections, counts before segmentation, account-filter composition and paging over 205 customers. Existing sponsor-padding, leading-zero and reconciliation tests still pass.

Browser verified segment + CIF search, clicking the duplicate-count column, six scoped duplicate payees and return navigation restoring the segment/search. Test data is synthetic and excluded from the ZIP. No production files used.
