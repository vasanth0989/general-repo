import { inspectBytes, validateSelection } from './core/inventory.mjs';
import catalog from './layouts.json';
self.onmessage = async (event: MessageEvent<{files: File[]; mappings: string[]}>) => {
  try {
    const {files,mappings}=event.data; validateSelection(files);
    if(!Array.isArray(mappings)||mappings.length!==files.length) throw new Error('File mappings are incomplete.');
    const total=files.reduce((n,f)=>n+f.size,0); let done=0; const results=[];
    for(let i=0;i<files.length;i++) {
      const file=files[i],layout=catalog.layouts.find(l=>l.id===mappings[i]);
      if(!layout) {
        results.push({name:file.webkitRelativePath||file.name,size:file.size,layout:null,state:'skipped',stats:null});
        done+=file.size;
        self.postMessage({type:'progress',percent:total?done/total*100:100,name:file.name}); continue;
      }
      let lastProgress=0;
      const stats=await inspectBytes(file.stream(),layout.listed_field_length_total,(read:number)=>{
        if(performance.now()-lastProgress>100) {
          self.postMessage({type:'progress',percent:total?(done+read)/total*100:100,name:file.name});lastProgress=performance.now();
        }
      });
      const review=!stats.lines||stats.mismatched>0||stats.nonAscii>0||stats.suspiciousControl>0;
      results.push({name:file.webkitRelativePath||file.name,size:file.size,layout:layout.id,state:review?'review':'width-match',stats});
      done+=file.size;
    }
    self.postMessage({type:'complete',results});
  } catch(e) {self.postMessage({type:'error',message:e instanceof Error?e.message:'Unable to inspect selected files.'});}
};
