export type Customer = {id:string; name:string; initials:string; payees:number; scheduled:number; models:number; history:number; amount:string; review:boolean; email:string};
const first=['Olivia','James','Amelia','Noah','Charlotte','Elijah','Sophia','William','Isabella','Lucas','Mia','Benjamin','Harper','Henry','Evelyn','Alexander','Avery','Daniel','Ella','Michael'];
const last=['Bennett','Morgan','Parker','Reed','Brooks','Hayes','Collins','Foster','Bailey','Rivera','Sullivan','Gray'];
export const customers:Customer[]=Array.from({length:240},(_,i)=>({
 id:String(10342+i).padStart(10,'0'),name:first[i%20]+' '+last[Math.floor(i/20)%12],
 initials:first[i%20][0]+last[Math.floor(i/20)%12][0],
 payees:3+i%9,scheduled:2+i%11,models:1+i%4,history:64+(i*7)%200,
 amount:String((64+(i*7)%200)*18425+i*137),review:i%19===0,email:'customer-'+(i+1)+'@example.test'
}));
export const totals=customers.reduce((a,c)=>({customers:a.customers+1,payees:a.payees+c.payees,scheduled:a.scheduled+c.scheduled,models:a.models+c.models,history:a.history+c.history,amount:a.amount+BigInt(c.amount),review:a.review+Number(c.review)}),{customers:0,payees:0,scheduled:0,models:0,history:0,amount:0n,review:0});
export const num=(n:number)=>n.toLocaleString('en-US');
export const money=(value:string|bigint)=>{const n=BigInt(value);return '$'+(n/100n).toLocaleString('en-US')+'.'+String(n%100n).padStart(2,'0');};
export const bytes=(n:number)=>n<1024?n+' B':n<1024**2?(n/1024).toFixed(1)+' KB':n<1024**3?(n/1024**2).toFixed(1)+' MB':(n/1024**3).toFixed(2)+' GB';
export const demoFiles=[
 {name:'sample_members.txt',label:'Member',records:totals.customers,width:412},
 {name:'sample_payees.txt',label:'Payee',records:totals.payees,width:378},
 {name:'sample_single_payments.txt',label:'Single payments',records:totals.scheduled,width:572},
 {name:'sample_recurring.txt',label:'Recurring models',records:totals.models,width:586},
 {name:'sample_nicknames.txt',label:'Payee nickname',records:totals.payees,width:258},
 {name:'sample_history.txt',label:'Payment history',records:totals.history,width:489}
];
export const payeeNames=['Evergreen Energy','Northstar Telecom','Cedar Home Services','Summit Insurance','Atlas Water','Oakwood Credit Union','City Utilities','Meridian Wireless'];
export type Stats={bytes:number;lines:number;matched:number;mismatched:number;empty:number;nonAscii:number;suspiciousControl:number;minWidth:number;maxWidth:number;lf:number;crlf:number;examples:{line:number;byteWidth:number}[]};
export type ScanFile={name:string;size:number;layout:string|null;state:'skipped'|'review'|'width-match';stats:Stats|null};
export type Run={id:string;name:string;date:string;files:ScanFile[]};

