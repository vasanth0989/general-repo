# Billpay dashboard prototype

A local React and TypeScript dashboard for exploring the deconversion-analysis experience.

## Fastest start on Windows or macOS

The distribution includes a prebuilt interface. Only Node.js 22.12 or newer is required to run it. No npm package download is needed for this first launch.

1. Extract the ZIP and open Terminal (Mac) or PowerShell (Windows).
2. Change directory into the extracted billpay-dashboard folder.
3. Run:

```sh
npm start
```

4. Open **http://127.0.0.1:4173** in Chrome.
5. Stop the server with **Ctrl+C**.

The same source and startup command work on both platforms. This release was built and tested on Windows; macOS execution remains to be checked on your Mac. If port 4173 is occupied, stop the other app or set PORT to an available port.

## What works

- Eight navigation views: overview, customers, payees, payments, data quality, source files, run history, and layout guide.
- Synthetic demo with 240 searchable customers, pagination, customer dialogs, exact integer-minor-unit amounts, charts, review filters, and JSON export.
- Folder selection with explicit per-file layout assignment.
- Actual streamed structural checks in a browser worker: line counts, byte widths, width differences, blank lines, non-ASCII bytes, CRLF/LF observations, and progress/cancellation.
- Session-only scan history and structural JSON report download.
- Full source layout reference with printed versus derived positions distinguished.

## Try a real structural scan safely

Click **New analysis** and choose the included **sample-files** directory. Assign sample_members.txt and sample_members_review.txt to Member File. Assign sample_history.txt to Payment History File. Leave sample_notes.txt unassigned. Click Perform analysis.

These fixtures contain synthetic padding only; they are not business-valid migration records. Expected: 4 selected files, 3 inspected files, 7 lines, 5 candidate-width matches, 1 file to review, 1 skipped file. The notes file is not read. Zero customer or payment facts are inferred.

## Scope of this skeleton

The demo is fictional and clearly labeled. The charts include illustrative series, not reconstructions of the sample customer history. A width match does not prove valid fields, correct encoding, approved record lengths, or migration readiness.

Real customer parsing, joins, duplicate detection, scheduling rules, reconciliation, database persistence, and server-side ingestion are future modules. This phase deliberately uses a browser worker and no SQLite database or upload API. The Node service serves the interface and /api/health only.

The copied layouts come from seven supplied document images. Revision February 17, 2010 is visible on page 4; approval is unknown. Nickname offsets are printed. Other offsets and totals are derived. Byte-width comparisons assume single-byte fields only as a structural experiment. Unknown null conventions, headers/trailers, and encoding must be resolved before parsing business records.

## Develop or rebuild

Use your existing enterprise npm registry configuration; no registry override is included.

```sh
npm ci
npm run build
npm test
npm start
```

For hot reload while editing: **npm run dev**, then open **http://127.0.0.1:5173**.

Dependencies are pinned in package.json and package-lock.json. Install separately per operating system; do not copy node_modules. The checked-in .npmrc disables dependency install scripts. The Windows build succeeded with that policy. Package metadata availability on Artifactory is known; a clean install and native build-package availability on your Mac remain unverified. The prebuilt launch avoids this requirement.

## Project map

- src/App.tsx: interface and session orchestration.
- src/styles.css: responsive visual system.
- src/data.ts: synthetic fixtures and exact amount formatting.
- src/layouts.json: copied source evidence catalog.
- src/scan.worker.ts: cancellable background file scanner.
- src/core/inventory.mjs: bounded-memory structural analysis.
- server/index.mjs: loopback static server and health endpoint.
- tests/: scanner and server boundary tests.
- sample-files/: synthetic width-check fixtures.
- dist/: prebuilt runnable interface.

## Data handling and limits

Files remain in the browser; no input contents are uploaded or stored. Source files are never changed. Session results are cleared on refresh. JSON reports are saved only when Export report is clicked and may contain filenames. Demo exports contain fictional customer names only. The source directory is never served over HTTP.

Limits: 300 files, 2 GiB per file, 10 GiB per selection; these are guardrails, not tested performance guarantees. Non-LF newline conventions and non-ASCII encodings need explicit review. Only the first five width mismatches per file are retained.

The server binds to 127.0.0.1, validates Host, rejects writes, restricts assets to dist, and sends CSP/frame/referrer/content-type protections. No external fonts, telemetry, CDNs, or runtime API services. CSP permits inline styling for generated chart styles. Existing enterprise browser policies still apply.

## Validation

See VALIDATION.md for the release checks and platform limitations.

