# Prototype validation

Validated on Windows, 2026-10-02, Node 26.5.0 and npm 11.17.0.

- Production TypeScript check and Vite build passed.
- 11 automated tests passed: chunk-split CRLF, LF and unterminated lines, empty input, blank lines, width mismatches, UTF-8/control-byte detection, bare CR, bounded exception samples, progress, selection caps, and server boundaries.
- Server checks cover health, compiled asset serving, security headers, rejected write requests, source-file exclusion, traversal rejection, and foreign Host rejection.
- npm audit: zero known vulnerabilities at check time. This is not a guarantee against all supply-chain risks.
- Browser: dashboard loaded; customer search returned 12 Olivia records; customer detail displayed the preserved 10-character member ID and exact amount.
- Browser folder workflow: four synthetic files selected, three explicitly assigned layouts, one skipped; produced seven inspected lines, five candidate-width matches, and one file needing review.
- Browser console: no errors or warnings observed during those checks.

The production server was launched with no runtime npm dependencies. No dependency install scripts were enabled.

Not yet verified: macOS execution, enterprise Island/Safari policy behavior, multi-gigabyte performance, real deconversion parsing, and production approval of source layouts. The browser worker is the prototype scanning layer; Node ingestion and SQLite remain future work.
