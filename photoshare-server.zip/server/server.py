#!/usr/bin/env python3
"""PhotoShare receiver.

Implements the HTTP contract from SPEC.md section 4:
  GET  /health  -> {"ok": true, "name": <hostname>, "folder": <destination>}
  POST /upload  -> raw JPEG body, X-Filename / X-Device / X-Session headers,
                   201 {"saved": <path>, "bytes": <n>}

Also advertises itself over Bonjour as _photoshare._tcp so the phone can find it.
Standard library only, except `zeroconf` (discovery) and the optional
`pillow-heif` fallback converter for non-JPEG uploads.
"""

from __future__ import annotations

import json
import logging
import os
import re
import socket
import sys
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from logging.handlers import RotatingFileHandler
from pathlib import Path

HERE = Path(__file__).resolve().parent
SERVICE_TYPE = "_photoshare._tcp.local."

DEFAULT_CONFIG = {
    "port": 8787,
    "destination_folder": str(Path.home() / "PhotoShare" / "inbox"),
    "keep_originals": True,
}

log = logging.getLogger("photoshare")


# --------------------------------------------------------------------------- config


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    path = HERE / "config.json"
    if path.exists():
        with path.open("r", encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    cfg["destination_folder"] = str(Path(cfg["destination_folder"]).expanduser())
    return cfg


def setup_logging() -> None:
    logs = HERE / "logs"
    logs.mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    file_handler = RotatingFileHandler(logs / "server.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(fmt)
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(fmt)
    log.setLevel(logging.INFO)
    log.addHandler(file_handler)
    log.addHandler(stream)


# --------------------------------------------------------------------------- files

_SAFE = re.compile(r"[^A-Za-z0-9._ -]+")


def sanitize(name: str | None, fallback: str) -> str:
    """Strip path separators and odd characters from a client-supplied name."""
    if not name:
        return fallback
    name = os.path.basename(name.replace("\\", "/")).strip()
    name = _SAFE.sub("_", name).strip(". ")
    return name or fallback


def unique_path(folder: Path, name: str) -> Path:
    """Never overwrite: foo.jpg -> foo-1.jpg -> foo-2.jpg ..."""
    stem, ext = os.path.splitext(name)
    candidate = folder / name
    n = 1
    while candidate.exists():
        candidate = folder / f"{stem}-{n}{ext}"
        n += 1
    return candidate


def write_atomic(target: Path, data: bytes) -> Path:
    """Write to a temp name in the same folder, then rename into place."""
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(f".{target.name}.part")
    with tmp.open("wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    # Re-check uniqueness right before the rename; another upload may have landed.
    final = unique_path(target.parent, target.name)
    os.replace(tmp, final)
    return final


def sniff(data: bytes) -> str:
    if data[:3] == b"\xff\xd8\xff":
        return "jpeg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if len(data) > 12 and data[4:8] == b"ftyp":
        brand = data[8:12]
        if brand in (b"heic", b"heix", b"hevc", b"hevx", b"mif1", b"msf1", b"heif"):
            return "heif"
    return "unknown"


def convert_to_jpeg(data: bytes) -> bytes:
    """Fallback for non-JPEG uploads. Quality 95, as the old script did."""
    import io

    from PIL import Image  # pillow is pulled in by pillow-heif

    try:
        import pillow_heif

        pillow_heif.register_heif_opener()
    except ImportError:
        pass
    img = Image.open(io.BytesIO(data))
    exif = img.info.get("exif")
    if img.mode not in ("RGB", "L"):
        img = img.convert("RGB")
    out = io.BytesIO()
    kwargs = {"quality": 95, "subsampling": 0}
    if exif:
        kwargs["exif"] = exif
    img.save(out, format="JPEG", **kwargs)
    return out.getvalue()


# --------------------------------------------------------------------------- http


class Handler(BaseHTTPRequestHandler):
    server_version = "PhotoShare/1.0"
    protocol_version = "HTTP/1.1"
    config: dict = {}

    # Quiet the default per-request stderr logging; we log uploads ourselves.
    def log_message(self, fmt, *args):  # noqa: D401
        pass

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    _seen_clients: set = set()

    def do_GET(self):
        if self.path.split("?")[0] == "/health":
            client = self.client_address[0]
            if client not in Handler._seen_clients:
                Handler._seen_clients.add(client)
                log.info("health check from new client %s (%s)", client, self.headers.get("User-Agent", "?"))
            self._json(200, {"ok": True, "name": socket.gethostname(), "folder": self.config["destination_folder"]})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        if self.path.split("?")[0] != "/upload":
            self._json(404, {"error": "not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0:
            self._json(411, {"error": "Content-Length required"})
            return

        started = time.monotonic()
        data = self.rfile.read(length)
        if len(data) != length:
            self._json(400, {"error": f"short body: got {len(data)} of {length} bytes"})
            return

        device = self.headers.get("X-Device", "unknown")
        session = sanitize(self.headers.get("X-Session"), "")
        default_name = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3] + ".jpg"
        filename = sanitize(self.headers.get("X-Filename"), default_name)

        dest = Path(self.config["destination_folder"])
        if session:
            dest = dest / session

        kind = sniff(data)
        try:
            if kind == "jpeg":
                if not filename.lower().endswith((".jpg", ".jpeg")):
                    filename = os.path.splitext(filename)[0] + ".jpg"
                saved = write_atomic(unique_path(dest, filename), data)
            elif kind in ("heif", "png"):
                if self.config.get("keep_originals", True):
                    ext = ".heic" if kind == "heif" else ".png"
                    orig_name = os.path.splitext(filename)[0] + ext
                    write_atomic(unique_path(dest / "originals", orig_name), data)
                jpeg = convert_to_jpeg(data)
                filename = os.path.splitext(filename)[0] + ".jpg"
                saved = write_atomic(unique_path(dest, filename), jpeg)
            else:
                self._json(415, {"error": "unsupported image type (expected JPEG)"})
                log.warning("rejected %s from %s: unknown type, %d bytes", filename, device, len(data))
                return
        except ImportError as exc:
            self._json(500, {"error": f"conversion unavailable: {exc}"})
            log.error("cannot convert %s from %s: %s", filename, device, exc)
            return
        except Exception as exc:  # noqa: BLE001
            self._json(500, {"error": str(exc)})
            log.exception("failed saving %s from %s", filename, device)
            return

        size = saved.stat().st_size
        ms = int((time.monotonic() - started) * 1000)
        log.info("saved %s  %d bytes  from %s  type=%s  %dms", saved, size, device, kind, ms)
        self._json(201, {"saved": str(saved), "bytes": size})


# --------------------------------------------------------------------------- bonjour


def local_ipv4() -> str:
    """Best-effort primary LAN address. Falls back to hostname resolution."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # no packets are sent
        return s.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"
    finally:
        s.close()


def advertise(port: int, folder: str):
    try:
        from zeroconf import ServiceInfo, Zeroconf
    except ImportError:
        log.warning("zeroconf not installed; phone must use the manual host:port setting")
        return None

    host = socket.gethostname().split(".")[0]
    instance = re.sub(r"[^A-Za-z0-9 _-]", "", host) or "PhotoShare"
    ip = local_ipv4()
    info = ServiceInfo(
        SERVICE_TYPE,
        f"{instance}.{SERVICE_TYPE}",
        addresses=[socket.inet_aton(ip)],
        port=port,
        # ip/port in TXT lets the phone skip mDNS name resolution entirely.
        properties={"ip": ip, "port": str(port), "folder": folder},
        server=f"{instance}.local.",
    )
    zc = Zeroconf()
    zc.register_service(info)
    log.info("bonjour: advertising %s at %s:%d", instance, ip, port)
    return zc, info


# --------------------------------------------------------------------------- main


def main() -> int:
    setup_logging()
    cfg = load_config()
    Path(cfg["destination_folder"]).mkdir(parents=True, exist_ok=True)
    Handler.config = cfg

    httpd = ThreadingHTTPServer(("0.0.0.0", cfg["port"]), Handler)
    httpd.daemon_threads = True
    log.info("listening on http://0.0.0.0:%d  ->  %s", cfg["port"], cfg["destination_folder"])

    zc = advertise(cfg["port"], cfg["destination_folder"])
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        if zc:
            zc[0].unregister_service(zc[1])
            zc[0].close()
        httpd.server_close()
        log.info("stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
