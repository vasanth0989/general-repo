# PhotoShare receiver installer for Windows.
# Run from an elevated PowerShell:  powershell -ExecutionPolicy Bypass -File install.ps1
#
# 1. Installs Python dependencies.
# 2. Opens the firewall for the server port (TCP) and Bonjour (UDP 5353) on the Private profile only.
# 3. Registers a Scheduled Task that starts the server at logon.

$ErrorActionPreference = "Stop"
$here   = Split-Path -Parent $MyInvocation.MyCommand.Path
$config = Get-Content (Join-Path $here "config.json") | ConvertFrom-Json
$port   = [int]$config.port
# Prefer the py launcher: it points at the real python.org install, not the Microsoft Store stub.
$python = $null
if (Get-Command py.exe -ErrorAction SilentlyContinue) {
    $python = (& py -3 -c "import sys; print(sys.executable)").Trim()
}
if (-not $python) { $python = (Get-Command python.exe -ErrorAction SilentlyContinue).Source }
if (-not $python -or $python -like "*WindowsApps*") {
    Write-Error "Install Python 3 from https://www.python.org/downloads/windows/ (tick 'Add python.exe to PATH'), then re-run."
    exit 1
}

Write-Host "Using Python: $python"
& $python -m pip install --upgrade -r (Join-Path $here "requirements.txt")

$taskName = "PhotoShare Receiver"
$pythonw  = Join-Path (Split-Path $python) "pythonw.exe"
if (-not (Test-Path $pythonw)) { $pythonw = $python }

# Firewall: TCP for uploads, UDP 5353 so the zeroconf responder in python can answer mDNS queries.
# Rules for both interpreters: python.exe when you run it by hand, pythonw.exe for the hidden task.
foreach ($exe in @($python, $pythonw) | Select-Object -Unique) {
    $tag = [IO.Path]::GetFileNameWithoutExtension($exe)
    foreach ($rule in @(
        @{ Name = "PhotoShare HTTP $port ($tag)"; Protocol = "TCP"; Port = $port },
        @{ Name = "PhotoShare mDNS ($tag)";       Protocol = "UDP"; Port = 5353 }
    )) {
        if (Get-NetFirewallRule -DisplayName $rule.Name -ErrorAction SilentlyContinue) {
            Remove-NetFirewallRule -DisplayName $rule.Name
        }
        New-NetFirewallRule -DisplayName $rule.Name -Direction Inbound -Action Allow `
            -Protocol $rule.Protocol -LocalPort $rule.Port -Profile Private,Domain `
            -Program $exe | Out-Null
        Write-Host "Firewall rule added: $($rule.Name)"
    }
}

# Scheduled task at logon, runs hidden via pythonw.
$action   = New-ScheduledTaskAction -Execute $pythonw -Argument "`"$(Join-Path $here 'server.py')`"" -WorkingDirectory $here
$trigger  = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
}
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings `
    -RunLevel Limited -Description "Receives photos from the PhotoShare iPhone app" | Out-Null
Start-ScheduledTask -TaskName $taskName
Write-Host "Scheduled task '$taskName' registered and started."
Write-Host "Smoke test:  curl http://localhost:$port/health"
