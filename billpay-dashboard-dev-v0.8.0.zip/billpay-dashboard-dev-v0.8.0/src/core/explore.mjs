import {identifyCustomer} from './customer-identity.mjs';
import {identify,fundingMatch} from './analysis.mjs';
import {prepareLayout,parseRecord,customerKey,payeeKey} from './record.mjs';
import {lineFramer,CHUNK_BYTES} from './stream.mjs';
export function publicResult(result){const {_identity,_accountNumbers,_customers,_payees,_funding,_rules,...rest}=result;return rest;}
export function summary(result){const {customers,unlinkedCustomers,payees,accounts,...rest}=publicResult(result);return {...rest,customerCount:customers.length,payeeCount:payees.length,accountCount:accounts.length};}
export function pageEntities(result,request){
 const query=String(request.query||'').toLowerCase(),rows=[],page=Math.max(0,Number(request.page)||0),size=100;
 const source=request.entity==='Customers'?(request.filter==='unlinked'?result.unlinkedCustomers:result.customers):request.entity==='Payees'?result.payees:result.accounts;let total=0,index=-1;const accountTypes=new Map();
 for(const row of source){
  index++;
  if(request.customerKey&&(row.customerKey||row.key)!==request.customerKey)continue;
  if(request.payeeKey&&row.key!==request.payeeKey)continue;
  if(request.entity==='Funding accounts'){accountTypes.set(row.type,(accountTypes.get(row.type)||0)+1);if(request.accountType!==undefined&&row.type!==request.accountType)continue;const numberQuery=String(request.accountQuery||'').trim();if(numberQuery&&!result._accountNumbers[index].includes(numberQuery))continue;}
  if(request.filter==='duplicates'&&!(row.rows>1||row.possibleDuplicate))continue;if(request.filter==='multiple'&&!(row.accounts>1))continue;
  if(query&&![...(row.cifs||[]),...(row.memberIds||[]),row.name,row.customer,row.id,row.member,row.memberId,row.reference,row.relationship,row.nickname,row.account].some(v=>String(v||'').toLowerCase().includes(query)))continue;
  if(total>=page*size&&rows.length<size)rows.push(row);total++;
 }
 return {rows,total,page,size,accountTypes:[...accountTypes].map(([code,count])=>({code,count})).sort((a,b)=>b.count-a.count||a.code.localeCompare(b.code)),customer:result._customers.get(request.customerKey)||null,payee:result._payees.get(request.payeeKey)||null};
}
export function paymentView(r,kind,source,result){
 identifyCustomer(r,result._identity);
 const p=result._payees.get(payeeKey(r)),funding=fundingMatch(r,result._funding);
 const models=r['FIS Recurring Rule DB']&&r['FI Account Number']?result._rules.get(JSON.stringify([payeeKey(r),r['FI Account Number'],r['FIS Recurring Rule DB']])):null;
 return {customerMapping:r._customerMapping,cifs:result._customers.get(customerKey(r))?.cifs||[],kind:kind==='single_payments'?'single':kind==='payment_history'?'history':kind,customerKey:customerKey(r),payeeKey:payeeKey(r),member:r['Sponsor Member ID'],sponsor:r['Sponsor Id'],customer:[r['First Name'],r['Last Name']].filter(Boolean).join(' ')||r['Business name']||r['Business Name']||'',payee:r['Payee Name']||p?.name||'No payee match',relationship:r['Payee Relationship Number'],paymentId:r['Payment ID']||'',amount:r['Payment Amount'],date:r['Payment Schedule Date']||r['Payment Date'],due:r['Payment Due Date']||'',end:r['Payment End Date']||'',status:r['Payment Status']||'',frequency:r['Payment Frequency']??'',frequencyLabel:r.frequencyLabel||'',identifier:r['Recurring / Single Payment Identifier']??'',rule:r['FIS Recurring Rule DB']||'',reference:r['FI Account Reference Number']||'',account:(r['FI Account Number']||'Not supplied'),routing:(r['FI R&T']||'Not supplied'),source,payeeMapping:p?(p.rows>1?'Ambiguous — repeated relationship key':'Candidate match — sponsor/member/relationship'):'Unmatched',payeeSource:p?.source,funding,modelCandidate:kind==='instance'?{count:models?.count||0,sources:models?.sources||[],basis:'Same sponsor, member, relationship, exact FI account number and FIS Rule DB. Proposed validation grouping only; rule-ID equality is not guaranteed.'}:null};
}
export async function pagePayments(inputs,catalog,result,request,signal){
 const rows=[],size=100,page=Math.max(0,Number(request.page)||0),query=String(request.query||'').toLowerCase();let total=0,amount=0n,modelAmount=0n,unclassifiedAmount=0n,rejected=0;
 for(const input of inputs){
  const id=input.layout??identify(input.file.name);if(!['single_payments','recurring_payments','payment_history'].includes(id))continue;
  if(request.filter==='history'&&id!=='payment_history')continue;if(request.filter==='single'&&id!=='single_payments')continue;if(['model','instance','unclassified'].includes(request.filter)&&id!=='recurring_payments')continue;
  const layout=prepareLayout(catalog.layouts.find(l=>l.id===id));let line=0;
  const framer=lineFramer(text=>{
   line++;const parsed=parseRecord(text,layout,result.blankModels);if(parsed.error){rejected++;return;}const r=parsed.record,kind=parsed.kind;identifyCustomer(r,result._identity);
   if(request.customerKey&&customerKey(r)!==request.customerKey)return;if(request.payeeKey&&payeeKey(r)!==request.payeeKey)return;
   if(['model','instance','unclassified'].includes(request.filter)&&kind!==request.filter)return;
   if(request.filter==='future'&&!(id==='single_payments'||kind==='instance'))return;
   if(request.filter==='future'&&r['Payment Schedule Date']<=result.asOf)return;
   if(request.date&&(r['Payment Schedule Date']||r['Payment Date'])!==request.date)return;
   const p=result._payees.get(payeeKey(r));
   if(query&&![...(result._customers.get(customerKey(r))?.cifs||[]),...(result._customers.get(customerKey(r))?.memberIds||[]),result._customers.get(customerKey(r))?.name,r['Sponsor Member ID'],r['Payment ID'],r['Payee Name'],p?.name,p?.nickname,r['FIS Recurring Rule DB'],r['First Name'],r['Last Name']].some(v=>String(v||'').toLowerCase().includes(query)))return;
   if(request.filter==='unmatched'&&p)return;
   if(request.reference&&r['FI Account Reference Number']!==request.reference)return;
   if(request.filter==='funding-unmatched'&&fundingMatch(r,result._funding).status!=='Unmatched')return;
   if(request.filter==='funding-conflict'&&fundingMatch(r,result._funding).status!=='Conflict')return;
   if(total>=page*size&&rows.length<size)rows.push({...paymentView(r,kind,{file:input.file.name,line,layout:id},result),warnings:parsed.warnings});
   total++;if(kind==='model')modelAmount+=BigInt(r['Payment Amount']);else if(kind==='unclassified')unclassifiedAmount+=BigInt(r['Payment Amount']);else amount+=BigInt(r['Payment Amount']);
  });
  for(let offset=0;offset<input.file.size;offset+=CHUNK_BYTES){signal?.throwIfAborted();const bytes=new Uint8Array(await input.file.slice(offset,offset+CHUNK_BYTES).arrayBuffer());signal?.throwIfAborted();framer.push(bytes);}framer.finish();
 }
 return {rows,total,page,size,customer:result._customers.get(request.customerKey)||null,payee:result._payees.get(request.payeeKey)||null,amount:String(amount),modelAmount:String(modelAmount),unclassifiedAmount:String(unclassifiedAmount),rejected};
}
