# Validation — 0.8.0

2026-10-02, Windows, Node 26.5.0.

- 37 tests passed; TypeScript and Vite 8.3.1 build passed.
- Native npm lockfile audit: zero reported vulnerabilities. No dependencies added.
- Reproduced the v0.7 failure with 133 Member customers, 151 Consumer rows and differing Consumer/Payee Member IDs but matching scoped Sponsor Member IDs: old version left 133 groups detached and reported zero customers with multiple account rows; 0.8 links all groups and reports 18 customers with multiple rows.
- Browser verified numeric CIF search, a customer with two accounts, linked payee, one-time payment, recurring model and history; payee drilldown shows its payment and candidate funding match.
- Full payee account numbers are visible, including leading zeros. Public-result tests cover full account display/export while excluding private indexes.
- Tests retain true identity conflicts, ambiguous aliases, missing Member files, sponsor isolation, numeric CIF precision, model-only deliveries and invalid codes. Known instance frequency codes do not create false warnings; unsupported codes still do.
- Five user screenshots show 133 linked Member rows, 151 unlinked Consumer rows and 341 unlinked Payee rows with Member ID not found; 11 single / 75 recurring / 338 history rows linked through sponsor-member aliases. Zero rejected rows. The 43 warnings concern populated instance frequencies. Screenshot evidence is not raw-file join verification. Actual delivery must be re-analyzed.
- Prior v0.7 performance evidence: 700,000 rows in 3.360 seconds, observed RSS 863.69 MiB; history scan 0.480 seconds. Not rerun for 0.8; Mac performance unverified.
- ZIP includes source, tests and built assets; excludes datasets, screenshots, benchmarks and node_modules.
