export const frequencyNames=['Yearly','Every six months','Every three months','Every two months','Monthly','Twice monthly','Every two weeks','Weekly','Every four weeks'];
export function validDate(v){if(!/^\d{8}$/.test(v))return false;const d=new Date(`${v.slice(0,4)}-${v.slice(4,6)}-${v.slice(6,8)}T00:00:00Z`);return Number.isFinite(+d)&&d.toISOString().slice(0,10).replaceAll('-','')===v;}
export const customerKey=r=>JSON.stringify([r['Sponsor Id']||r['Sponsor ID'],r['Sponsor Member ID']||r['Sponsor Member id']||r['Sponsor member id']]);
export const payeeKey=r=>JSON.stringify([customerKey(r),r['Payee Relationship Number']]);
export const masked=v=>v?'••••'+v.slice(-4):'Not supplied';
// Secure login ID is the user-requested DFS CIF. Retained only for local customer lookup.
// Deliberately exclude SSN, tax IDs, email, phone, addresses and free-text memos.
const fields=new Set(['Member ID','Sponsor Id','Sponsor ID','Sponsor Member ID','Sponsor Member id','Sponsor member id','First Name','Last Name','Last Name/Business Name','Business Name','Business name','Payee Relationship Number','Payee Name','Payee Nickname','Payee Account Number','Internal Payee Id','Electronic Indicator','Payment Amount','Payment ID','Payment Schedule Date','Payment Date','Payment Due Date','Payment End Date','Payment Create Date','Payment Modified Date','Recurring / Single Payment Identifier','Payment Frequency','FIS Recurring Rule DB','Payment Status','Primary Account Indicator','FI Account Type','FI Account Number','FI Account Reference Number','FI R&T']);
export function prepareLayout(layout){return {...layout,fields:layout.fields.filter(f=>fields.has(f.name)||(layout.id==='member'&&f.name==='Secure login ID'))};}
export function parseRecord(text,layout,blankModels=false){
 const id=layout.id,warnings=[];
 if(text.length!==layout.listed_field_length_total||/[^\x20-\x7e]/.test(text))return {error:`Width/encoding mismatch: expected ${layout.listed_field_length_total} ASCII bytes; observed ${text.length}.`};
 const r={};for(const f of layout.fields)r[f.name]=text.slice(f.start-1,f.end).trim();
 const memberField=id==='consumer'?'Sponsor member id':id==='payee'?'Sponsor Member id':'Sponsor Member ID';
 if(id!=='payee_nickname'&&(!r[memberField]||!(r['Sponsor Id']||r['Sponsor ID'])))return {error:'Missing sponsor/member key.'};
 if(id==='consumer'&&!['DDA','SV'].includes(r['FI Account Type']))warnings.push('Funding account type is blank or undocumented; row retained with its original code.');
 let kind=id;
 if(['single_payments','recurring_payments','payment_history'].includes(id)){
  if(!/^\d+$/.test(r['Payment Amount'])||!r['Payee Relationship Number'])return {error:'Invalid amount or missing relationship.'};
  if(!validDate(r['Payment Schedule Date']??r['Payment Date']))return {error:'Invalid process/schedule date.'};
 }
 if(id==='single_payments'&&!['1','50'].includes(r['Payment Status']))return {error:'Unknown single-payment status.'};
 if(id==='consumer'&&(!r['Member ID']||!['Y','N'].includes(r['Primary Account Indicator'])))return {error:'Missing Member ID or unknown funding-account code.'};
 if(id==='payee'&&!r['Payee Relationship Number'])return {error:'Missing payee relationship number.'};
 if(id==='recurring_payments'){
  const code=r['Recurring / Single Payment Identifier'],frequency=r['Payment Frequency'];
  // Normalize only numeric codes; never normalize identifiers or account numbers.
  const numericFrequency=/^\d{1,6}$/.test(frequency)?String(Number(frequency)):frequency;
  r.frequencyLabel=frequencyNames[Number(numericFrequency)]&&numericFrequency!==''?frequencyNames[Number(numericFrequency)]:'Not specified / unknown';
  kind=code==='1'?'instance':code===''&&blankModels?'model':'unclassified';
  if(kind==='unclassified')warnings.push('Recurring type unresolved. Blank-as-model is a profile choice; other identifiers need source clarification. Row retained outside model/instance totals.');
  if(kind==='instance'&&frequency!=='')warnings.push('Instance identifier is 1, but frequency is populated. Instance retained; source frequency convention needs review.');
  if(kind==='model'&&!/^[0-8]$/.test(numericFrequency))warnings.push('Model frequency is missing or unsupported; model retained without projecting occurrences.');
  if(frequency!==numericFrequency)warnings.push('Zero-padded numeric frequency interpreted using documented 0–8 codes; original value preserved.');
 }
 return {record:r,kind,warnings};
}

export const accountTypeLabel=code=>code==='DDA'?'Checking (DDA)':code==='SV'?'Savings (SV)':code?code+' (unmapped)':'Not supplied';
