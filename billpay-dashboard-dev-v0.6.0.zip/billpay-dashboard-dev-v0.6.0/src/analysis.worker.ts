import {analyzeFiles} from './core/stream.mjs';
import {pageEntities,pagePayments,publicResult,summary} from './core/explore.mjs';
import catalog from './layouts.json';
let result:any=null,inputs:any[]=[],queryAbort:AbortController|null=null;
self.onmessage=async({data})=>{try{
 if(data.type==='explore'){
  if(!result)return;queryAbort?.abort();const controller=new AbortController();queryAbort=controller;
  const response=data.entity==='Payments'?await pagePayments(inputs,catalog,result,data,controller.signal):pageEntities(result,data);
  if(!controller.signal.aborted)self.postMessage({type:'explore',...response,requestId:data.requestId});return;
 }
 if(data.type==='export'){
  if(result)self.postMessage({type:'export',blob:new Blob([JSON.stringify({version:'0.6.0',note:'Provisional joins; masked account values; no settlement inference.',...publicResult(result)})],{type:'application/json'})});return;
 }
 queryAbort?.abort();result=null;inputs=data.files;
 result=await analyzeFiles(inputs,catalog,data.asOf,data.blankModels,p=>self.postMessage({type:'progress',...p}));
 self.postMessage({type:'complete',result:summary(result)});
}catch(e){if(e instanceof Error&&e.name==='AbortError')return;self.postMessage({type:'error',requestId:data.requestId,message:e instanceof Error?e.message:'Analysis failed.'});}};
