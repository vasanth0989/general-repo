# Validation — 0.6.0

2026-10-02, Windows, Node 26.5.0.

- 28 automated tests pass; TypeScript check and Vite 8.3.1 production build pass.
- Native npm lockfile audit: zero known vulnerabilities. No new dependencies.
- Tests cover padded CIF search, multiple CIF values, customer isolation, full-account duplicate checks versus identical masked endings, recurring models with zero instances, scoped history/future queries, exact money, bounded streaming and server restrictions.
- Browser: existing 98-record synthetic delivery, search TEST_LOGIN_2 -> one customer, open customer -> two payees, two accounts, one instruction, one instance and three history rows. Open payee -> its one-time/recurring/history records. Duplicate review and breadcrumb return checked locally.
- Prior v0.5 performance baseline: 700,000 synthetic records, 100,000 customer/account/payee groups: 3.168 seconds analysis; observed process RSS 850.81 MiB; filtered history query 0.474 seconds. Totals and last-customer drilldown pass. Test data and screenshots are not packaged.
- These are Windows observations, not enterprise Mac guarantees. No actual FIS delivery was available. Source layouts retain unknown approval/current applicability; customer/payee joins and duplicate heuristics are evidence-bounded, not vendor certification.
- Only supplied records analyzed. No projection or inference of settlement. No automatic deduplication. CIF resides in session memory and user-requested exports, with no telemetry or persistent browser storage.

Funding update checks: unknown and blank type codes retained with warnings, dropdown counts computed before filters, customer isolation, full and partial number matching with leading zeros, combined type/text/number filters, and masked public/export output. Browser verification: 15 rows = 12 Checking (80%) + 3 Savings (20%); Savings plus number fragment 0102 returns one masked account.
