# Billpay explorer — development release 0.6.0

Source, standalone tests and the prebuilt app are included. Sample datasets, benchmark files, screenshots and node_modules are excluded.

## Run on Mac or Windows

Stop the previous server with Ctrl+C. Extract this ZIP into a separate folder, open Terminal there and run:

```sh
npm start
```

Open http://127.0.0.1:4173 and refresh. The footer should say 0.6.0. No npm install is needed to use the prebuilt app.

For local editing through your approved Artifactory registry:

```sh
npm config get registry
npm ci
npm run dev
```

Open http://127.0.0.1:5173. Save source changes for live updates. Run npm run check to test and build, then npm start to serve the new dist. Node >=22.12 required. Vite stays at 8.3.1; no new dependencies were added. Do not copy Windows node_modules to Mac. Keep Mac node_modules for source-only updates; run npm ci when dependencies change. Back up local edits before replacing source. Preserve enterprise credentials/settings and use the approved registry. The supplied .npmrc disables dependency lifecycle scripts and does not override registry or authentication.

Keep input files outside public/, dist/ and project source folders, which development servers may serve.

## Customer navigation and CIF

Start in Customers. The first column is CIF, taken from Member Secure login ID (64 characters, derived positions 251–314). CIF is DFS terminology confirmed by the user, not a vendor field rename. Search CIF, Member ID, Sponsor Member ID or name; all identifiers preserve leading zeros. Missing CIF stays explicitly absent; conflicting values are retained and warned. CIF never replaces sponsor/member source joins.

Open a customer for a full workspace with payees, duplicate payees, funding accounts, one-time payments, recurring instructions, supplied instances, future-dated supplied payments, and history. Open a payee for the same payment categories restricted to that customer/payee. Breadcrumbs return to the customer or customer search. Payment detail includes source evidence. No unsupplied payment is generated.

Duplicate payees is a separate customer tab and a global navigation entry. It flags repeated relationship keys and possible duplicates across different relationships with the same normalized name and exact full payee account in one customer. Normalization only changes name case and whitespace. Blank accounts and names are excluded from the latter heuristic; matching masked last four alone is insufficient. These are review rules, not proven duplicate entities. Nothing is merged or removed. Repeated-key source variants are available in Payee & source details; payment association remains ambiguous for those keys.

## Funding account filters and chart

The Funding accounts page shows account-row counts and percentages by the FI Account Type actually supplied in Consumer. The dropdown and clickable bars use the same scoped inventory; totals remain before search/type filters, within the selected customer when applicable. Counts include repeated Consumer rows, not deduplicated physical accounts.

DDA is Checking and SV is Savings according to the supplied layout. Other codes, including blank, are now retained with a warning and displayed as unmapped / Not supplied rather than rejected. No money-market code is inferred without source evidence. This can increase accepted-row counts relative to previous releases when undocumented type codes are present.

Use Account number to search a full number or any contiguous part; leading zeros are preserved. Combine it with account type and the existing text search. Results and exported summaries remain masked; full numbers are searched in worker memory and omitted from public results. Reset filters clears the number, type and text query without losing the selected customer.

## Explore

- Every Overview metric opens a record explorer. Customer rows open the full customer workspace.
- Funding accounts show source reference, masked account/routing, primary/secondary status and source line. Follow a reference to matching payment rows.
- Payees supports name, nickname, relationship and customer search. Inspect scheduled/history row counts and exact amounts; open a payee to view associated payment records.
- Payments supports single, model, instance, history, future, unresolved and unmatched/conflicting filters. Open any record for dates, amount, source codes and mapping evidence.
- Payment detail shows candidate, ambiguous, conflicting or unmatched payee/funding results. Source filename and line number make every observation traceable. These are source-to-source candidate matches, not target-system mappings.
- Data quality distinguishes excluded invalid records from retained warnings. Observed recurring identifier/frequency combinations are counted. Re-run from Data quality after changing the blank-model interpretation.
- Search/paging and payment-detail scans run in a worker. Up to 100 matched rows are sent to the interface at a time.

## Recurring rules

User-confirmed prior-project convention: blank identifier at 573–574 means recurring model. Enabled by default; optionally disable to inspect unresolved blanks. Identifier 1 means an instance. A populated instance frequency raises a warning rather than rejecting that instance. Numeric frequency padding is normalized (000004 -> 4); raw values stay visible. Other identifier values remain unresolved, outside known model/instance totals.

The current user-approved scope analyzes supplied records only. No projections are calculated or required. A delivery with models and no instances is valid; instructions remain inspectable and the instance view reports no instances supplied. Historical prior-project projection behavior is outside this dashboard scope. Models are excluded from instance/history amounts. No global payment deduplication is assumed.

Manual model-instance candidate grouping uses exact SponsorMemberID + PayeeRelationshipNumber + FIAccountNumber + FISRecurringRuleDB, additionally scoped by sponsor. The user explicitly says Rule DB equality across model/instance is unproven. A candidate is not a production-verified link, and no link is inferred from amount or dates.

## Mapping rules and limitations

Exact sponsor + Sponsor Member ID scopes source joins. Leading zeros are preserved. The headline customer count and explorer both use distinct sponsor + Sponsor Member ID across all supplied files. The exported consumerCustomers metric separately retains the distinct sponsor + Member ID count from Consumer.

Payee association uses sponsor/member/relationship. Repeated keys are ambiguous; displayed metadata comes from the first row, and no records are automatically deduplicated. Search is over the Payee file name/nickname; independent Nickname identifiers are not automatically joined because their cross-file meaning remains unverified.

Funding first compares the customer's exact FI account reference, then exact routing/account if no reference candidate exists. Multiple matching Consumer rows remain ambiguous. A reference match with different supplied routing/account is a conflict. Account-reference drilldown lists the rows that use that reference; it does not prove all those rows have consistent account fields. Account and routing numbers are masked in UI/export. SSNs, tax IDs, emails, addresses and free-text memos are not selected for drilldown.

Source profile remains provisional: contiguous ASCII fixed width, space padding, LF/CRLF lines. No automatic header/trailer stripping. Only Nickname offsets are printed; others derive from ordered lengths. Observed layout revision February 17, 2010; approval/current applicability unknown. Missing files or invalid/unclassified rows mean incomplete coverage. Warning rows remain in totals.

History statuses are presented as supplied; successful processing, ACH transmission, settlement and cutover ownership are not inferred. Monetary aggregation uses integer minor units with two display decimals; currency is unspecified. Model amounts are never combined with instance/history amounts.

## Performance and privacy

No fixed file-size cap. One delivery at a time; one file per recognized layout; up to 300 selected files. Files stream in 1 MiB chunks. The worker retains customer, account and payee indexes and File handles, and re-reads payment files on demand for searches. New searches cancel previous scans. A scan over large payment files may take time even when only 100 rows are displayed.

Memory scales with unique customers and account/payee keys, not just record count. Richer indexes use more RAM than v0.3. The updated 700,000-row test with 100,000 customers took 3.17s in Node, observed process RSS about 851 MiB. Filtered history lookup took 0.47s. These are Windows observations, not Mac/browser guarantees.

No file uploads, telemetry, input modifications or persistent browser storage. Refresh clears the session. Summary export contains CIF values, names, identifiers, masked account details and source locations; it does not include raw payment records or private lookup maps. Treat exports as sensitive.

## Source map

src/AnalysisApp.tsx and explorer.css implement navigation/details. src/core/record.mjs centralizes field selection/validation. analysis.mjs aggregates and indexes relationships. stream.mjs reads bounded chunks. explore.mjs pages entities and scans payment details. analysis.worker.ts coordinates work and cancellation. layouts.json contains the evidence catalog. server/index.mjs serves the prebuilt UI only on loopback. tests/ runs without external sample files.
