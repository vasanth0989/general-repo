# Validation — 0.11.0

2026-10-22, Windows. 47 automated tests pass. TypeScript and Vite 8.3.5 production build pass. npm audit --package-lock-only reports zero vulnerabilities. Lock includes Mac ARM64 and x64 optional build dependencies.

Regression coverage includes 50/20/3 groups, separate pairs, original-inclusive largest-group filtering/sorting, stable sorting before pagination, scoped group drill-down, invalid group IDs, relationship payment lookup and existing reconciliation behavior.

Browser verified five groups ordered 50,20,3,2,2; opening the 50 group displays 50 relationships and customer statistics largest=50/groups=3. Customer ascending sort yields 2 then 50, and 5+ retains only the customer with largest=50. Overview history-by-process-date chart is absent. Synthetic verification screenshot is outside the distribution. Test fixture intentionally contains only Member and Payee files, so missing-file notices are expected.

Source, tests, pinned lockfile and prebuilt dist are included. Datasets, screenshots and node_modules are excluded. Mac execution and large-volume performance were not re-benchmarked for this release.
