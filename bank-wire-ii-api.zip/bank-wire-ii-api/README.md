# bank-wire-ii-api

Wire II service for the DFS OPF Convergence program. Today it holds the FIS-side client: a Spring Boot client for the FIS Universal Execution API (EP-POM-CCTI v1): obtains an access token
with the OAuth2 client credentials grant and posts pain.001.001.11 messages to OPF in the FIS JSON
shape. The request and response models are generated at build time from the contract downloaded
from Code Connect.

Java 21, Gradle 9.8 (wrapper included), Spring Boot 4.1, OpenAPI Generator 7.26.

## Layout

```
build.gradle                         plugins, dependencies, model generation (with a small spec patch)
src/main/resources/openapi/EP-POM-CCTI.json      the contract from Code Connect
src/main/resources/application.yml               gateway URLs, headers, casing; secrets from the environment
src/main/java/com/capitalone/bank/wireii/api/
  BankWireIiApiApplication
  config/FisProperties          fis.opf.* settings
  config/FisClientConfig        client registration, token manager (refreshes 60 s before expiry), RestClient, Jackson mapper
  config/FisPropertyNaming      renders IBAN, BICFI, LEI, UETR as FIS's example does (the contract spells them iBAN, bICFI, lEI, uetr)
  constants/FisHeaders          header names
  service/OpfSubmitService      interface and SubmitResult
  service/impl/OpfSubmitServiceImpl   POST /customer-credit-transfer-initiations with uuid, idempotency-key, organization-id
  runner/SendSampleRunner       sends one JSON file at start-up when fis.opf.send-sample is set
  model/ (generated)            FIS request and response types
src/test/resources/samples/          FIS's UC01 example and a USD corporate wire
build/generated/openapi/             generated models (com.capitalone.bank.wireii.api.model), created by the build
```

## Build and test

```bash
./gradlew build
```

`compileJava` depends on `openApiGenerate`, so every build (and every IntelliJ Gradle sync that runs a build) regenerates the models from the contract first; there is no separate step. The task generates the models, compiles, and runs the tests: the two samples round-trip through the
generated model without losing a field, and the HTTP client sends the required headers and
returns 202 and problem+json responses as results rather than exceptions.

To open in IntelliJ: File, Open, choose the folder; let it import the Gradle project. Run
`openApiGenerate` once (or any build) so the generated sources appear.

## Send a request to the Sandbox

Put the Sandbox consumer key and secret of the Code Connect application into
`src/main/resources/application.yml` (`fis.opf.consumer-key`, `fis.opf.consumer-secret`), then:

```bash
./gradlew bootRun --args='--fis.opf.send-sample=src/test/resources/samples/usd-corporate-wire.json'
```

The yml with real values must not be committed; the placeholders make the runner refuse to send
until they are replaced.

The runner parses the file into the generated model, requests a token, posts the message and logs
the HTTP status, the uuid sent and echoed, the idempotency key, and the response body on errors.

Settings in `application.yml` under `fis.opf`:

| Setting | Default | Meaning |
|---|---|---|
| `base-url` | UAT gateway, pom/v1 | change for production once FIS confirms the URL |
| `token-uri` | UAT token endpoint | |
| `organization-id` | 8203 | Discover's FIS processing organisation |
| `environment` | empty | optional `environment` header; empty means absent |
| `json-casing` | example | `example` = IBAN/BICFI/LEI/UETR; `contract` = iBAN/bICFI/lEI/uetr |

## Known gateway and OPF behaviour (Sandbox, October 2026)

| Response | Meaning |
|---|---|
| 401, fault 900901 | token missing, invalid or expired |
| 404, "No matching resource found" | wrong path |
| 500, fault 101503 "Error connecting to the back end" | gateway could not reach OPF at that moment; retry later |
| 504 HTML page from the edge | gateway hung on the request (seen with an empty body) |
| 400, problem+json with `details[]` | OPF validated the message and rejected it; read `fields` |
| 422 | same idempotency-key with a different payload |
| 202, empty body, `uuid` echoed | accepted |

Open with FIS: the business application header `from`/`to` identifiers for Discover (the samples
carry FIS's demo values), the `characterSet` rule, which identifier casing OPF expects, and the
intermittent backend availability.

## Using the models from the mapper library

The generated package `com.capitalone.bank.wireii.api.model` is the FIS-side target type for the
payment-object mapper: build a `Pain001v11UniversalApplicationMessage1`, hand it to
`OpfSubmitService.submit`. Serialise with the `fisObjectMapper` bean, not Spring's default mapper,
because the generated classes carry Jackson 2 annotations.
