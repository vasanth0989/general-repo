package com.capitalone.bank.wireii.api.config;

import static org.assertj.core.api.Assertions.assertThat;

import com.capitalone.bank.wireii.api.model.Pain001v11UniversalApplicationMessage1;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;
import java.io.InputStream;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Map;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * The generated models must read the FIS example and our own request and write them back without
 * losing or inventing a field; any divergence here would surface as a 400 from OPF. Two tolerated
 * differences: date-times are compared as instants (fraction digits and offset notation may change),
 * and the ISO identifiers compare case-insensitively (IBAN versus iBAN, see FisPropertyNaming).
 */
class ModelRoundTripTest {

    private static final Map<String, String> IDENTIFIERS = Map.of(
            "iban", "IBAN", "bicfi", "BICFI", "lei", "LEI", "uetr", "UETR");

    @ParameterizedTest
    @CsvSource({
        "/samples/fis-example-uc01.json, example",
        "/samples/usd-corporate-wire.json, example",
        "/samples/fis-example-uc01.json, contract",
        "/samples/usd-corporate-wire.json, contract"})
    void generatedModelRoundTripsTheSample(String resource, String casing) throws Exception {
        var props = new FisProperties("https://x", "https://x/token", "k", "s", "8203", "", null, casing);
        ObjectMapper mapper = new FisClientConfig().fisObjectMapper(props);

        JsonNode original;
        try (InputStream in = getClass().getResourceAsStream(resource)) {
            assertThat(in).as(resource).isNotNull();
            original = mapper.readTree(in);
        }

        Pain001v11UniversalApplicationMessage1 message =
                mapper.treeToValue(original, Pain001v11UniversalApplicationMessage1.class);
        String text = mapper.writeValueAsString(message);
        JsonNode rendered = mapper.readTree(text);

        assertThat(normalise(rendered)).isEqualTo(normalise(original));
        assertThat(message.getBusinessApplicationHeader().getMessageDefinitionIdentifier())
                .isEqualTo("pain.001.001.11");
        if (resource.contains("fis-example")) {
            assertThat(text).contains("example".equals(casing) ? "\"IBAN\"" : "\"iBAN\"");
        }
    }

    /** Canonical form: identifier keys upper-cased, date-time strings reduced to their instant. */
    private static JsonNode normalise(JsonNode node) {
        if (node.isObject()) {
            ObjectNode out = ((ObjectNode) node).objectNode();
            var names = new ArrayList<String>();
            node.fieldNames().forEachRemaining(names::add);
            for (String name : names) {
                String key = IDENTIFIERS.getOrDefault(name.toLowerCase(), name);
                out.set(key, normalise(node.get(name)));
            }
            return out;
        }
        if (node.isArray()) {
            ArrayNode out = ((ArrayNode) node).arrayNode();
            node.forEach(child -> out.add(normalise(child)));
            return out;
        }
        if (node.isTextual() && node.textValue().length() >= 20 && node.textValue().charAt(10) == 'T') {
            try {
                return new TextNode(OffsetDateTime.parse(node.textValue()).toInstant().toString());
            } catch (DateTimeParseException ignored) {
                return node;
            }
        }
        return node;
    }
}
