package com.capitalone.bank.wireii.api.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

import com.capitalone.bank.wireii.api.config.FisClientConfig;
import com.capitalone.bank.wireii.api.config.FisProperties;
import com.capitalone.bank.wireii.api.service.OpfSubmitService;
import java.util.UUID;
import java.util.regex.Pattern;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClient;

/** Exercises the HTTP contract against a mock gateway: headers, body, and how 202 and 400 come back. */
class OpfSubmitServiceImplTest {

    private static final String BASE = "https://gateway.test/api/enterprise-payments/pom/v1";
    private static final Pattern UUID_RE =
            Pattern.compile("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$");

    private MockRestServiceServer server;
    private OpfSubmitService client;

    @BeforeEach
    void setUp() {
        RestClient.Builder builder = RestClient.builder().baseUrl(BASE);
        server = MockRestServiceServer.bindTo(builder).build();
        var props = new FisProperties(BASE, "https://gateway.test/token", "key", "secret", "8203", "", null, "example");
        client = new OpfSubmitServiceImpl(builder.build(), new FisClientConfig().fisObjectMapper(props), props);
    }

    @Test
    void sendsRequiredHeadersAndReturnsAcceptedOn202() {
        UUID idem = UUID.randomUUID();
        server.expect(requestTo(BASE + OpfSubmitService.PATH))
                .andExpect(method(HttpMethod.POST))
                .andExpect(header("Content-Type", MediaType.APPLICATION_JSON_VALUE))
                .andExpect(header("idempotency-key", idem.toString()))
                .andExpect(header("organization-id", "8203"))
                .andExpect(header("uuid", org.hamcrest.Matchers.matchesPattern(UUID_RE)))
                .andExpect(content().json("{\"businessApplicationHeader\":{}}"))
                .andRespond(withStatus(HttpStatus.ACCEPTED).header("uuid", "echo"));

        var result = client.submitJson("{\"businessApplicationHeader\":{}}", idem);

        server.verify();
        assertThat(result.accepted()).isTrue();
        assertThat(result.status()).isEqualTo(202);
        assertThat(result.echoedUuid()).isEqualTo("echo");
        assertThat(result.body()).isEmpty();
    }

    @Test
    void returnsProblemBodyInsteadOfThrowingOn400() {
        String problem = "{\"details\":[{\"code\":\"UE-0102\",\"subcode\":\"AH.NA\","
                + "\"message\":\"Not allowed business application header field\","
                + "\"fields\":[\"$.businessApplicationHeader.characterSet\"]}]}";
        server.expect(requestTo(BASE + OpfSubmitService.PATH))
                .andRespond(withStatus(HttpStatus.BAD_REQUEST)
                        .contentType(MediaType.APPLICATION_PROBLEM_JSON)
                        .body(problem));

        var result = client.submitJson("{}", UUID.randomUUID());

        assertThat(result.accepted()).isFalse();
        assertThat(result.status()).isEqualTo(400);
        assertThat(result.body()).contains("UE-0102").contains("characterSet");
    }
}
