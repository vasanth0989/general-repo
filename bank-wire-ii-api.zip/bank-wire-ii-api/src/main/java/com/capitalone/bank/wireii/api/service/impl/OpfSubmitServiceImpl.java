package com.capitalone.bank.wireii.api.service.impl;

import com.capitalone.bank.wireii.api.config.FisProperties;
import com.capitalone.bank.wireii.api.constants.FisHeaders;
import com.capitalone.bank.wireii.api.model.Pain001v11UniversalApplicationMessage1;
import com.capitalone.bank.wireii.api.service.OpfSubmitService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

/**
 * Posts a pain.001.001.11 universal application message to EP-POM-CCTI.
 *
 * <p>Every call carries a fresh {@code uuid} header and the caller's idempotency key. The gateway
 * answers 202 with no body on success and a problem+json body on 400, 422, 500 and 503; both are
 * returned as a {@link SubmitResult} rather than thrown, so the caller can log and decide.
 */
@Service
public class OpfSubmitServiceImpl implements OpfSubmitService {

    private final RestClient fis;
    private final ObjectMapper mapper;
    private final FisProperties props;

    public OpfSubmitServiceImpl(RestClient fisRestClient, ObjectMapper fisObjectMapper, FisProperties props) {
        this.fis = fisRestClient;
        this.mapper = fisObjectMapper;
        this.props = props;
    }

    @Override
    public SubmitResult submit(Pain001v11UniversalApplicationMessage1 message, UUID idempotencyKey) {
        String json;
        try {
            json = mapper.writeValueAsString(message);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Message cannot be serialised", e);
        }
        return submitJson(json, idempotencyKey);
    }

    @Override
    public SubmitResult submitJson(String json, UUID idempotencyKey) {
        UUID interactionId = UUID.randomUUID();
        var request = fis.post()
                .uri(PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.ALL)
                .header(FisHeaders.UUID, interactionId.toString())
                .header(FisHeaders.IDEMPOTENCY_KEY, idempotencyKey.toString());
        if (props.organizationId() != null && !props.organizationId().isBlank()) {
            request = request.header(FisHeaders.ORGANIZATION_ID, props.organizationId());
        }
        if (props.environment() != null && !props.environment().isBlank()) {
            request = request.header(FisHeaders.ENVIRONMENT, props.environment());
        }
        return request.body(json).exchange((req, res) -> {
            HttpStatusCode status = res.getStatusCode();
            String body = res.getBody() == null ? "" : new String(res.getBody().readAllBytes(), StandardCharsets.UTF_8);
            String echoedUuid = res.getHeaders().getFirst(FisHeaders.UUID);
            return new SubmitResult(status.value(), interactionId, idempotencyKey, echoedUuid, body);
        });
    }
}
