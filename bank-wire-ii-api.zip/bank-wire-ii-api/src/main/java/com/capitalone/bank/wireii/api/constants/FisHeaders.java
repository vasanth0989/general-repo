package com.capitalone.bank.wireii.api.constants;

/** HTTP header names of the FIS Universal Execution API. */
public final class FisHeaders {

    public static final String UUID = "uuid";
    public static final String IDEMPOTENCY_KEY = "idempotency-key";
    public static final String ORGANIZATION_ID = "organization-id";
    public static final String ENVIRONMENT = "environment";

    private FisHeaders() {
    }
}
