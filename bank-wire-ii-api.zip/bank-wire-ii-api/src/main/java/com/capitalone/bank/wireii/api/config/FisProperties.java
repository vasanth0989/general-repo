package com.capitalone.bank.wireii.api.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Connection settings for the FIS API gateway. For the Sandbox trial the consumer key and secret
 * are read from application.yml; before the code reaches a shared branch they move to the secret store.
 *
 * @param baseUrl        gateway base URL for EP-POM-CCTI, for example
 *                       https://api-gw-uat.fisglobal.com/api/enterprise-payments/pom/v1
 * @param tokenUri       OAuth2 token endpoint, for example https://api-gw-uat.fisglobal.com/token
 * @param consumerKey    Code Connect consumer key (OAuth2 client id) for the environment
 * @param consumerSecret Code Connect consumer secret (OAuth2 client secret)
 * @param organizationId FIS processing organisation id sent in the organization-id header (8203 for Discover)
 * @param environment    optional environment header value; empty means absent (primary endpoint)
 * @param sendSample     optional path of a JSON request to send once at start-up, then exit
 * @param jsonCasing     "example" renders IBAN, BICFI, LEI and UETR as in FIS's published example (default);
 *                       "contract" renders them as the OpenAPI schema spells them (iBAN, bICFI, lEI, uetr)
 */
@ConfigurationProperties(prefix = "fis.opf")
public record FisProperties(
        String baseUrl,
        String tokenUri,
        String consumerKey,
        String consumerSecret,
        String organizationId,
        String environment,
        String sendSample,
        String jsonCasing) {

    public static final String REGISTRATION_ID = "fis-opf";

    public boolean exampleCasing() {
        return jsonCasing == null || jsonCasing.isBlank() || "example".equalsIgnoreCase(jsonCasing);
    }

    public boolean hasCredentials() {
        return consumerKey != null && !consumerKey.isBlank() && !consumerKey.startsWith("REPLACE_WITH")
                && consumerSecret != null && !consumerSecret.isBlank() && !consumerSecret.startsWith("REPLACE_WITH");
    }
}
