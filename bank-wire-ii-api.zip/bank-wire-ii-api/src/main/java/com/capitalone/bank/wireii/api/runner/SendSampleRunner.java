package com.capitalone.bank.wireii.api.runner;

import com.capitalone.bank.wireii.api.config.FisProperties;
import com.capitalone.bank.wireii.api.model.Pain001v11UniversalApplicationMessage1;
import com.capitalone.bank.wireii.api.service.OpfSubmitService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Sends one JSON request file at start-up when {@code fis.opf.send-sample} points at a file:
 *
 * <pre>
 * FIS_CONSUMER_KEY=... FIS_CONSUMER_SECRET=... \
 *   ./gradlew bootRun --args='--fis.opf.send-sample=src/test/resources/samples/usd-corporate-wire.json'
 * </pre>
 *
 * The file is parsed into the generated model first, so a shape error fails before any call.
 */
@Component
@ConditionalOnProperty(prefix = "fis.opf", name = "send-sample")
public class SendSampleRunner implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(SendSampleRunner.class);

    private final OpfSubmitService client;
    private final ObjectMapper mapper;
    private final FisProperties props;

    public SendSampleRunner(OpfSubmitService client, ObjectMapper fisObjectMapper, FisProperties props) {
        this.client = client;
        this.mapper = fisObjectMapper;
        this.props = props;
    }

    @Override
    public void run(String... args) throws Exception {
        if (!props.hasCredentials()) {
            log.error("fis.opf.consumer-key and consumer-secret are not set in application.yml; nothing sent.");
            return;
        }
        Path file = Path.of(props.sendSample());
        var message = mapper.readValue(Files.readString(file), Pain001v11UniversalApplicationMessage1.class);
        log.info("Parsed {} into the generated model; sending to {}{}", file, props.baseUrl(), OpfSubmitService.PATH);

        var result = client.submit(message, UUID.randomUUID());

        log.info("HTTP {} | uuid sent {} | uuid echoed {} | idempotency-key {}",
                result.status(), result.interactionId(), result.echoedUuid(), result.idempotencyKey());
        if (result.accepted()) {
            log.info("Accepted by OPF.");
        } else {
            log.warn("Response body: {}", result.body());
        }
    }
}
