package com.capitalone.bank.wireii.api.config;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import java.util.Map;

/**
 * The FIS contract spells a few ISO identifiers as {@code iBAN}, {@code bICFI}, {@code lEI} and
 * {@code uetr}, while FIS's own published example sends {@code IBAN}, {@code BICFI}, {@code LEI}
 * and {@code UETR}. This strategy renders the example form; reading accepts either because the
 * mapper is case-insensitive on property names.
 */
public final class FisPropertyNaming extends PropertyNamingStrategies.NamingBase {

    private static final Map<String, String> EXAMPLE_FORM = Map.of(
            "iBAN", "IBAN",
            "bICFI", "BICFI",
            "lEI", "LEI",
            "uetr", "UETR");

    @Override
    public String translate(String propertyName) {
        return EXAMPLE_FORM.getOrDefault(propertyName, propertyName);
    }
}
