package com.capitalone.bank.wireii.api.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.time.Duration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.AuthorizedClientServiceOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.client.OAuth2ClientHttpRequestInterceptor;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.web.client.RestClient;

/**
 * Wires the OAuth2 client credentials flow for the FIS gateway:
 * one client registration built from FisProperties, a manager that requests and caches the
 * access token (refreshing it 60 seconds before expiry), and a RestClient whose interceptor
 * adds the Bearer header to every call.
 */
@Configuration
public class FisClientConfig {

    @Bean
    ClientRegistrationRepository fisClientRegistrationRepository(FisProperties props) {
        ClientRegistration registration = ClientRegistration.withRegistrationId(FisProperties.REGISTRATION_ID)
                .tokenUri(props.tokenUri())
                .clientId(props.hasCredentials() ? props.consumerKey() : "missing-consumer-key")
                .clientSecret(props.hasCredentials() ? props.consumerSecret() : "missing-consumer-secret")
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
                .build();
        return new InMemoryClientRegistrationRepository(registration);
    }

    @Bean
    OAuth2AuthorizedClientService fisAuthorizedClientService(ClientRegistrationRepository registrations) {
        return new InMemoryOAuth2AuthorizedClientService(registrations);
    }

    @Bean
    OAuth2AuthorizedClientManager fisAuthorizedClientManager(
            ClientRegistrationRepository registrations, OAuth2AuthorizedClientService clientService) {
        OAuth2AuthorizedClientProvider provider = OAuth2AuthorizedClientProviderBuilder.builder()
                .clientCredentials(c -> c.clockSkew(Duration.ofSeconds(60)))
                .build();
        var manager = new AuthorizedClientServiceOAuth2AuthorizedClientManager(registrations, clientService);
        manager.setAuthorizedClientProvider(provider);
        return manager;
    }

    /**
     * Jackson 2 mapper for the generated FIS models (they carry Jackson 2 annotations).
     * Reads property names case-insensitively, keeps the sender's UTC offset on date-times,
     * omits nulls, and renders the ISO identifiers in the casing chosen by fis.opf.json-casing.
     */
    @Bean
    public ObjectMapper fisObjectMapper(FisProperties props) {
        JsonMapper.Builder builder = JsonMapper.builder()
                .addModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE)
                .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
                .enable(MapperFeature.ALLOW_EXPLICIT_PROPERTY_RENAMING)
                .serializationInclusion(JsonInclude.Include.NON_NULL);
        if (props.exampleCasing()) {
            builder.propertyNamingStrategy(new FisPropertyNaming());
        }
        return builder.build();
    }

    @Bean
    RestClient fisRestClient(OAuth2AuthorizedClientManager manager, FisProperties props) {
        var bearer = new OAuth2ClientHttpRequestInterceptor(manager);
        bearer.setClientRegistrationIdResolver(request -> FisProperties.REGISTRATION_ID);
        return RestClient.builder().baseUrl(props.baseUrl()).requestInterceptor(bearer).build();
    }
}
