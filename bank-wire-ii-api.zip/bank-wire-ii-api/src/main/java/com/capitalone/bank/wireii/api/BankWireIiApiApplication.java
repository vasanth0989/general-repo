package com.capitalone.bank.wireii.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Thin client for the FIS Universal Execution API (EP-POM-CCTI v1): obtains a token with the
 * client credentials grant and posts pain.001.001.11 messages in the FIS JSON shape.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class BankWireIiApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BankWireIiApiApplication.class, args);
    }
}
