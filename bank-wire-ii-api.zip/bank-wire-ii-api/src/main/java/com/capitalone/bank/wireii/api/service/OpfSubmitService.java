package com.capitalone.bank.wireii.api.service;

import com.capitalone.bank.wireii.api.model.Pain001v11UniversalApplicationMessage1;
import java.util.UUID;

/** Submits pain.001.001.11 universal application messages to OPF through the FIS gateway. */
public interface OpfSubmitService {

    String PATH = "/customer-credit-transfer-initiations";

    SubmitResult submit(Pain001v11UniversalApplicationMessage1 message, UUID idempotencyKey);

    /** Sends an already-rendered JSON body; used by the sample runner and by tests. */
    SubmitResult submitJson(String json, UUID idempotencyKey);

    /**
     * @param status         HTTP status: 202 accepted; 400 validation; 422 idempotency conflict; 5xx gateway or backend
     * @param interactionId  the uuid header sent
     * @param idempotencyKey the idempotency key sent
     * @param echoedUuid     the uuid header echoed by the gateway, if any
     * @param body           response body, a problem+json document on errors, empty on 202
     */
    record SubmitResult(int status, UUID interactionId, UUID idempotencyKey, String echoedUuid, String body) {
        public boolean accepted() {
            return status == 202;
        }
    }
}
