# Billpay explorer — development release 0.13.1

## Run or update
Extract this ZIP into a new folder, preserving your previous copy/local edits. Run `npm install`, then `npm run build` to generate dist locally. Run `npm start` and open http://127.0.0.1:4173 to serve your build. This source-only ZIP excludes dist. Verify footer version 0.13.1, then select your files again.

For development, use Node >=22.12 and run `npm install`, then `npm run dev` (http://127.0.0.1:5173). Run `npm run check` to test and build. Use npm install to synchronize dependencies. Do not copy Windows node_modules to Mac. Keep enterprise npm registry/authentication settings. The package .npmrc disables dependency lifecycle scripts and does not override the registry.

Source, tests and registry dependency manifests are included. No dist or vendor directory is included. No customer files, sample datasets or node_modules are shipped. For static hosting, publish only the contents of dist. Input files and exported reports must remain outside the published folder/repository.

## Optional DNA segmentation
1. Choose the deconversion folder or individual files.
2. Enable **Perform segmentation** and select the DNA `.xlsx` or `.xls` workbook.
3. Click **Perform analysis**.

The Data sheet must contain BNK_CUST_NBR and SEGMENTS headers in the first 30 rows. Columns can be reordered and additional columns are ignored. The optional Segmentation sheet supplies the definitions (segment label followed by definition) and date. If it is absent, assignments still work and definitions are labeled unavailable. Labels such as SEGMENT 1.A, 1A and 1.A normalize to SEGMENT 1.A. Definitions and date criteria are displayed from the workbook; the app never recomputes these cohorts.

Member Secure login ID (CIF) matches BNK_CUST_NBR exactly after trimming surrounding whitespace. Text leading zeros are preserved. Safe nonnegative integer cells are supported; an explicit zero-only Excel number format preserves displayed zeros. Otherwise numeric IDs remain unpadded: Excel-lost zeros cannot be guessed. Formula CIF/segment cells and unsafe numeric IDs are rejected, with row numbers/reasons in reconciliation. Macros are not executed; links are not fetched.

The denominator is the unique Member customers in the deconversion delivery, never the entire workbook or driver file. Every customer appears in exactly one chart bucket. MISSING CIF, UNMATCHED and CONFLICT remain visible. A CIF shared by multiple Member customers is ambiguous. Different segments across one customer's CIFs or invalid/conflicting workbook assignments are CONFLICT. All of a customer's supplied CIFs must match consistently. Repeated identical workbook assignments do not multiply customers. Reference CIFs outside this delivery are counted separately and never create customers.

Overview shows an interactive donut with counts/percentages and definitions on hover/focus. Click a slice or legend to open its customers. Customers has a Segment column before Member ID, group filters (Segment 1/2/3) and exact subsegment filters. These combine with search, duplicate filters, numeric sorting and pagination; return navigation preserves them. Segment definitions and reconciliation are available above the customer table and under Data quality. Models and History rows columns have been removed from Customers; their details remain in customer/payment workspaces. Segment 3 is shown if present, never automatically excluded. Closed Account Analysis is available as a separate workspace; see below.

## Customers and relationships
Only the Member file defines the customer master. Consumer rows represent funding-account rows and do not create extra customers. Search supports CIF, Member ID, Sponsor Member ID and name. CIF is Member field 7 (Secure login ID, length 64); identifiers stay strings.

Exact Sponsor + Member ID links account/payee rows first. Unambiguous scoped Sponsor Member ID fallback is supported. Numeric Sponsor ID padding may be reconciled when exact paths fail; raw fields and all customer/account identifier zeros remain unchanged. Ambiguous candidates stay unlinked with match evidence.

Open customer → payees → payments/history. Funding accounts support full-account search and observed account-type filters. Counts represent supplied account rows, not deduplicated physical accounts. Full account numbers are visible and included in exported summaries.

## Duplicate payees
Groups contain distinct relationship keys for the same customer, normalized payee name and exact full payee account. Names normalize case/whitespace only; blank names/accounts are excluded. One row per group is shown largest first; drill into a group to see relationships and their payments. Group size includes the original, extra copies exclude it. A customer with groups of 50,20,3 has largest size 50, three groups and 70 extra copies. Customer 2/3/4/5+ filters and largest-group sorting use 50, not 73. Repeated source rows for one relationship remain a separate quality issue. Nothing is automatically merged or deleted.

## Recurring payments and layout evidence
Only supplied records are analyzed; no unsupplied future payments are projected. Blank recurring identifiers use the confirmed delivery model convention when enabled. Identifier 1 defines an instance. Frequency codes 0–8 are normalized numerically, retaining source evidence; blank frequency is not inferred. Models without instances are valid. Model-instance rule matches are candidates only, not a proven production join. Schedule dates do not imply ACH transmission or settlement.

Seven fixed-width layouts are supported; Ebills is excluded. Source revision February 17, 2010 is observed; approval remains unknown. Nickname offsets were printed, other offsets derived from ordered lengths. Invalid widths, keys, amounts and required dates remain visible. Money reconciliation uses integer minor units.

## Local processing and dependencies
Deconversion files and the optional workbook are read in a browser Web Worker. No upload, analytics or remote-processing API is added. The worker script is downloaded from the same static site before running locally. Browser/hosting requests for code are separate from file analysis. Memory is released on refresh; explicit summary exports are local downloads. Excel parsing holds the selected workbook in memory; deconversion parsing streams chunks. Cancel terminates the worker.

The xlsx import is an npm alias to @e965/xlsx@0.20.3, a community republish of SheetJS CE. Vite is pinned to 8.3.4, the version reported available in your Artifactory. All dependencies install from the configured registry; no vendor archives are required. License: public/SHEETJS-LICENSE.txt (also in dist). Official installation reference: https://docs.sheetjs.com/docs/getting-started/installation/frameworks/ . Other dependencies use your configured npm registry. Dependency installation is separate from analysis. See VALIDATION.md for evidence and limitations.

## Segment CIF export

Export Segment CIF above Find your cohort downloads distinct nonempty CIFs, one per line, no header, as TXT. It uses the selected exact segment or parent segment across the complete delivery, not the visible page. All segments exports all Member CIFs. Other customer search/duplicate filters do not narrow this segment export, as stated beside the button. Missing CIFs are omitted; identifiers and leading zeros remain unchanged.

## Closed Account Analysis

Analyze a deconversion delivery first, optionally with segmentation, then open Closed Account Analysis. Select an unquoted TXT file containing account number,CIF, one pair per line. An optional first-line account number,CIF header is accepted. UTF-8 BOM, LF and CRLF are supported. Blank lines are ignored; malformed rows are counted with line-number reasons. Duplicate identical pairs are counted once.

An exact CIF must identify one Member customer, and the account number must exist in that customer’s Consumer funding inventory. Matching an account on a different customer is not sufficient. Unmatched rows show the supplied CIF/account with customer NA and segment No Match. Ambiguous CIFs are separately labeled and do not cause assumed removals. Matched customers link to a scoped Customers view; matched account numbers link to exact-number, customer-scoped Funding accounts.

Funding accounts counts distinct nonblank account numbers per Member customer, not repeated Consumer rows. Post Removal subtracts ALL distinct matched account numbers for that customer in the full input, regardless of table filters. It does not subtract a duplicate input or repeated source row twice. Missing account identifiers cause an unknown Post Removal count. Invalid input rows do not participate in removal counts and are visibly reported. Zero remaining is only a review candidate for potential unenrollment, not an eligibility decision. No source data, FIS account or enrollment is changed. Status is taken from the supplied closed-account list; no live DFS/FIS status is queried or inferred.

The donut shows unique input-pair outcomes; the summary separately reports matched customers and zero-remaining customers. Segment (parent/exact), match status, Post Removal and search filters combine. Post Removal sorts ascending/descending across all filtered results before paging, with unknowns last. Navigating away and returning retains the results and filters until a new delivery/reanalysis/refresh.

Export CIF + Account downloads every pair matching the current filters across all pages, no header, one CIF,account number per line. Reset filters exports all valid unique pairs, including unmatched/ambiguous rows. Filter to Matched or Zero remaining when preparing a focused review. This export order is deliberately CIF first, whereas the input order is account first. All parsing and downloads run locally in the browser.

## Account payment review (0.13.1)
Closed Account Analysis includes a Payments on this account column and clickable payment-outcome summary/filter. Counts are scoped to resolved Member customer + exact funding account number; a unique funding reference can resolve a missing account number. Conflicting references are not assigned. Separate source-row counts show one-time payments, recurring instances, recurring instructions (including models without instances), and history. No future instances are projected; model and instance counts are not summed into payment obligations.
Payments present means supplied scheduled-payment rows or recurring instructions, not verified live status or confirmed future execution. History alone does not qualify. None reported requires both Single and Recurring files, no rejected payment rows, and no unresolved ownership affecting the result. Otherwise Review needed is shown. Positive evidence remains visible alongside coverage warnings. Counts use all supplied rows regardless of schedule date; past-dated or ended instructions remain review evidence, not assertions of active status.
The payment filter combines with existing filters and applies to TXT exports without altering whole-input Post Removal counts. Input-pair totals can include the same account under multiple CIF aliases. No dependencies added; source-only packaging remains unchanged.
