import {customerKey} from './record.mjs';
export function createAccountPayments(){
 const accounts=new Map(),uncertain=new Set();let unlinked=false;
 return {accounts,uncertain,get unlinked(){return unlinked;},add(r,id,kind,funding,linked){
  const key=customerKey(r),number=r['FI Account Number'],routing=r['FI R&T'],ref=r['FI Account Reference Number'];
  const candidates=ref?(funding.refs.get(JSON.stringify([key,ref]))||[]):[];
  const numbers=new Set(candidates.map(a=>a.number).filter(Boolean));
  const conflict=candidates.some(a=>(number&&a.number!==number)||(routing&&a.routing!==routing));
  const account=conflict?'':number||(numbers.size===1?[...numbers][0]:'');
  if(!linked){if(id!=='payment_history')unlinked=true;return;}
  if(!account){if(id!=='payment_history')uncertain.add(key);return;}
  const index=JSON.stringify([key,account]),counts=accounts.get(index)||{single:0,instances:0,models:0,history:0,unclassified:0};
  const field=id==='payment_history'?'history':id==='single_payments'?'single':kind==='model'?'models':kind==='instance'?'instances':'unclassified';counts[field]++;accounts.set(index,counts);
 }};
}
export function accountPaymentEvidence(result,key,account){
 if(!key)return {state:'Not matched',single:0,instances:0,models:0,history:0,unclassified:0};
 const index=result._accountPayments,counts=index?.accounts.get(JSON.stringify([key,account]))||{single:0,instances:0,models:0,history:0,unclassified:0};
 const complete=['single_payments','recurring_payments'].every(id=>result.files?.some(f=>f.layout===id&&f.rejected===0));
 const review=!index||!complete||index.unlinked||index.uncertain.has(key)||counts.unclassified>0;
 return {...counts,review,state:counts.single+counts.instances+counts.models>0?'Payments present':review?'Review needed':'None reported'};
}
