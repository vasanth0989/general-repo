import {segmentCifs,analyzeClosed,closedPage,exportClosed} from './core/closed-accounts.mjs';
import {parseSegmentation,applySegmentation} from './core/segmentation.mjs';
import {analyzeFiles} from './core/stream.mjs';
import {pageEntities,pagePayments,publicResult,summary} from './core/explore.mjs';
import catalog from './layouts.json';
let closedAnalysis:any=null;
let result:any=null,inputs:any[]=[],queryAbort:AbortController|null=null;
self.onmessage=async({data})=>{try{
 if(data.type==='segment-export'){
  if(!result)throw Error('Analyze the delivery first.');const exported=segmentCifs(result,data.segment);if(!exported.count)throw Error('No CIFs are available for this segment.');
  self.postMessage({type:'export',filename:'segment-'+String(data.segment||'all').replace(/[^a-z0-9.-]+/gi,'-')+'-cifs.txt',blob:new Blob([exported.text],{type:'text/plain;charset=utf-8'})});return;
 }
 if(data.type==='closed-analyze'){
  if(!result)throw Error('Analyze the deconversion delivery first.');closedAnalysis=null;
  closedAnalysis=await analyzeClosed(data.file,result,(bytes=0,total=0)=>self.postMessage({type:'closed-progress',closedId:data.closedId,percent:Math.round(100*bytes/(total||1))}));
  self.postMessage({type:'closed-result',closedId:data.closedId,...closedPage(closedAnalysis,data)});return;
 }
 if(data.type==='closed-page'){self.postMessage({type:'closed-result',closedId:data.closedId,...closedPage(closedAnalysis,data)});return;}
 if(data.type==='closed-export'){
  const text=exportClosed(closedAnalysis,data);if(!text)throw Error('No pairs match the selected filters.');
  self.postMessage({type:'export',closedId:data.closedId,filename:'closed-accounts-'+String(data.segment||'all-segments').replace(/[^a-z0-9.-]+/gi,'-')+(data.post?'-'+data.post:'')+'.txt',blob:new Blob([text],{type:'text/plain;charset=utf-8'})});return;
 }
 if(data.type==='explore'){

  if(!result)return;queryAbort?.abort();const controller=new AbortController();queryAbort=controller;
  const response=data.entity==='Payments'?await pagePayments(inputs,catalog,result,data,controller.signal):pageEntities(result,data);
  if(!controller.signal.aborted)self.postMessage({type:'explore',...response,requestId:data.requestId});return;
 }
 if(data.type==='export'){
  if(result)self.postMessage({type:'export',blob:new Blob([JSON.stringify({version:'0.13.1',note:'Provisional joins; full account numbers included; no settlement inference.',...publicResult(result)})],{type:'application/json'})});return;
 }
 queryAbort?.abort();result=null;closedAnalysis=null;inputs=data.files;
 result=await analyzeFiles(inputs,catalog,data.asOf,data.blankModels,p=>self.postMessage({type:'progress',...p}));
 if(data.segmentationFile){const segmentStart=performance.now();self.postMessage({type:'progress',bytes:0,total:data.segmentationFile.size,records:result.metrics.customers,name:'Reading segmentation workbook and matching CIFs locally'});const reference=parseSegmentation(await data.segmentationFile.arrayBuffer(),data.segmentationFile.name);applySegmentation(result,reference);result.segmentation.seconds=(performance.now()-segmentStart)/1000;result.performance.seconds+=result.segmentation.seconds;}
 self.postMessage({type:'complete',result:summary(result)});
}catch(e){if(e instanceof Error&&e.name==='AbortError')return;self.postMessage({type:data.closedId?'closed-error':'error',closedId:data.closedId,requestId:data.requestId,message:e instanceof Error?e.message:'Analysis failed.'});}};

