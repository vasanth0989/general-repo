# Validation — 0.12.0

2026-10-23, Windows. 54 automated tests pass, TypeScript and Vite 8.3.5 build pass. npm lockfile audit: zero reported vulnerabilities. SheetJS 0.20.3 official tarball vendored; license included. Native audit is not a complete security certification.

New regression tests cover XLSX and legacy XLS, text/number-formatted leading zeros, no guessed padding, formula/unsafe numeric rejection, duplicate/conflicting assignments, shared CIF ambiguity, missing/unmatched cases, delivery-only denominator, multiple customer CIFs, malformed headers, group/exact filters, search and sorting before paging. Existing joins, duplicates, payments and streaming checks pass.

Synthetic benchmark: 332,071 reference rows (13,452,878-byte XLSX), 83,000 delivery customers. Node on this Windows machine: parse 2.006 seconds, match 0.223 seconds; 83,000 matched and counted. Observed heap after benchmark approximately 260 MiB; this is not a peak or end-to-end production/browser memory estimate. Workbook parsing uses memory; cancellation terminates the browser worker.

Browser verification: optional switch defaults off, enabling requires a workbook; the 332,071-row workbook imports in the worker. A 12-customer synthetic Member fixture shows 10 matched, one unmatched and one missing CIF, summing to 12. Chart opens exact segment customers; group filter and CIF search compose. Customer table has Segment before Member ID and omits Models/History rows. Definitions are synthetic fixture labels. Missing-file warnings are expected for the Member-only fixture. Screenshots and datasets remain outside the distribution.

Actual DNA workbook and production files were not supplied. Validate the next delivery locally, particularly CIF cell formats and definition-sheet layout. Mac timing has not been measured. Closed-account reconciliation remains deferred.
