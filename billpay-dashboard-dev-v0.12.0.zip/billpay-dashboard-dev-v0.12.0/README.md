# Billpay explorer — development release 0.12.0

## Run or update
Extract this ZIP into a new folder, preserving your previous copy/local edits. Run `npm start` and open http://127.0.0.1:4173. Prebuilt assets are included; no dependency installation is needed for this mode. Verify footer version 0.12.0, then select your files again.

For development, use Node >=22.12 and run `npm ci`, then `npm run dev` (http://127.0.0.1:5173). Run `npm run check` to test and build. This release adds an Excel reader, so existing development installations must run `npm ci`. Do not copy Windows node_modules to Mac. Keep enterprise npm registry/authentication settings. The package .npmrc disables dependency lifecycle scripts and does not override the registry.

Source, tests, pinned dependencies, a vendor package and prebuilt dist are included. No customer files, sample datasets or node_modules are shipped. For static hosting, publish only the contents of dist. Input files and exported reports must remain outside the published folder/repository.

## Optional DNA segmentation
1. Choose the deconversion folder or individual files.
2. Enable **Perform segmentation** and select the DNA `.xlsx` or `.xls` workbook.
3. Click **Perform analysis**.

The Data sheet must contain BNK_CUST_NBR and SEGMENTS headers in the first 30 rows. Columns can be reordered and additional columns are ignored. The optional Segmentation sheet supplies the definitions (segment label followed by definition) and date. If it is absent, assignments still work and definitions are labeled unavailable. Labels such as SEGMENT 1.A, 1A and 1.A normalize to SEGMENT 1.A. Definitions and date criteria are displayed from the workbook; the app never recomputes these cohorts.

Member Secure login ID (CIF) matches BNK_CUST_NBR exactly after trimming surrounding whitespace. Text leading zeros are preserved. Safe nonnegative integer cells are supported; an explicit zero-only Excel number format preserves displayed zeros. Otherwise numeric IDs remain unpadded: Excel-lost zeros cannot be guessed. Formula CIF/segment cells and unsafe numeric IDs are rejected, with row numbers/reasons in reconciliation. Macros are not executed; links are not fetched.

The denominator is the unique Member customers in the deconversion delivery, never the entire workbook or driver file. Every customer appears in exactly one chart bucket. MISSING CIF, UNMATCHED and CONFLICT remain visible. A CIF shared by multiple Member customers is ambiguous. Different segments across one customer's CIFs or invalid/conflicting workbook assignments are CONFLICT. All of a customer's supplied CIFs must match consistently. Repeated identical workbook assignments do not multiply customers. Reference CIFs outside this delivery are counted separately and never create customers.

Overview shows an interactive donut with counts/percentages and definitions on hover/focus. Click a slice or legend to open its customers. Customers has a Segment column before Member ID, group filters (Segment 1/2/3) and exact subsegment filters. These combine with search, duplicate filters, numeric sorting and pagination; return navigation preserves them. Segment definitions and reconciliation are available above the customer table and under Data quality. Models and History rows columns have been removed from Customers; their details remain in customer/payment workspaces. Segment 3 is shown if present, never automatically excluded. Closed-account reconciliation is not part of this release.

## Customers and relationships
Only the Member file defines the customer master. Consumer rows represent funding-account rows and do not create extra customers. Search supports CIF, Member ID, Sponsor Member ID and name. CIF is Member field 7 (Secure login ID, length 64); identifiers stay strings.

Exact Sponsor + Member ID links account/payee rows first. Unambiguous scoped Sponsor Member ID fallback is supported. Numeric Sponsor ID padding may be reconciled when exact paths fail; raw fields and all customer/account identifier zeros remain unchanged. Ambiguous candidates stay unlinked with match evidence.

Open customer → payees → payments/history. Funding accounts support full-account search and observed account-type filters. Counts represent supplied account rows, not deduplicated physical accounts. Full account numbers are visible and included in exported summaries.

## Duplicate payees
Groups contain distinct relationship keys for the same customer, normalized payee name and exact full payee account. Names normalize case/whitespace only; blank names/accounts are excluded. One row per group is shown largest first; drill into a group to see relationships and their payments. Group size includes the original, extra copies exclude it. A customer with groups of 50,20,3 has largest size 50, three groups and 70 extra copies. Customer 2/3/4/5+ filters and largest-group sorting use 50, not 73. Repeated source rows for one relationship remain a separate quality issue. Nothing is automatically merged or deleted.

## Recurring payments and layout evidence
Only supplied records are analyzed; no unsupplied future payments are projected. Blank recurring identifiers use the confirmed delivery model convention when enabled. Identifier 1 defines an instance. Frequency codes 0–8 are normalized numerically, retaining source evidence; blank frequency is not inferred. Models without instances are valid. Model-instance rule matches are candidates only, not a proven production join. Schedule dates do not imply ACH transmission or settlement.

Seven fixed-width layouts are supported; Ebills is excluded. Source revision February 17, 2010 is observed; approval remains unknown. Nickname offsets were printed, other offsets derived from ordered lengths. Invalid widths, keys, amounts and required dates remain visible. Money reconciliation uses integer minor units.

## Local processing and dependencies
Deconversion files and the optional workbook are read in a browser Web Worker. No upload, analytics or remote-processing API is added. The worker script is downloaded from the same static site before running locally. Browser/hosting requests for code are separate from file analysis. Memory is released on refresh; explicit summary exports are local downloads. Excel parsing holds the selected workbook in memory; deconversion parsing streams chunks. Cancel terminates the worker.

SheetJS CE 0.20.3 is bundled from the official tarball, included at vendor/xlsx-0.20.3.tgz for reproducible development without a runtime CDN dependency. License: public/SHEETJS-LICENSE.txt (also in dist). Official installation reference: https://docs.sheetjs.com/docs/getting-started/installation/frameworks/ . Other dependencies use your configured npm registry. Dependency installation is separate from analysis. See VALIDATION.md for evidence and limitations.
