package com.capitalone.payx.wireii.pain001;

import java.time.OffsetDateTime;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

/** Date and time conversions for the ISO 20022 types. */
final class Dates {

    private static final DatatypeFactory FACTORY;

    static {
        try {
            FACTORY = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            throw new IllegalStateException("No JAXP datatype factory available", e);
        }
    }

    private Dates() {
    }

    /** ISODateTime with offset, as pain.001 CreDtTm expects. */
    static XMLGregorianCalendar toXmlDateTime(OffsetDateTime dateTime) {
        return FACTORY.newXMLGregorianCalendar(GregorianCalendar.from(dateTime.toZonedDateTime()));
    }
}
