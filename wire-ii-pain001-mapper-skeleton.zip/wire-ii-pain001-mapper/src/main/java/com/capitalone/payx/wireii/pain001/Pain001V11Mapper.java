package com.capitalone.payx.wireii.pain001;

import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import com.capitalone.payx.wireii.pain001.v11.model.CustomerCreditTransferInitiationV11;
import com.capitalone.payx.wireii.pain001.v11.model.Document;
import com.capitalone.payx.wireii.pain001.v11.model.GroupHeader95;
import com.capitalone.payx.wireii.pain001.v11.model.PartyIdentification135;
import com.capitalone.payx.wireii.pain001.v11.model.PaymentInstruction40;

import java.time.OffsetDateTime;
import java.util.Objects;

/**
 * Maps the Payment Exchange payment object to a pain.001.001.11 Document.
 *
 * <p>The mapping rules are specified in docs/pain001-v11-field-mapping.md. This class holds the
 * top-level assembly only; the group header, payment information and transaction blocks each get
 * their own builder as the mapping is implemented.
 */
public final class Pain001V11Mapper {

    private final MappingContext context;

    public Pain001V11Mapper(MappingContext context) {
        this.context = Objects.requireNonNull(context, "context");
    }

    /**
     * Builds the pain.001.001.11 document for one payment.
     *
     * @param payload   the completed payment object from the OPFRAIL stage
     * @param createdAt the message creation time (from the enterprise message timestamp)
     */
    public Document map(SDPPayload payload, OffsetDateTime createdAt) {
        Objects.requireNonNull(payload, "payload");
        Objects.requireNonNull(createdAt, "createdAt");

        CustomerCreditTransferInitiationV11 initiation = new CustomerCreditTransferInitiationV11();
        initiation.setGrpHdr(groupHeader(payload, createdAt));
        initiation.getPmtInf().add(paymentInformation(payload));

        Document document = new Document();
        document.setCstmrCdtTrfInitn(initiation);
        return document;
    }

    private GroupHeader95 groupHeader(SDPPayload payload, OffsetDateTime createdAt) {
        GroupHeader95 header = new GroupHeader95();
        header.setMsgId(Identifiers.messageId(payload));
        header.setCreDtTm(Dates.toXmlDateTime(createdAt));
        header.setNbOfTxs("1");

        PartyIdentification135 initiatingParty = new PartyIdentification135();
        initiatingParty.setNm(context.initiatingPartyName());
        header.setInitgPty(initiatingParty);
        return header;
    }

    private PaymentInstruction40 paymentInformation(SDPPayload payload) {
        // Debtor side and the single credit transfer transaction: next increment.
        PaymentInstruction40 instruction = new PaymentInstruction40();
        instruction.setPmtInfId(Identifiers.paymentInformationId(payload));
        return instruction;
    }
}
