package com.capitalone.payx.wireii.pain001;

import com.capitalone.payx.wireii.pain001.v11.model.Document;
import com.capitalone.payx.wireii.pain001.v11.model.ObjectFactory;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import java.io.StringWriter;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;

/**
 * Renders a pain.001.001.11 Document as XML and, optionally, validates it against the schema.
 * The JSON rendering for the FIS API is a separate step, once FIS confirms its element conventions.
 */
public final class Pain001V11Marshaller {

    private static final String SCHEMA_RESOURCE = "/xsd/pain.001.001.11.xsd";

    private final JAXBContext context;
    private final Schema schema;

    public Pain001V11Marshaller() {
        try {
            this.context = JAXBContext.newInstance(Document.class);
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            this.schema = factory.newSchema(
                    new StreamSource(Pain001V11Marshaller.class.getResourceAsStream(SCHEMA_RESOURCE)));
        } catch (JAXBException | SAXException e) {
            throw new IllegalStateException("Cannot initialise the pain.001.001.11 marshaller", e);
        }
    }

    /** Marshals the document to XML. With {@code validate} set, schema violations throw. */
    public String toXml(Document document, boolean validate) {
        try {
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            if (validate) {
                marshaller.setSchema(schema);
            }
            StringWriter writer = new StringWriter();
            marshaller.marshal(new ObjectFactory().createDocument(document), writer);
            return writer.toString();
        } catch (JAXBException e) {
            throw new MappingException("pain.001.001.11 message is not valid: " + rootMessage(e), e);
        }
    }

    private static String rootMessage(Throwable t) {
        Throwable cause = t;
        while (cause.getCause() != null) {
            cause = cause.getCause();
        }
        return cause.getMessage();
    }
}
