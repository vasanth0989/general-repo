package com.capitalone.payx.wireii.pain001;

/** Thrown when the payment object cannot be mapped to a valid pain.001.001.11 message. */
public class MappingException extends RuntimeException {

    public MappingException(String message) {
        super(message);
    }

    public MappingException(String message, Throwable cause) {
        super(message, cause);
    }
}
