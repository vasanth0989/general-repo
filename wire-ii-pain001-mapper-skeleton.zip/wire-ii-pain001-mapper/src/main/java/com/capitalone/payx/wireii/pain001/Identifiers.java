package com.capitalone.payx.wireii.pain001;

import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;

/**
 * Identifier rules. The choice of source field for each identifier is an open question in the
 * mapping document (section 8, question 2); the current rules follow the reference converter.
 */
final class Identifiers {

    static final int MAX_35 = 35;

    private Identifiers() {
    }

    /** GrpHdr/MsgId: Max35Text, unique per message. */
    static String messageId(SDPPayload payload) {
        return max35(payload.getClientTransactionId(), "clientTransactionId");
    }

    /** PmtInf/PmtInfId: Max35Text. */
    static String paymentInformationId(SDPPayload payload) {
        return max35(payload.getClientTransactionId(), "clientTransactionId");
    }

    private static String max35(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new MappingException("Required identifier missing: " + field);
        }
        if (value.length() > MAX_35) {
            throw new MappingException(field + " exceeds " + MAX_35 + " characters: " + value.length());
        }
        return value;
    }
}
