package com.capitalone.payx.wireii.pain001;

/**
 * Values the mapping needs that do not come from the payment object: the initiating party name
 * and, later, the Capital One agent identifiers and code tables. Supplied by the calling service,
 * never read from environment-specific configuration inside the library.
 */
public record MappingContext(String initiatingPartyName) {

    public MappingContext {
        if (initiatingPartyName == null || initiatingPartyName.isBlank()) {
            throw new IllegalArgumentException("initiatingPartyName is required");
        }
    }
}
