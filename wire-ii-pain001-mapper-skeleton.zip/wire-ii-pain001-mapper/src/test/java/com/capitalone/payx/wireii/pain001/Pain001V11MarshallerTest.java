package com.capitalone.payx.wireii.pain001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.capitalone.payx.wireii.pain001.v11.model.CustomerCreditTransferInitiationV11;
import com.capitalone.payx.wireii.pain001.v11.model.Document;
import com.capitalone.payx.wireii.pain001.v11.model.GroupHeader95;
import com.capitalone.payx.wireii.pain001.v11.model.PartyIdentification135;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import org.junit.jupiter.api.Test;

class Pain001V11MarshallerTest {

    private final Pain001V11Marshaller marshaller = new Pain001V11Marshaller();

    @Test
    void marshalsAGroupHeaderToTheV11Namespace() {
        Document document = documentWithHeaderOnly();

        String xml = marshaller.toXml(document, false);

        assertThat(xml)
                .contains("urn:iso:std:iso:20022:tech:xsd:pain.001.001.11")
                .contains("<MsgId>MSG-0001</MsgId>")
                .contains("<NbOfTxs>1</NbOfTxs>");
    }

    @Test
    void validationRejectsADocumentWithoutPaymentInformation() {
        Document document = documentWithHeaderOnly();

        assertThatThrownBy(() -> marshaller.toXml(document, true))
                .isInstanceOf(MappingException.class)
                .hasMessageContaining("PmtInf");
    }

    private static Document documentWithHeaderOnly() {
        PartyIdentification135 initiatingParty = new PartyIdentification135();
        initiatingParty.setNm("Capital One");

        GroupHeader95 header = new GroupHeader95();
        header.setMsgId("MSG-0001");
        header.setCreDtTm(Dates.toXmlDateTime(OffsetDateTime.of(2026, 10, 14, 9, 30, 0, 0, ZoneOffset.UTC)));
        header.setNbOfTxs("1");
        header.setInitgPty(initiatingParty);

        CustomerCreditTransferInitiationV11 initiation = new CustomerCreditTransferInitiationV11();
        initiation.setGrpHdr(header);

        Document document = new Document();
        document.setCstmrCdtTrfInitn(initiation);
        return document;
    }
}
