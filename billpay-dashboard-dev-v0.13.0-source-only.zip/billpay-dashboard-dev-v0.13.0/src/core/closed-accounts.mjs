import {matchesSegment} from './segmentation.mjs';
export function segmentCifs(result,segment){
 if(!result.segmentation)throw Error('Run segmentation before exporting segment CIFs.');
 const values=new Set();let missing=0;
 for(const c of result.customers)if(matchesSegment(c.segment,segment)){if(!c.cifs?.length)missing++;for(const cif of c.cifs||[])if(cif)values.add(cif);}
 return {text:[...values].sort().join('\r\n')+(values.size?'\r\n':''),count:values.size,missing};
}
export function createClosedAnalyzer(result){
 const owners=new Map(),inventory=new Map(),unknownAccounts=new Set(),seen=new Set(),removed=new Map(),rows=[],issues=[];
 for(const c of result.customers){inventory.set(c.key,new Set());for(const cif of new Set(c.cifs||[])){if(!owners.has(cif))owners.set(cif,[]);owners.get(cif).push(c);}}
 for(let i=0;i<result.accounts.length;i++){const a=result.accounts[i],set=inventory.get(a.customerKey);if(!set)continue;const number=result._accountNumbers[i];if(number)set.add(number);else unknownAccounts.add(a.customerKey);}
 let duplicates=0,invalid=0,inputRows=0,header=false;
 return {
  line(text,line){
   const value=text.replace(/^\uFEFF/,'').trim();if(!value)return;
   const cells=value.split(',').map(s=>s.trim());
   if(line===1&&cells.length===2&&/^account[ _-]*(number|no)$/i.test(cells[0])&&/^(cif|bnk_cust_nbr)$/i.test(cells[1])){header=true;return;}
   inputRows++;
   if(cells.length!==2||cells.some(v=>!v||/[\x00-\x1f\x7f"\uFFFD]/.test(v))){invalid++;if(issues.length<100)issues.push({line,reason:'Expected exactly account number,CIF with two nonempty unquoted identifiers.'});return;}
   const [account,cif]=cells,key=JSON.stringify(cells);if(seen.has(key)){duplicates++;return;}seen.add(key);
   const candidates=owners.get(cif)||[];let customer=null,status='No Match',reason='CIF is not in the Member customer master.';
   if(candidates.length>1){status='Ambiguous';reason='CIF belongs to multiple Member customers; no removal is assumed.';}
   else if(candidates.length===1){const c=candidates[0];if(inventory.get(c.key).has(account)){customer=c;status='Matched';reason='Exact CIF and account number match in the customer funding inventory.';if(!removed.has(c.key))removed.set(c.key,new Set());removed.get(c.key).add(account);}else reason='Account number is not in the funding inventory for this CIF.';}
   rows.push({cif,account,customer:customer?.name||'NA',customerKey:customer?.key||null,segment:customer?.segment|| (customer?'Not analyzed':'No Match'),status,reason,line,current:customer?inventory.get(customer.key).size:null,post:null});
  },
  finish(name){
   for(const r of rows)if(r.customerKey&&!unknownAccounts.has(r.customerKey))r.post=r.current-removed.get(r.customerKey).size;
   const totals={matched:0,noMatch:0,ambiguous:0,zero:0,remaining:0,unknown:0},zeroCustomers=new Set();
   for(const r of rows){if(r.status==='No Match')totals.noMatch++;else if(r.status==='Ambiguous')totals.ambiguous++;else{totals.matched++;if(r.post===0){totals.zero++;zeroCustomers.add(r.customerKey);}else if(r.post===null)totals.unknown++;else totals.remaining++;}}
   return {rows,summary:{name,inputRows,header,duplicates,invalid,issues,total:rows.length,...totals,matchedCustomers:removed.size,zeroCustomers:zeroCustomers.size}};
  }
 };
}
export async function analyzeClosed(file,result,onProgress=(_bytes=0,_total=0)=>{}){
 const analyzer=createClosedAnalyzer(result),decoder=new TextDecoder();let pending='',line=0,discard=false;
 // Bound a malformed line without reading the entire input into memory.
 for(let offset=0;offset<file.size;offset+=1024*1024){
  const chunk=decoder.decode(await file.slice(offset,offset+1024*1024).arrayBuffer(),{stream:true});
  for(const part of chunk.split(/(?<=\n)/)){
   if(pending.length+part.length>4096)discard=true;
   if(!discard)pending+=part;
   if(part.endsWith('\n')){analyzer.line(discard?'INVALID,LINE,TOO,LONG':pending,++line);pending='';discard=false;}
  }
  onProgress(Math.min(file.size,offset+1024*1024),file.size);
 }
 pending+=decoder.decode();if(pending||discard)analyzer.line(discard?'INVALID,LINE,TOO,LONG':pending,++line);
 return analyzer.finish(file.name);
}
export function closedRows(analysis,request={}){
 const query=String(request.query||'').trim().toLowerCase();
 const rows=analysis.rows.filter(r=>matchesSegment(r.segment,request.segment)&&(!query||[r.cif,r.customer,r.account].some(v=>v.toLowerCase().includes(query)))&&(!request.status||r.status===request.status)&&(!request.post||(request.post==='zero'?r.status==='Matched'&&r.post===0:request.post==='remaining'?r.status==='Matched'&&r.post>0:r.status==='Matched'&&r.post===null)));
 if(request.sortDirection)rows.sort((a,b)=>a.post===null?(b.post===null?0:1):b.post===null?-1:(request.sortDirection==='desc'?-1:1)*(a.post-b.post));
 return rows;
}
export function closedPage(analysis,request={}){
 if(!analysis)return {summary:null,rows:[],total:0,segments:[]};
 const rows=closedRows(analysis,request),page=Math.max(0,Number(request.page)||0);
 return {summary:analysis.summary,total:rows.length,rows:rows.slice(page*100,page*100+100),segments:[...new Set(analysis.rows.map(r=>r.segment))].sort()};
}
export function exportClosed(analysis,request={}){
 if(!analysis)throw Error('Analyze the closed-account file first.');
 const rows=closedRows(analysis,request);return rows.map(r=>r.cif+','+r.account).join('\r\n')+(rows.length?'\r\n':'');
}

