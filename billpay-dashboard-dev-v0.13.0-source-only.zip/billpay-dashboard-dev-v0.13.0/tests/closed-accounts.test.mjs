import test from 'node:test';
import assert from 'node:assert/strict';
import {segmentCifs,createClosedAnalyzer,analyzeClosed,closedPage,exportClosed} from '../src/core/closed-accounts.mjs';
import {pageEntities} from '../src/core/explore.mjs';
function fixture(){
 const customers=[{key:'one',name:'One',cifs:['0001'],segment:'SEGMENT 1.A'},{key:'two',name:'Two',cifs:['0002'],segment:'SEGMENT 2.C'},{key:'three',name:'Three',cifs:['0003'],segment:'SEGMENT 1.B'},{key:'missing',name:'Missing',cifs:[],segment:'MISSING CIF'}];
 const accounts=[{customerKey:'one',account:'00100'},{customerKey:'one',account:'00100'},{customerKey:'one',account:'00200'},{customerKey:'one',account:'00300'},{customerKey:'two',account:'00400'},{customerKey:'three',account:'00500'}];
 return {segmentation:{},customers,accounts,_accountNumbers:accounts.map(a=>a.account),_customers:new Map(customers.map(c=>[c.key,c])),_payees:new Map()};
}
const run=(text,r=fixture())=>{const a=createClosedAnalyzer(r);text.split('\n').forEach((v,i)=>a.line(v,i+1));return a.finish('test.txt');};
test('segment CIF export is unique, complete and preserves zeros, with parent groups',()=>{
 const r=fixture();r.customers.push({key:'duplicate',cifs:['0001'],segment:'SEGMENT 1.A'});
 assert.equal(segmentCifs(r,'GROUP:SEGMENT 1').text,'0001\r\n0003\r\n');assert.equal(segmentCifs(r,'SEGMENT 2.C').text,'0002\r\n');assert.equal(segmentCifs(r).count,3);assert.equal(segmentCifs(r).missing,1);assert.throws(()=>segmentCifs({...r,segmentation:null}),/segmentation/);
});
test('all closed accounts per customer subtract once from distinct funding numbers',()=>{
 const a=run('account number,CIF\n00100,0001\n00200,0001\n00100,0001\n00400,0002');
 assert.equal(a.summary.header,true);assert.equal(a.summary.duplicates,1);assert.equal(a.summary.total,3);assert.deepEqual(a.rows.map(r=>[r.current,r.post]),[[3,1],[3,1],[1,0]]);assert.equal(a.summary.zeroCustomers,1);assert.equal(a.summary.matchedCustomers,2);
});
test('wrong CIF, foreign ownership and missing account never match by account alone',()=>{
 const a=run('00100,0002\n00100,1\n99999,0001');assert.equal(a.summary.noMatch,3);for(const r of a.rows){assert.equal(r.customer,'NA');assert.equal(r.segment,'No Match');assert.equal(r.post,null);assert.equal(r.customerKey,null);}
});
test('ambiguous CIF and unknown funding identifiers never imply zero remaining',()=>{
 const r=fixture();r.customers.push({key:'alias',name:'Alias',cifs:['0001']});r.accounts.push({customerKey:'two'});r._accountNumbers.push('');
 const a=run('00100,0001\n00400,0002',r);assert.equal(a.rows[0].status,'Ambiguous');assert.equal(a.rows[1].post,null);assert.equal(a.summary.zeroCustomers,0);
});
test('malformed lines are reported, not silently parsed as account/CIF pairs',()=>{
 const a=run('one\n,0001\n00100,0001,extra\n"00100",0001\n00100,0001\n');assert.equal(a.summary.invalid,4);assert.equal(a.summary.matched,1);assert.equal(a.summary.issues[0].line,1);
});
test('stream handles BOM, CRLF, final line and bounded oversized line',async()=>{
 const f=new File(['\uFEFFaccount number,CIF\r\n00100,0001\r\n'+'x'.repeat(1024*1024+2)+'\n00400,0002'],'closed.txt');const a=await analyzeClosed(f,fixture());assert.equal(a.summary.total,2);assert.equal(a.summary.invalid,1);assert.equal(a.rows[1].post,0);
});
test('filters/sorting/export cover every page and post count uses full input',()=>{
 const r=fixture();const a=run('00100,0001\n00200,0001\n00400,0002\n99999,0003',r);
 assert.equal(exportClosed(a,{post:'zero'}),'0002,00400\r\n');assert.equal(exportClosed(a,{segment:'GROUP:SEGMENT 1'}),'0001,00100\r\n0001,00200\r\n');assert.equal(closedPage(a,{query:'00200'}).rows[0].post,1);
 assert.deepEqual(closedPage(a,{sortDirection:'asc'}).rows.map(r=>r.post),[0,1,1,null]);assert.deepEqual(closedPage(a,{sortDirection:'desc'}).rows.map(r=>r.post),[1,1,0,null]);
 const many={...a,rows:Array.from({length:205},(_,i)=>({...a.rows[0],account:String(i),line:i+1}))};assert.equal(closedPage(many,{page:1}).rows.length,100);assert.equal(exportClosed(many).trim().split('\r\n').length,205);
});
test('account navigation selects exact number within matched customer',()=>{
 const r=fixture();r.accounts.push({customerKey:'one',account:'001001'});r._accountNumbers.push('001001');const p=pageEntities(r,{entity:'Funding accounts',customerKey:'one',accountExact:'00100'});assert.equal(p.total,2);assert.ok(p.rows.every(a=>a.account==='00100'));
});
