# Validation — 0.13.0

2026-10-23, Windows. 62 automated tests pass. TypeScript and Vite 8.3.4 build pass. Native npm lockfile audit: zero reported vulnerabilities. Registry dependencies only, including community @e965/xlsx 0.20.3 via xlsx alias. No vendor or dist shipped.

New tests cover segment CIF deduplication/leading zeros/parent segments; whole-input multi-account removal; repeated funding and input rows; wrong-CIF/foreign-account nonmatches; ambiguous CIF ownership; unknown account identifiers; malformed and oversized lines; streamed BOM/CRLF/final line handling; combined filters, stable numeric sorting, all-page exports and exact account navigation. Existing 54 tests remain green.

Browser: selected segment 1.B downloaded exactly two synthetic CIFs with leading zeros. Closed-account fixture yielded three matched pairs/two customers, two unmatched pairs, one duplicate and one invalid row. Current/post counts were 3/1, 3/1 and 1/0. Ascending sort placed zero first; Zero remaining export downloaded exactly 000000002,00400 with no header. Matched account navigation opened only account 00400 for its customer. All data used was synthetic; no production files supplied.

Core benchmark: 100,000 synthetic customers, 300,000 distinct funding accounts and 700,000 input lines (400,000 duplicates), approximately 0.825 seconds for indexing, matching and aggregation on Windows Node. This excludes input I/O, browser rendering and exports. No Mac performance claim is made.

No sample files, screenshots, node_modules, vendor archives or dist in the source-only ZIP. Run npm install and npm run build. Actual production-file reconciliation remains a local user validation step. Post Removal models the supplied valid matches only and does not authorize unenrollment or confirm live status.
