# Glossary

Terms used on this project. "Source" says where the meaning comes from. Entries marked (general) are standard industry meanings, not from project files.

Source labels added 2026-10-01: `PIW` = `shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt` (PI planning walkthrough, 2026-09-30 morning). `Deck IMG_NNNN` = a slide of the "OPF Wires Convergence Solution Options" deck, photo in `shelf/files/images/processed/`, transcribed in `shelf/generated/2026-10-01-solution-options-deck/pages/`.

| Term | Meaning | Source |
|---|---|---|
| OPF | FIS Open Payment Framework. FIS-hosted wire processing platform used by Discover. | C4 doc; FIS meeting |
| PEX | Payment Execution. The OPF processing engine Discover already uses. | FIS meeting cue 61-62 |
| POM | Payment Order Manager. OPF layer that exposes the APIs and sits in front of PEX. | FIS meeting cue 65-67; slide 3 |
| Code Connect | FIS API gateway and developer portal, codeconnect.fisglobal.com. | FIS meeting cue 68-69; slide 11 |
| EP | Enterprise Payments, the FIS product family name on the Code Connect tile. | slide 11; Swagger title |
| Universal Execution Origination HostedWires | The Code Connect product tile that contains the payment initiation API. | slide 11 |
| PO | Payment Origination. OPF's screens for keying manual wires. Replaced by OnePay in Phase 1. | Confluence IMG_9856 |
| OVA | Operations Visibility Application. OPF's screens for exception handling; stays through Phase 1. One page also calls PEX "aka OVA", the batch ingestion layer. | Confluence IMG_9856, IMG_9842 |
| XCP | Appears as the "to" system in the API header, alongside OPF. Meaning not yet known. | FIS meeting cue 174 |
| DMPS | Discover Monetary Processing System, as named in the 2022 C4 diagram. Probably the same system Confluence calls MTA. Not confirmed. | C4 doc IMG_9739 |
| DFTP | Discover's managed file transfer. | C4 doc |
| BPM | Business process management system that creates the wire case after the UI submits. | Owner; C4 doc |
| CDF | Discover AWS Cloud Data Fabric. Receives archived OPF data. | C4 doc |
| ECC API | Enterprise Common Components API. In the OFAC call path. | C4 doc IMG_9740 |
| OCP | Platform hosting the Treasury API. Probably OpenShift Container Platform. | C4 doc IMG_9740; expansion assumed |
| Compliance Link | Accuity Compliance Link. The sanctions screening engine behind Discover's OFAC service today. Discover-owned, retiring early 2027; replaced by Bridger in PayX. | Confluence IMG_9869, IMG_9798; C4 doc text |
| CR | Change request opened in the FIS client portal. Required before FIS starts work. | FIS meeting cue 1-6 |
| SOW | Statement of work. Required by FIS even for a POC. | FIS meeting cue 595 |
| pain.001 | ISO 20022 Customer Credit Transfer Initiation. The "send this wire" message. API uses version 11 as JSON. | slide 4; (general) |
| pain.002 / PSR | ISO 20022 Payment Status Report. OPF sends version 10 as XML. | slide 8 |
| camt.054 | ISO 20022 debit/credit notification. OPF sends version 6 as XML, successful payments only. | slide 10 |
| head.001 / BAH | ISO 20022 Business Application Header. Wraps the pain.001 with from, to, message id, date. | slide 4 |
| Interchange, instruction, transaction | OPF's names for pain.001 group header, payment information, and credit transfer transaction. | FIS meeting cue 143-145 |
| Supplementary data | FIS-specific extra fields in the payload at three levels. | slide 4; cue 146-147 |
| UETR | Unique end-to-end transaction reference. Travels with the wire to other banks. | FIS meeting cue 188-206; (general) |
| Idempotency key | Header that makes a retry safe: same key means same payment. | Swagger; cue 164-166 |
| CTR, BTR | Customer transfer and bank transfer. The two wire types the API supports. | FIS meeting cue 215, 233 |
| Drawdown | A request for another bank to send funds from an account held there. Supported in batch, not in the API today. | FIS meeting cue 208-259; (general) |
| ACCP, ACTC, ACSC, ACSP, ACCC, RJCT | pain.002 status codes. See meeting summary section 4. ACTC vs ACCP is inconsistent in the deck. | slides 5 and 9 |
| On-us | Payment between two accounts at the same bank. Not done through OPF at Discover. | FIS meeting cue 461-465 |
| MQ | IBM-style message queue. How OPF delivers async responses. | slides 7-10 |
| MPLS | Private network line. FIS alternative to VPN for operator screen access. | FIS meeting cue 632-637 |
| NPI | Non-public personal information, such as account numbers. | FIS meeting cue 121 |
| FX / JPM | Foreign exchange workflow with JPMorgan, used for international wires. Details pending. | FIS meeting cue 617-626 |
| WS4 | The program code for DFS Wires within the Discover integration. | Confluence IMG_9758 |
| DFS OPF Convergence | The program this project belongs to: moving Discover wires off OPF onto PayX. | Confluence IMG_9758 |
| PIE | Payment Infrastructure Engine. The Confluence space, and also Capital One's older payments engine that Clearwater aims to leave behind. | Confluence IMG_9758, IMG_9791 |
| PayX, PayEx, EP | Payment Exchange. Capital One's payments platform that will process the wires. EP here also stands for Enterprise Payments engineering. | Confluence IMG_9759, IMG_9787 |
| OnePay | Capital One's payment initiation and approval screens. Replaces OPF's PO for manual corporate wires. | Confluence IMG_9759, IMG_9790 |
| GPN | Global Payment Network, also written Global Network Payments. Discover's network businesses; about 95% of wire volume. | Confluence IMG_9759, IMG_9787 |
| DN, Pulse, DCI, SciFi, ACSS, EPP, WorldPay | GPN initiation channels that produce wire instructions. | Confluence IMG_9759, IMG_9797 |
| MTA | Monetary Transfers Application. The Discover mainframe application that builds the flat files sent to OPF today. Must retire by May 17, 2027. | Confluence IMG_9797, IMG_9816 |
| PIX | A separate program that migrates Consumer and BPM wires. Out of scope here. | Confluence IMG_9759, IMG_9807 |
| Pod | One of the delivery teams: Pod 1 Externalize PRAPI, Pod 2 PayX Capabilities, Pod 3 Connect to OPF and Reports, Pod OnePay. | Confluence IMG_9759 |
| ADR | Architecture Decision Record. ADR-0001 to ADR-0004 define the design. | Confluence IMG_9761 |
| Capability N | A numbered line item of Phase 1 scope in ADR-0003, each with its own Confluence page. | Confluence IMG_9799 |
| PRAPI | Payment Request API. PayX's internal API for starting a payment. Contract version PaymentRequest v2.5. | Confluence IMG_9778, IMG_9785 |
| External Payment Requests API | The externalized version of PRAPI that Discover calls. `POST /payments/wires`. | Confluence IMG_9812 |
| DXGW, DevExchange | Capital One's API gateway and registry. The external gateway exposes APIs to partners over the internet. | Confluence IMG_9811, IMG_9813 |
| DFS PayX Submission Service | Service that receives Discover's wire requests, decrypts and tokenizes account numbers, and forwards to PRAPI. | Confluence IMG_9816 |
| Payment Network Originator (PNO) | The component Discover builds to replace MTA and call Capital One's API. Earlier called Network Payment Gateway (NPG) or Payment Network Adaptor. | Confluence IMG_9816, IMG_9837, IMG_9778 |
| Saga | PayX's name for the ordered stages a payment passes through. | Confluence IMG_9832 |
| WIRE-GPN-OUTBOUND | The new PayX saga for these wires. The tracker says it was renamed WIRE-OPF-OUTBOUND. | Confluence IMG_9832, IMG_9761 |
| OPFRAIL, OPFCLEARING | The last two saga stages: Wire II generation, then submission to OPF. `.OPFCLEARING.STOP` is the rejected end state. | Confluence IMG_9832, IMG_9833 |
| Wire II | The Capital One service that generates pain.001 messages. Read as roman numeral two; the font does not distinguish it from "Wire Il". | Confluence IMG_9850 |
| UEAPI | Universal Execution API. FIS's name for the OPF payment initiation API, the same one shown in the FIS meeting. | Confluence IMG_9761, IMG_9844 |
| CodeConnect | Same as Code Connect: FIS's API gateway. | Confluence IMG_9840 |
| SQS | Amazon's queue service. Sits between Wire II and the Submit Request service. | Confluence IMG_9847 |
| ASV | Capital One's unit for an application and its resources. ASVPAYMENTEXCHANGE, ASVOPF, ASVDFSWIRES and ASVONEPAY appear in diagrams. | Confluence IMG_9802, IMG_9818 |
| Cat 2, Cat 3, UCD | Network zones in Capital One architecture diagrams. UCD is an uncontrolled domain, such as Discover or FIS. | Confluence IMG_9818 |
| UTEP | An exception record needed when temporary firewall rules are not part of the baseline. Expansion not given. | Confluence IMG_9841 |
| Turing | Capital One's tokenization service. Replaces account numbers with tokens. | Confluence IMG_9799, IMG_9858 |
| FLE | Field-level encryption. Account numbers are encrypted individually with a Capital One public key. | Confluence IMG_9816, IMG_9820 |
| KRS | Key Rotation Service. Part of the partner encryption pattern, with keys rotating every 30 days. | Confluence IMG_9820 |
| Chamber of Secrets | Capital One's store for private keys. | Confluence IMG_9820 |
| BAN | Bank account number. | Confluence IMG_9816 |
| HSHD | A Capital One data classification applied to account numbers. Expansion not given. | Confluence IMG_9782 |
| Client Registry | PayX's allow-list of which callers may start which payments. | Confluence IMG_9814 |
| Bridger | The sanctions screening engine PayX uses, replacing Compliance Link. | Confluence IMG_9802, IMG_9825 |
| FSIS | A component between OPF and Discover's OFAC service today. Written "FSYS" on one page. | Confluence IMG_9869, IMG_9824 |
| eBAM | Capital One's Nostro account system of record. Has no real-time API yet. | Confluence IMG_9849 |
| CBIS | The system OPF uses with Quantum to qualify accounts today. Capital One cannot connect to it. | Confluence IMG_9790, IMG_9849 |
| Nostro account | An account one bank holds at another bank, used to settle wires. (general) | Confluence IMG_9790 |
| Correspondent bank | A bank that holds the Nostro accounts and sends the wire onward. JPMC, Citi, BNY, BoA today. | Confluence IMG_9797 |
| Correspondent Bank Adaptor | Phase 2 component that connects PayX directly to the banks. | Confluence IMG_9874 |
| NIS | System of record that decides whether a payment goes as ACH or wire and through which correspondent bank. | Confluence IMG_9793 |
| EFG | Enterprise File Gateway. Capital One's file transfer service. | Confluence IMG_9778 |
| OneLake, OneStream, Mercury | Capital One's data lake, its ingestion service, and the component that publishes PayX data to it. | Confluence IMG_9792, IMG_9858 |
| CMOD, OCM | Discover's report store and Oracle Cash Management. Both retire in Phase 1. | Confluence IMG_9798, IMG_9775 |
| Quantum | Treasury management system. DFS Quantum is decommissioned about Q4 2026. | Confluence IMG_9798 |
| BAI2 | A bank statement file format used for settlement and reconciliation. (general) | Confluence IMG_9773, IMG_9837 |
| WSS | The Capital Markets FX system that supplies rates for corporate wires today. | Confluence IMG_9790 |
| FXS Adapter | A Discover FX component described in the JPM interface specification. | Confluence IMG_9830 |
| NCR, OPA | Network Conflict Risk, and the data-segregation mechanism required for it. | Confluence IMG_9792 |
| CRF | Connectivity Review Forum. Approves network connectivity patterns. | Confluence IMG_9795 |
| EPGO, EWO | Capital One operations and governance groups named as owners of several decisions. Expansions not given. | Confluence IMG_9758, IMG_9794 |
| FinX | A Finance program that the wire work depends on for GL and reconciliation. | Confluence IMG_9793 |
| Clearwater | Wires Modernization initiative: all wires processed in PayX with no PIE dependency. The Phase 2 end state. | Confluence IMG_9791, IMG_9871 |
| TOH | Appears in "TOH convergence events", the mechanism moving consumer wires. Expansion not given. | Confluence IMG_9787 |
| pain.008 | ISO 20022 direct debit initiation, named in the ADRs as the drawdown instruction. Phase 2 scope for Wire II. | Confluence IMG_9791, IMG_9874 |
| pain.013 | ISO 20022 request-to-pay message, listed as a possible drawdown need in an older requirements list. | Confluence IMG_9769 |
| LOE | Level of effort. | Confluence IMG_9810 |
| E2E, UAT, SIT | End-to-end testing, user acceptance testing, system integration testing. | Confluence IMG_9758 |
| DevNav Hub | Capital One's internal portal that creates a new component with its Bogiefile and pipeline. | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt cues 411-436 |
| Bogiefile | The pipeline and deployment definition file each Capital One component carries. | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt cue 435; Confluence IMG_9784 |
| PI, PI 26.4 | Program increment, the planning period in scaled agile. 26.4 is the current one. | IMG_9883 tab title |
| ENTPMTS-143224 | Jira epic for Wire II pain.001 generation (Capability 10), owned by the owner. Project "RBT ENT Pmts: Silver Streak", component "Rail - Wires". | IMG_9882 |
| c1-bmad | Jira label on the Pod 3 epics. Meaning not given. | IMG_9882 |
| All Access | Capital One's entitlement request portal, used for Artifactory, IDE licences and similar. | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt cues 565-580 |
| Clearwater Squad | The three pods together, led by Kaushik Ravichandran and Kiran Iruku. Named after the Clearwater initiative. | PIW cues 4-5 |
| Erie, Chesapeake, Hoover, Mackinac, Hudson | Candidate team names for the pods, put to a vote on 2026-09-30. Suggested: Erie for Pod 1, Chesapeake for Pod 2, Hoover for Pod 3. Outcome not known. | PIW cues 53-97 |
| PayX integration service | New service that listens to PayX's event stream for the stage before OPF (tentatively OFAC), calls Wire II, records the OPFRAIL stage, exposes a callback for the FIS answer and then records OPFCLEARING or OPFCLEARING.STOP. Also called the OPF PayX integration service. Who builds it is not settled. | PIW cues 370-372, 413-425, 475-477 |
| Submit to OPF | Same as the Submit Request service: reads pain.001 JSON from SQS, posts it to the FIS API, and reports accepted or rejected back. | PIW cues 397, 418-421 |
| SDP topic | PayX's private event stream. Each PayX service listens on it for a saga type and stage and publishes the next stage. Expansion not given in the sources. | PIW cues 367-369 |
| Fargate | Amazon's service for running containers without managing servers. PayX services are Java Fargate microservices. (general) | PIW cue 367 |
| Rail, rail ASV | A separate ASV that holds the logic for one payment type or outside connection. PayX itself keeps little payment-specific logic and relies on rails. The OPF integration is the "OPF rail". | PIW cues 380-386, 547-552 |
| ASV (expansion) | Cameron expands it as "application service": a logical application. Adds to the ASV entry above. | PIW cues 373, 547-548 |
| ASV OPF | Working name for the new ASV that would hold the FIS integration; labelled "DFS Wires" on the diagram. Planned to face the correspondent banks after FIS and to retire when Capital One connects to Fed and SWIFT directly. The afternoon call chose the PIE ASV for now. | PIW cues 376-379, 843-846 |
| BR ALR (unknown) | The review a new ASV must go through, as transcribed. Contact: Sanjeev. Real name not resolved. | PIW cues 752-753 |
| Ack/nack file | The acknowledgement file MTA gets from OPF today. Cameron likens it to the HTTP code the API returns: it says the input passed technical checks, not that the wire settled. | PIW cues 453, 876-878 |
| Entity ID (Code Connect) | Identifies a customer's instance of OPF in FIS Code Connect. Discover's is 8203. A user must be tied to it for API calls to reach Discover's OPF environment. | PIW cues 1009-1011, 1044-1054 |
| PDASH account | A second Capital One account that production AWS access is tied to. Spelling as transcribed. | PIW cues 918-940 |
| Data share, partner, route | Terms in Capital One's file transfer (EFG). A data share records the agreement to exchange files with an outside party and needs approval. A partner is one end of a transfer with its sign-on details; it can be reused. A route connects partners for one file, so nine reports need about nine routes. | PIW cues 652-682 |
| S3 | Amazon's file storage. Inbound report files land in an S3 bucket before OneStream publishes them to OneLake. (general) | PIW cues 668-670, 685-688 |
| Equinix colocation | Third-party data centres where Capital One has space. A possible home for the FIS VPN devices. (general) | PIW cues 516-517 |
| SAML | Sign-on standard. Okta sends OPF a signed token naming the user's groups, and OPF grants access from those. (general) | PIW cues 818-821 |
| Okta, DFS SSO | Discover's single sign-on. Operations staff use it to reach OPF's PO and OVA screens. Due to be replaced by Capital One SSO if Okta is retired by May 2027; that disposition is not yet known. | PIW cues 499-500, 778-781, 796-800 |
| LeanIX | Application inventory tool used to decide which applications are retained or retired. (general) | PIW cue 779 |
| Disposition | The decision on whether an application is retained, migrated or decommissioned. | PIW cues 778-781 |
| BMAD | A method for running agile work with AI agents. The squad uses its "epics and stories" skill to draft Jira stories. Probably the meaning of the `c1-bmad` label above; inferred. (general) | PIW cues 115-119 |
| KDS (unknown) | What Kiran asked the owner to keep time for. Probably "KTs", knowledge-transfer sessions. | PIW cue 749 |
| Cheetah (unknown) | A basic access Kiran lists beside VPN. Not explained. | PIW cue 738 |
| EA membership (unknown) | An entitlement on the Pod 3 access list, changed from "BA admin membership". Not explained. | PIW cues 916-917 |
| Funding Required | Legend entry on the deck's scope slide, shown in red. Applies to DFS Quantum, Oracle Cash Management, FX (Chase FX for Corp) and FIS dependencies. | Deck IMG_9901, IMG_9911 |
| Commitment Secured, Planning Underway, In Discovery | The other status colours on the same slide: green, yellow and grey. Only the Payment Network Originator is green; CMOD to OneLake is grey. | Deck IMG_9901, IMG_9911 |
| OL | OneLake, as abbreviated on the deck ("COF OL", "EP: Reporting and OL"). | Deck IMG_9902, IMG_9903-2 |
| COF OneLake 1, COF OneLake 2 | Two OneLake boxes on the Phase 1 diagram: 1 receives OPF reports, 2 receives the banks' BAI2 files. | Deck IMG_9902 |
| MSK (unknown) | Label on the PayX box of the Phase 1 diagram. Not explained. Amazon's managed Kafka service has this name; assumed, not confirmed. | Deck IMG_9902 |
| BIC2 reports (unknown) | Named beside OPF Reports on the Phase 1 diagram. Possibly a typo for BAI2. | Deck IMG_9902 |
| CONA | Appears in "from Discover Legal Entity to CONA". Probably Capital One, National Association, the bank legal entity; not expanded on the slide. | Deck IMG_9910 |
| GF | Global Finance, as abbreviated on the deck ("Testing Support Needed GF", "GF/Fin X"). | Deck IMG_9901, IMG_9907 |
| [N], [E] | Deck tags: Net New and Enhance existing. Wire II (pain.001) is [E]; Submit Request to OPF API is [N]. | Deck IMG_9907 |
| ISO deadline | ISO 20022 specifications due Nov 13, 2027, marked "to be confirmed". The deck wants OPF gone before it. | Deck IMG_9908, IMG_9899 |
| AI Pilot | Label beside "EP Wires: 3 engineers" in the deck's executive summary. Not explained. | Deck IMG_9898 |
