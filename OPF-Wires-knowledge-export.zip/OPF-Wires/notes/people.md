# People

Surnames are given where a source shows them. "Source" says how the person was identified. Photo numbers refer to `shelf/generated/2026-09-30-confluence-capture/pages/`.

| Name | Role | Owns | Contact or source |
|------|------|------|---------|
| Owner (Vasanth; vasanth878@gmail.com) | Former DFS, now Capital One. Member of Pod 3. Owns the Wire II epic ENTPMTS-143224. Has built the consumer wire UI and APIs up to BPM. | This workspace; Wire II stories. From 2026-09-30 also the VPN device and DFS Okta follow-up (actions 40 to 42). | Owner, 2026-09-29 and 2026-09-30 sessions. Self-introduction: about seven years at Discover, tech lead for bill pay and consumer wires, full stack, Java (PIW cues 189-197). Zoom tile "Vasanth Senthamarai...", cut off (shelf/files/images/processed/IMG_9912.jpg). |
| Kiran Iruku (byline: Naga Kiran Irukuvarjula) | Architecture and technical lead for the program | PayX architecture and technical delivery across all pods. Led the FIS call for Capital One. | IMG_9758; FIS transcript cue 13 (transcribed as "Karen", corrected by owner). Leads the Clearwater Squad with Kaushik Ravichandran (PIW cue 5). Speaker 6 on the 2026-09-30 morning walkthrough: "Team, Kiran here" (PIW cue 724). |
| Kaushik Ravichandran (owner's spelling: Koushik) | Pod 3 technical lead; pod and team alignment stakeholder | Author of ADR-0001 to ADR-0004. Asked the encryption, version and UETR questions to FIS. | IMG_9758, IMG_9797; FIS transcript Speaker 5 (name supplied by owner). Update 2026-09-30: leads the squad of three pods with Kiran, rather than being one of Pod 3's three engineers (PIW cues 5, 113, 1075). Not to be confused with the second Kaushik, a new Pod 3 engineer, listed below. |
| Cameron Mayor | Engineering lead for the capability write-ups | Author of the Pod pages and most capability pages, and of the architecture diagrams. Investigating NAT for FIS traffic. | IMG_9839, IMG_9840, IMG_9818. Speaker 2 on the 2026-09-30 morning walkthrough: full stack engineer, about four years in wires, mainly SWIFT connectivity; senior developer on Pod 2, supporting Pods 1 and 3 (PIW cues 5-7, 182-184; "Cameron Mayor's screen" in shelf/files/images/processed/IMG_9912.jpg). |
| Rudy Antonini | Program sponsor | | IMG_9758 |
| Jen Crowther | Product owner | | IMG_9758 |
| Dylan Pensabene | Product lead | Requirements for Payment API Externalization, PayX capabilities, OPF API integration. Runs the Pod 3 epics and story sessions; drafts epics with Claude. | IMG_9758; Pod 3 call 2026-09-30 (Speaker 2, probable). Speaker 1 on the morning walkthrough (probable: "everything that Dylan just said", PIW cue 44); covers Pods 1 and 3 (PIW cue 112). |
| Catherine Hu | Product lead | Same; moved the PRDs into Confluence | IMG_9758, IMG_9833. Probably Speaker 3 on the 2026-09-30 morning kickoff, who ran the logistics and rooms (inferred from PIW cue 125). |
| Joe Kataoka (byline: Yasuhiko Kataoka) | Technical program manager | ADR-to-pod alignment; maintains the open questions tracker. Program manager for all three pods; has been running the OPF upgrade and holds the original OPF files. | IMG_9758, IMG_9761. Speaker 4 on the 2026-09-30 morning kickoff: "I am Joe ... TPM for all three pods", about nine months at Capital One (PIW cues 14-25). Surname not said; matched by role. |
| Dan Rahusen | Program management lead | | IMG_9758 |
| Jen Schaffer, Travis Goad | NCR legal and data segregation | Sign-off pending | IMG_9758 |
| Kenneth McCartney | Compliance Link to Bridger cutover | OFAC contingency, Compliance Link decommission | IMG_9758 (written "Kenney McCarthey" in IMG_9807) |
| Andre Barker | Treasury and eBAM | The new real-time eBAM API | IMG_9758 |
| Ryan Kushner | Correspondent banks and capital markets | FX rate sourcing, bank testing timelines | IMG_9758 |
| Jason Kemper | Settlement agent closure; Finance | Settlement-agent role; reconciliation notes on the diagrams | IMG_9758, IMG_9775 |
| Vinod Kumar Gade | Tech lead, Account Qualification and Bank Availability services | | IMG_9823, IMG_9835 |
| Rahul Patel | Reviewer | Questions on BIC and ABA enrichment | IMG_9823 |
| Susan, Scott (surnames not shown) | GPN and MTA subject experts | MTA rules, Nostro determination, file specifications | IMG_9795, IMG_9808 |
| Beatrice (surname unknown) | Capital One/DFS | Opening the FIS change request; holds the Discover entity id; assigned the OVA usage question | FIS transcript cues 9, 579-582; IMG_9856 |
| Praveen (surname unknown) | Capital One/DFS engineer | First to log into Code Connect; access ticket open | FIS transcript cues 512, 547 |
| Subha (surname unknown) | | To confirm how batch failures are seen today. Contact for the OPF VPN devices and for how OPF authorises users; told Cameron on 2026-09-29 that Okta passes group names to OPF in the SAML token. | IMG_9841; PIW cues 760, 818-821 (transcribed "Shubha", "Suba") |
| Jose, Bill (surnames not shown) | Capital Markets | JPM FX API | IMG_9807 |
| Ashwin, Joseph Kim | | Contingency and non-OPF wires decisions | IMG_9808 |
| Raji C | PIX programme | Consumer wires contingency | IMG_9807 |
| John Tilmon | Enterprise Architecture | Author of the partner encryption key rotation pattern | IMG_9810 |
| Robert (also "Bert", "Bob"; surname unknown) | FIS engagement lead | Change request and statement of work; scheduling FIS teams. Awaited on disabling OFAC screening in OPF. | FIS transcript cues 1-17, 673; IMG_9824 |
| Sujith Sukumaran | FIS, API and solution lead | The API walkthrough; drawdown follow-up with FIS product | FIS deck photo IMG_9746; transcript cue 17 |
| Saurabh (probable, surname unknown) | FIS, knows Discover's OPF configuration | pain.002 settings and bank acknowledgements | FIS transcript cues 328-341; identity inferred |
| FIS Code Connect team | FIS API gateway team | Network, allow-lists, encryption options, credentials | FIS transcript cues 37-39; IMG_9841 |
| RM Arcuri | BT Treasury Product Team (DFS), 2022 | Author of the 2022 OPF C4 architecture document | shelf/files/images/processed/IMG_9740.jpg |

More contacts on program and business open questions are listed in `shelf/generated/2026-09-30-confluence-capture/program-digest.md` section 3.
| Two new Pod 3 members (names unclear). Resolved 2026-10-01, see the rows below: Tejaswi Davuluri and a second Kaushik. | Pod 3 engineers who joined around 2026-09-30 | One took the enablement epic, the other the foundation setup epic | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt cues 963, 967; names garbled in the transcript |
| Alex, Sirisha | Named as contacts by Dylan. Alex shared the starter access list with the new Pod 3 members (PIW cues 153, 905). | | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt cue 333 |
| Tejaswi Davuluri (probable match to the voice) | Pod 3 engineer, joined around 2026-09-30. Former Discover, 12 years, mostly the bank side; team handled ACH; based in California. | Took the enablement epic in the afternoon call (probable: Speaker 3 there). Registered on Code Connect with a Discover email on 2026-09-29. | Name from the Zoom tile in shelf/files/images/processed/IMG_9912.jpg. Speaker 5 in PIW: self-introduction transcribed "myself teacher" (cues 212-213); matched by elimination, so probable. |
| Kaushik (surname not shown; a different person from Kaushik Ravichandran) | Pod 3 engineer, joined around 2026-09-30. About six and a half years with Capital One teams (internal and external transfers in RBT, then notifications); new to wires; Java, AWS. Called "Kaushik the contractor" once, in a question; not confirmed. | Took the foundation setup epic in the afternoon call (Speaker 6 there). Already has a PDASH account. | Speaker 7 in PIW: "this is Kaush" (cues 200-208); "Kaushik is the new, joining Pod three" (cue 160); Kiran checks his laptop access (cues 736-748). Zoom tile "Kaushik" in IMG_9912.jpg. Pod3Call cues 75-79. |
| Shantanu (surname unknown) | Capital One | Working out which applications are retained or retired ("disposition"), from a LeanIX standpoint. The person to ask about DFS Okta. | PIW cues 778-779 |
| Sanjeev (surname unknown) | Capital One | Contact for the review process a new ASV must go through (transcribed "BR ALR") | PIW cue 753 |
| Zelma (name uncertain; surname unknown) | Operations | The team that works the OPF exception queues in OVA and signs on through DFS Okta | PIW cues 768, 784 |

`PIW` in this file means `shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt`, the 2026-09-30 morning walkthrough.
