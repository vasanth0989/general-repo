# Timeline

Milestones and dates from project start. Oldest first. Month-only dates mean the source gives no day.

| Date | Milestone | Status | Source |
|------|-----------|--------|--------|
| 2022-05-20 | DFS OPF C4 architecture document v1.0 (RM Arcuri) | Historical | shelf/files/images/processed/IMG_9740.jpg |
| 2026-08-19 | ADR-0001 written (file-based ingestion; since overtaken) | Historical | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9777.md |
| 2026-08-27 | ADR-0002 written (full convergence onto PayX) | Historical | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9787.md |
| 2026-09-10 | ADR-0003 and ADR-0004 written (two-phase plan) | Done | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9797.md, IMG_9871.md |
| 2026-09-28 (inferred) | FIS Payment Initiation API walkthrough meeting | Done | shelf/files/audioRecordings/processed/Opf01-mp3-c4293ac6-bacd.srt |
| 2026-09-28 | Pod pages and capability pages created on Confluence | Done | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9839.md |
| 2026-09-29 | Project created; brief written from owner's description | Done | this session |
| 2026-09-29 | Reviewed DFS OPF C4 document photos; review on shelf | Done | shelf/generated/2026-09-29-opf-architecture-review/ |
| 2026-09-30 | FIS meeting transcript and deck processed; summary, system understanding and glossary written | Done | shelf/generated/2026-09-30-fis-payment-initiation-api-meeting/meeting-summary.md |
| 2026-09-30 | Confluence capture (123 photos) transcribed and digested | Done | shelf/generated/2026-09-30-confluence-capture/README.md |
| 2026-09 | Deck "OPF Wires Convergence Solution Options" dated Sep 2026 (probably the 2026-09-10 revision that ADR-0004 cites; inferred) | Done | shelf/generated/2026-10-01-solution-options-deck/deck-digest.md; shelf/files/images/processed/IMG_9897.jpg |
| 2026-09-29 | Subha told Cameron that Okta passes group names to OPF in the SAML token; Cameron asked a business user what OVA is used for (both said as "yesterday" on 2026-09-30) | Done | shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt cues 489, 818-821 |
| 2026-09-30 (morning) | PI planning day: squad kickoff and Cameron's walkthrough for Pod 3; owner given the VPN and Okta follow-up | Done | shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt; shelf/files/images/processed/IMG_9912.jpg |
| 2026-09-30 | Pod 3 PI planning call (PI 26.4); epics split; owner takes Wire II | Done | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt |
| 2026-10-01 | PI readout; FIS call on drawdowns and pain.008 | Upcoming | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt cues 222, 927 |
| 2026-10-01 | Solution-options deck (15 slides) and the Zoom screenshot transcribed; morning walkthrough processed | Done | shelf/generated/2026-10-01-solution-options-deck/; shelf/generated/2026-09-30-pi-planning-walkthrough/meeting-summary.md |
| 2026-10-02 | Compliance call on sending unencrypted account numbers to FIS | Upcoming | shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt cue 676 |
| 2026-10 | Engineering build window opens (runs to 2027-01; OnePay to 2027-02) | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9800.md |
| 2026-10-16 (inferred) | OPF upgrade release. Joe: "we should be out the door by 10:16". The date reading and the subject are inferred. | Upcoming | shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt cues 21-22 |
| 2026-10-31 | ADR-0003 review-by date, before Phase 1 build lock | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9797.md |
| ~2026-11 to 2026-12 | Capital One target to start integrating with the API ("within the next couple of months" after a POC) | Planned | shelf/files/audioRecordings/processed/Opf01-mp3-c4293ac6-bacd.srt, cue 33 |
| 2026-12 | OPF upgrade (Q4 2026), after which OPF reports support CSV; DFS Quantum decommission. The upgrade may land earlier, see the 2026-10-16 row. | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9858.md, IMG_9798.md |
| 2027-02 | Phase 1 development and system testing complete; Phase 2 build starts | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9758.md, IMG_9870.md |
| 2027-03 | Phase 1 end-to-end and acceptance testing complete | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9758.md |
| 2027-04 | Phase 1 live in production | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9758.md |
| 2027-05-17 | Hard deadline: legacy DFS shutdown, contractual. MTA, Compliance Link, CMOD, OCM, DFS Okta and DFS VPN retired. | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9758.md, IMG_9804.md |
| 2027-05 (day TBC) | Hard deadline: all DFS-hosted components in cloud; mainframe wire path must be gone | Superseded by the 2027-05-17 row | owner's description, 2026-09-29 |
| 2027-07 | Phase 2 development and system testing complete | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9758.md |
| 2027-08 | Phase 2 end-to-end and acceptance testing complete | Upcoming | shelf/files/images/processed/IMG_9908.jpg |
| 2027-09 | Phase 2 live: all banks cut over to PayX settlement | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9876.md |
| 2027-12 | OPF decommission (Q4 2027), gated on the FIS contract extension | Upcoming | shelf/generated/2026-09-30-confluence-capture/pages/IMG_9759.md |
| 2027-11-13 (to be confirmed, per the slide) | ISO 20022 specifications due; the deck's reason to be off OPF before then | Upcoming | shelf/files/images/processed/IMG_9908.jpg, IMG_9899.jpg |
| TBD | Later phase: move off FIS OPF to Capital One in-house payment exchange | Superseded: now Phase 2, see 2027-09 | owner's description, 2026-09-29 |
