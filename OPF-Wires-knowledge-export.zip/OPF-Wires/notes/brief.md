# Brief

Revised 2026-09-30 from the Confluence capture. The original brief from 2026-09-29 is kept at the bottom, marked superseded.

Sources: `shelf/generated/2026-09-30-confluence-capture/program-digest.md` and `pod3-digest.md`; FIS meeting summary in `shelf/generated/2026-09-30-fis-payment-initiation-api-meeting/`. Photo numbers such as (9797) refer to the transcriptions in the capture folder.

**The program**
DFS OPF Convergence, program code WS4 "DFS Wires", at Capital One. It moves Discover's GPN and Corporate wires off FIS OPF and onto Capital One's PayX and OnePay, in two phases. (9758)

**Goal**
Move Discover's GPN and Corporate wires from FIS OPF onto Capital One's PayX before the May 17, 2027 shutdown of Discover-owned systems. The owner's pod builds the Phase 1 bridge from PayX to OPF.

**The owner's part**
The owner is in Pod 3, "Connect to OPF and Reports". In Phase 1, Pod 3 builds the bridge from PayX to FIS OPF: generate a pain.001 version 11 message as JSON, submit it to the FIS API, and bring the accepted or rejected outcome back. Pod 3 also owns reports to OneLake, VPN replacement, single sign-on migration, international drawdowns, flat files consolidation and corporate account qualification. (9759, 9839)

**Why now**
Every Discover-owned application must be off Discover infrastructure by May 17, 2027. That includes the mainframe application MTA, which feeds OPF today. OPF itself is FIS-hosted and may stay for a while, which is what makes a phased plan possible. (9797)

**Scope**
- In: GPN wires and Corporate wires. (9759)
- Out: Consumer and BPM wires, which belong to the PIX program. Direct bank connectivity, which is Phase 2. GL, Nostro and Recon+, which Finance and Treasury own. (9759)

**Dates**
- Build window: October 2026 to January 2027 (9800)
- Phase 1 development and system testing complete: February 2027
- End-to-end and acceptance testing complete: March 2027
- Phase 1 go-live: April 2027
- Legacy Discover shutdown: **May 17, 2027**, hard and contractual
- Phase 2 go-live: September 2027. OPF decommission: Q4 2027. (9758)

**Constraints**
- The FIS contract must be extended to about Q4 2027. Not yet secured. Without it Phase 1 is not deliverable. (9798)
- FIS will not start work without a change request in its client portal and a statement of work, including for a proof of concept. (FIS meeting, cues 1-6, 595)
- The FIS API takes pain.001 version 11 as JSON only, and does not support drawdowns today. (9850, 9842; FIS meeting)
- FIS offers encryption in transit only. Its gateway is internet-facing. (FIS meeting, cues 81-121; 9841)
- Pod 3's OPF connection is transitional. It is removed in Phase 2. (9873)
- Nine engineers across three pods, three each. (9761)
- Added 2026-10-01: Pod 3 also coordinates end-to-end testing for all three pods. (source: shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt, cues 465-466)
- Added 2026-10-01: the solution-options deck marks the FIS integration ("FIS dependencies") as Funding Required. (source: shelf/files/images/processed/IMG_9901.jpg)
- All four architecture decision records are still "Proposed". (9797, 9871)

**Success criteria for Phase 1** (9804)
- PayX submits wires to OPF over the API and consumes the acknowledgements.
- OFAC screening runs in PayX, with Compliance Link retired.
- Operations staff initiate corporate wires in OnePay.
- MTA, Compliance Link, DFS Quantum, CMOD, OCM, DFS Okta and the DFS VPN appliances are all retired by May 17, 2027.

**Open questions**
- Is the FIS contract extension to Q4 2027 secured? Phase 1 depends on it. (9798)
- How will status messages reach Capital One? The design assumes pain.002 over MQ, which Discover does not have today. (9847; FIS meeting)
- Which pain.002 status means accepted, and which reports will FIS switch on? (FIS meeting; 9842)
- How are drawdowns handled? They are in scope, the FIS API does not support them, and the capability page is blank. (9855, 9842)
- How are account numbers protected on the way to FIS, given no field-level encryption? (9841)
- What are the FIS rate limits and the right batch size at GPN volume? (9806)
- What paperwork, lead times, allow-lists and firewall ports does FIS need? (9841)
- When will the eBAM real-time API exist? Capability 4 is blocked on it. (9849)
- Which of FIS's three VPN options will be used for OVA access? (9856)
- Does Flat Files consolidation still have any scope? (9800)
- Added 2026-10-01: after OPF's immediate answer, how does PayX learn what happened to a wire? No link out of OPF exists and one may not be feasible by May. (source: shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt, cues 437-449, 866-874)
- Added 2026-10-01: is OVA still needed, and what happens to the FIS VPN devices and to DFS Okta by May 2027? (source: shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt, cues 507-520, 759-805)
- Added 2026-10-01: new ASV now or later, and is the OPF pain.001 generation the existing Wire II service or a new one? (source: shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt, cues 752-758, 843-861)

The full list in context is in `notes/system-understanding.md`. The program's own tracker has 29 rows (9761 to 9770).

**The owner's own work**
- Owns Jira epic ENTPMTS-143224, Wire II pain.001 Generation: payment object to pain.001.001.11 XML, XML to JSON, publish to SQS, acknowledge PayX. Ten stories drafted in `shelf/generated/2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/stories-jira.md`. (source: shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt, cue 960; shelf/files/images/processed/IMG_9882.jpg)
- Pod 3 is Kaushik Ravichandran as tech lead, the owner, and two members who joined around 2026-09-30. Their names are not yet known. [Superseded 2026-10-01 by the next line.]
- Pod 3's three engineers are the owner, Tejaswi Davuluri (probable) and a newly joined Kaushik whose surname is not known. Kaushik Ravichandran and Kiran Iruku lead the whole squad of three pods; Cameron Mayor is on Pod 2 and supports Pod 3. (source: shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt, cues 4-7, 157-160, 200-213; shelf/files/images/processed/IMG_9912.jpg)
- Since 2026-09-30 the owner also has the VPN device and DFS Okta follow-up: actions 40 to 42. (source: shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt, cues 759-782, 828-839)
- Current state and next steps: `notes/handoff.md`.

---

## Original brief, 2026-09-29 (superseded)

Kept for history. Written from the owner's first description, before the Confluence material was available.

- Goal as then understood: send Discover outbound wires to FIS OPF through the FIS REST API instead of mainframe flat files, so the mainframe layer can be retired before the May 2027 cloud deadline.
- Flow as then understood: user authenticates in the frontend; a BPM process creates a case; the case goes through a mainframe layer; the mainframe sends flat files to OPF in batch; OPF forwards the wire to a correspondent bank.
- Scope as then understood: replacing FIS OPF with Capital One's in-house payment exchange was "a later phase, out of scope".

What turned out differently: the BPM path is the consumer wire path, which is outside this program. The program covers GPN and Corporate wires. Leaving OPF is Phase 2 of the same program. See "What changed" in `notes/system-understanding.md`.
