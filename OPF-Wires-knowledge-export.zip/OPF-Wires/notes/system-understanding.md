# System understanding

The living model of how DFS wires work and what this project changes. Written for someone who knows the UI-to-BPM part and is new to everything after it. Mark what is confirmed and what is inferred.

Last updated: 2026-10-01, after the Pod 3 PI planning call of 2026-09-30. This revision replaces the earlier model. What changed is listed at the bottom.

Added later on 2026-10-01: the morning PI planning walkthrough of 2026-09-30 and the solution-options deck. See the two sections before "What nobody has answered yet". The stage tables above them are unchanged except for one note on Phase 1 row 8.

Sources:
- Confluence capture, 123 pages: `shelf/generated/2026-09-30-confluence-capture/program-digest.md` and `pod3-digest.md`. Photo numbers such as (9797) refer to `pages/IMG_9797.md` there.
- FIS meeting, 2026-09-28: `shelf/generated/2026-09-30-fis-payment-initiation-api-meeting/meeting-summary.md`
- DFS C4 document, May 2022: `shelf/generated/2026-09-29-opf-architecture-review/opf-architecture-review.md`
- Owner's description, 2026-09-29
- PI planning walkthrough, 2026-09-30 morning: `shelf/generated/2026-09-30-pi-planning-walkthrough/meeting-summary.md`. Cues such as (cue 437) refer to `shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt`.
- Solution-options deck, Sep 2026: `shelf/generated/2026-10-01-solution-options-deck/deck-digest.md` and `pages/`. Photo numbers 9897 to 9912 refer to that folder.

## The project in three sentences

Discover's wires run through OPF, a platform hosted by FIS, fed by a Discover mainframe application called MTA. Every Discover-owned system must be off Discover infrastructure by May 17, 2027, so Capital One is moving wire processing into its own platform, PayX, in two phases. In Phase 1, PayX does the processing and hands each wire to OPF over an API; in Phase 2, Capital One connects to the banks itself and OPF is switched off.

## Three kinds of wire, and which ones this project covers

| Kind | Share | Started by | In this project? |
|---|---|---|---|
| GPN wires (Discover Network, Pulse, DN, SciFi/ACSS, WorldPay) | About 95% of volume | Network systems, in bulk | Yes |
| Corporate wires | Small volume, high value | Operations staff, manually, from templates | Yes |
| Consumer and BPM wires | | Customers, through the UI and BPM | **No. Separate program called PIX.** |

Source: 9759, 9787.

This matters for the owner: the UI-to-BPM flow the owner has worked on is the consumer path, which is outside this program. The owner's pod works on a different part of the wire estate.

## Today: how a GPN wire travels

| # | Stage | What happens | Owner | Confidence |
|---|---|---|---|---|
| 1 | Channels | Pulse, EPP, SciFi, ACSS, WorldPay, DN produce wire instructions in fixed-width files | Discover GPN | Confirmed (9797, 9778) |
| 2 | MTA on the mainframe | Monetary Transfers Application validates, picks the Nostro account, and builds flat files | Discover | Confirmed (9797, 9816) |
| 3 | File to FIS | Flat file, PGP-encrypted, sent to OPF | Discover to FIS | Confirmed (FIS meeting; 9841) |
| 4 | OPF batch layer | Turns the file into pain.001 messages | FIS | Confirmed (FIS meeting) |
| 5 | OPF processing | Enrichment, validation, risk filters, routing rules, value dating, FX | FIS | Confirmed (9797) |
| 6 | Sanctions screening | OPF calls Discover's OFAC service, which uses Compliance Link; the answer returns through Kafka and a Treasury API | Discover and FIS | Confirmed (9869; matches the 2022 C4 diagram) |
| 7 | Out to banks | OPF sends files to correspondent banks JPMC, Citi, BNY, BoA. They hold the Nostro accounts and settle. | FIS, banks | Confirmed (9797, 9818) |
| 8 | Acknowledgement | Banks return an ack or nack file. On a nack, OPF still shows the payment as processed. | Banks, FIS | Confirmed (9793, FIS meeting) |
| 9 | Reports | Nine PDF reports go to CMOD; reconciliation uses OCM | Discover | Confirmed (9858) |
| 10 | Operations access | Staff use OPF's PO screens to key corporate wires and OVA screens for exceptions, over a Discover VPN with Discover sign-on | Discover | Confirmed (9856, 9857) |

## Phase 1: what it becomes by April 2027

| # | Stage | What happens | Pod | Confidence |
|---|---|---|---|---|
| 1 | Discover side | Discover builds a Payment Network Originator that replaces MTA and calls Capital One's API over the internet, with account numbers encrypted | Discover | Confirmed (9816, 9818) |
| 2 | Front door | External Payment Requests API on the DevExchange external gateway. OAuth. One wire per call. | Pod 1 | Confirmed (9811 to 9813) |
| 3 | Submission service | Checks the caller, de-duplicates, validates, decrypts, tokenizes, forwards to the internal Payment Request API | Pod 1 | Confirmed (9816, 9817) |
| 3b | Manual wires | Operators create corporate wires in OnePay instead of OPF's PO screens | Pod OnePay | Confirmed (9802) |
| 4 | PayX saga | `INIT`, `CLIENTREGISTRY`, `BANKVALIDATION`, `ACCOUNTQUALIFICATION`, `OFAC`, then the two OPF stages | Pods 1 and 2 | Confirmed (9832) |
| 5 | **Wire II** (`OPFRAIL`) | Builds a pain.001 version 11 message as JSON and puts it on a queue | **Pod 3** | Confirmed (9850) |
| 6 | **Submit Request to OPF** (`OPFCLEARING`) | Takes the message off the queue and calls the FIS API through CodeConnect | **Pod 3** | Confirmed (9847) |
| 7 | OPF | Receives the wire by API instead of file. Still does routing, value dating, bank delivery. | FIS | Confirmed (9799) |
| 8 | Status back | FIS returns 202 at once, then a pain.002 over MQ. The submit service tells PayX accepted or rejected. | **Pod 3** | Designed; not validated with FIS (9763). Note 2026-09-30: the 202 answer is solid; the pain.002 over MQ part is in doubt (cues 866-874). See the walkthrough section below. |
| 9 | Banks | Unchanged. OPF sends files to the same banks. | FIS | Confirmed |
| 10 | Reports | OPF sends CSV through EFG into OneLake | **Pod 3** | Confirmed as design (9858) |
| 11 | Operations access | OVA stays for exceptions, on a Capital One network path and sign-on. PO is retired. | **Pod 3** | Decision pending FIS options (9856) |

## Phase 2: by September 2027

Capital One builds a Correspondent Bank Adaptor and connects to six banks directly, one bank at a time. Then the Phase 1 bridge to OPF is removed and the FIS contract ends. Most of Pod 3's OPF connection work is deleted at that point. (9873, 9874)

## Where the owner sits

The owner is in **Pod 3: Connect to OPF and Reports** and owns the **Wire II epic, ENTPMTS-143224** (stage 5 in the Phase 1 table above). Detail on the pod is in `pod3-digest.md`; the stories are in `shelf/generated/2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/`.

Added 2026-10-01: Pod 3's three engineers are the owner, Tejaswi Davuluri (probable) and a newly joined Kaushik, surname unknown. Kaushik Ravichandran and Kiran Iruku lead all three pods as the "Clearwater Squad"; Cameron Mayor sits in Pod 2 and supports Pod 3 (cues 4-7, 157-160; 9912). Since 2026-09-30 the owner also carries the VPN device and DFS Okta follow-up (cues 759-782, 828-839).

## What the Pod 3 call of 2026-09-30 added

Source: `shelf/generated/2026-09-30-pod3-pi-planning-call/meeting-summary.md`.

| Topic | What was said | Confidence |
|---|---|---|
| Wire II output | Build pain.001 V11 as XML, then convert to JSON. Phase 2 keeps the XML and drops the JSON step. | Decided by the tech lead (cue 872-879) |
| Build order | OPF API registration and Code Connect access first; Wire II in parallel; submit service third. | Decided (cue 903-916) |
| Where the code lives | Two repositories: Wire II, and Submit to OPF with the connection. Possibly a third for infrastructure such as SQS. Created through DevNav Hub. PIE ASV for now; a new ASV is a separate epic. | Decided (cue 415-497) |
| Stack | Java 21, Maven. | Decided (cue 555-561) |
| Who calls the FIS API | Not PayX itself. PayX hands off to the Wire II and OPF integration layer. | Confirmed (cue 603-610) |
| Status back to PayX | The submit service must send FIS's response on to PayX; Cameron is to expose an endpoint for it. | Stated (cue 732-763) |
| Drawdown volume | 250 to 350 a day, from DN and DCI, to BNY, JPMC and Citi. | Stated in the call (cue 278, 330) |
| Drawdown fallback | A batch file over EFG to OPF's batch component, or manual upload at bank portals. | Options only |
| Code Connect registration | Capital One ids are rejected; a Discover id is needed. One application per team; client id and secret are shared. | Observed (cue 22-44, 452-464) |
| Encryption to FIS | None at field level. Product doubts cyber will approve. Bill Pay got a workaround on the basis of encryption at rest plus mutual TLS. | Open (cue 612-687) |
| Capability grouping | Confluence pages regrouped by area: External API, PayX capabilities, OPF integration, OnePay. Account Qualification for Corporate moved under OnePay. Flat Files consolidation and Business Rules not needed. | Decided (cue 62-202) |
| OVA | Unclear whether it is used for all exception handling or only OFAC exceptions. | Open (cue 311-329) |

## What the PI planning walkthrough of 2026-09-30 (morning) added

Source: `shelf/generated/2026-09-30-pi-planning-walkthrough/meeting-summary.md`. This session came before the Pod 3 call in the section above; where they differ, the afternoon is the later word.

**The Pod 3 chain, in more detail than the Phase 1 table**

| # | Step | What happens | Confidence |
|---|---|---|---|
| 1 | PayX stages | PayX services are Java Fargate microservices on a private event stream (the "SDP topic"). Each listens for a saga type and stage and publishes the next. | Stated by Cameron (cues 367-369) |
| 2 | PayX integration service | New. Listens for the OFAC stage, tentatively the last before OPF. | Stated; "tentatively" (cues 370, 413-415) |
| 3 | Call to Wire II | Synchronous REST call, registered on Exchange because it crosses ASVs. | Stated (cues 393-396, 416) |
| 4 | Wire II | Builds the pain.001 JSON from the PayX payment object, puts it on SQS, returns OK. | Stated (cues 388-397) |
| 5 | OPFRAIL stage | Recorded by the PayX integration service once Wire II returns OK. | Stated (cue 417) |
| 6 | Submit to OPF | Reads SQS, posts to the FIS API. One call per payment. Over the general internet; no VPN or sign-on dependency. | Stated (cues 397, 304-308, 700-703) |
| 7 | Callback | Submit to OPF calls an endpoint on the PayX integration service with accepted or rejected. | Stated (cues 418-421) |
| 8 | OPFCLEARING or OPFCLEARING.STOP | Recorded by the PayX integration service. | Stated (cues 424-425) |

**Other points**

| Topic | What was said | Confidence |
|---|---|---|
| Status after the immediate answer | Not designed. Bank acknowledgements reach OPF only; nothing connects OPF outward; a new link needs FIS effort and a statement of work and may not be feasible by May; business value to be shown. Ideas: use the OneLake reports or Pod 2's reconciliation. | Open. Stated by Kiran and Cameron (cues 437-449, 866-874) |
| What the immediate answer means | Like today's ack/nack file to MTA: the input passed technical checks. A wire can still be stopped later by a filter or routing rule in OPF. | Cameron's understanding (cues 443-445, 451-453, 876-878) |
| Who builds the PayX integration service | "Mostly your pod" in the morning; in the afternoon Cameron was said to be exposing the endpoint. | Unclear (cues 475-477; Pod3Call cue 733) |
| New ASV | Kiran leaned to a separate ASV ("ASV OPF"): FIS now, correspondent banks in Phase 2, retired when Capital One connects to Fed and SWIFT directly. The afternoon chose the PIE ASV for now. | Not settled (cues 376-379, 752-758, 843-846) |
| Wire II | An existing service in the PIE ASV that handles all legacy Capital One wires. Reuse or build new was left open in the morning; the afternoon chose to extend the existing converter. Superseded 2026-10-05: the owner says there is no existing v9 converter and the V11 converter is a brand-new Gradle library. | Owner's statement stands (2026-10-05); the ASV question is still open |
| Reports today | Nine reports, a mix of PDF and CSV, sent through DFTP to CMOD. This refines "nine PDF reports" in the Today table. | Stated (cues 603-606, 632-635) |
| Reports in Phase 1 | All CSV after the OPF upgrade; through EFG into an S3 bucket; OneStream publishes to OneLake. About nine routes. Frequency believed daily. Unknown whether the CSV switch is a setting or an FIS ticket. | Design stated; details open (cues 607-624, 639-688) |
| OPF upgrade | "Out the door by 10:16", read as 2026-10-16. Earlier than the "Q4 2026" in the notes. | Inferred (cues 21-22) |
| PO and OVA access today | Discover sign-on (Okta) over physical VPN devices supplied by FIS in the Discover data centre. FIS will not take this traffic over the open internet. | Stated (cues 499-501, 518-520) |
| PO | Not needed once OnePay takes corporate wire entry. Kiran wants access considered for contingency. | Stated (cues 502-506, 761) |
| OVA | Kiran: still needed for the risk filter, duplicate and repair queues that stay in OPF. Cameron: waiting for the business. | Not confirmed (cues 507-512, 765-777) |
| How OPF authorises users | Okta evaluates the user's groups and passes the group names in the SAML token. Privileges inside OPF stay as they are. | Reported from Subha by Cameron (cues 812-821) |
| Code Connect entity | Discover's entity id is 8203; it ties a user to Discover's OPF instance. | Stated (cues 1009-1011, 1044-1054) |
| End-to-end testing | Pod 3 coordinates it for all three pods. | Decided (cues 465-466) |
| AWS accounts | One shared dev account for enterprise payments; each ASV has its own QA and prod accounts. | Stated (cues 954-957) |

## What the solution-options deck added

Source: `shelf/generated/2026-10-01-solution-options-deck/deck-digest.md`.

| Topic | What the deck shows | Photo |
|---|---|---|
| The exemption | "Vendor-hosted applications such as OPF, hosted externally on FIS, are exempt" from the May 2027 mandate. | 9898 |
| Staffing | DFS Integration 6 engineers; EP Wires 3 engineers (AI Pilot). Three pods of three. | 9898, 9909 |
| What stays in OPF in Phase 1 | Payment validation, filters and checks; holiday calendar and value date; routing rules and bank integration; OPF reports. | 9902 |
| What leaves OPF in Phase 1 | PO (to OnePay), enrichment, screening, FX integration. | 9900 against 9902 |
| Two OneLake landings | OPF reports go to "COF OneLake 1"; the banks' BAI2 files go to "COF OneLake 2" and on to OCM/FinX. | 9902 |
| Funding | Four items are marked Funding Required in red: DFS Quantum, Oracle Cash Management, FX (Chase FX for Corp), FIS dependencies. | 9901, 9911 |
| Reports ownership on the deck | CMOD to COF One Lake is "In Discovery (TBD)". The walkthrough says Pod 3 owns it. | 9901; cue 230 |
| Pod 3 on the deck | "OPF API integration (pain.001 out, acknowledgements in)"; smallest scope, finishes first, then joins PayX capabilities. | 9909 |
| Drawdowns on the deck | "[N] OB Intl Drawdowns" sits under OnePay. | 9907 |
| Wire II on the deck | Phase 1 "[E] Wire II (pain.001)"; Phase 2 "[E] Wire II — pain001 / pain008". | 9907, 9908 |
| Operations footprint | 151 OPF operations users and 500 templates. | 9907 |
| Phase 2 dates | Dev and SIT July 2027; E2E and UAT Aug 2027; go-live Sep 2027; ISO 20022 specs due Nov 13, 2027 (to be confirmed). | 9908 |
| Open decisions | NCR, Capital One as settlement agent, FX rates, contingency and DCI to Citi, non-OPF wires, PIX contingency. | 9910 |

## What nobody has answered yet

Program level:
1. The FIS contract extension to Q4 2027 is not secured. Phase 1 cannot deliver without it.
2. The two-phase plan rests on reading the deal as "vendor-hosted systems need not move". Not confirmed in writing.
3. All four ADRs are still "Proposed".

Pod 3 level:
4. MQ connectivity for status messages does not exist yet for Discover.
5. Which pain.002 status means accepted, and which reports FIS will switch on.
6. Drawdowns: in scope, unsupported by the FIS API, capability page blank.
7. Account numbers travel to FIS without field-level encryption. Pending FIS Code Connect.
8. Rate limits and batch size at GPN volume.
9. FIS paperwork, lead times, allow-lists, firewall ports, secret rotation.
10. The eBAM real-time API that Capability 4 needs does not exist.
11. Which of the three VPN options FIS offers will be used.
12. Whether Flat Files consolidation still has any scope.

Added 2026-10-01, from the morning walkthrough of 2026-09-30:
13. How PayX learns what happens to a wire after OPF's immediate answer. This sharpens item 4: the question is now whether any link out of OPF is built for Phase 1 at all.
14. Whether OVA is retained, and so whether the VPN devices must move to Capital One. This sits before item 11.
15. Whether DFS Okta is retired by May 2027 and who drives the move to Capital One sign-on.
16. New ASV now or later, and whether the OPF pain.001 generation is the existing Wire II service or a new one.
17. Who owns the PayX integration service.
18. Report details: frequency, schema and sensitivity of each of the nine, and how the switch to CSV is made.
19. How a Capital One user is tied to Discover's entity 8203 in Code Connect.

## What changed from the earlier model (2026-09-29 and early 2026-09-30)

| Earlier understanding | Now |
|---|---|
| The project replaces the mainframe hop on the consumer path: UI, BPM, mainframe, OPF | Consumer and BPM wires are out of scope. The project covers GPN and Corporate wires. |
| "The mainframe layer" was assumed to be the system the 2022 C4 diagram calls Discover Monetary Processing System | Confluence names it Monetary Transfers Application (MTA). Probably the same system under a different name. Not confirmed. |
| Who calls the FIS API was unknown | A Pod 3 service, fed by Wire II through a queue |
| What replaces the mainframe logic was unknown | Discover builds a Payment Network Originator; Capital One's PayX takes over validation and screening |
| Deadline "by May", assumed May 2027 | May 17, 2027, hard and contractual |
| Leaving OPF was "a later phase, out of scope" | It is Phase 2 of the same program, targeted September 2027 |
| OVA and PO were unknown terms | OVA is Operations Visibility Application, also described as the PEX batch ingestion layer. PO is Payment Origination. |
