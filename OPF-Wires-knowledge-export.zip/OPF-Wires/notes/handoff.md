# Handoff: where things stand

Read this first in a new session, right after the workspace and project `CLAUDE.md`. It says what exists, what was done, how the owner wants things done, and what comes next. Update it at the end of every session; keep the previous state under "Session log".

Last updated: 2026-10-01, during the second session.

## In two paragraphs

The owner, Vasanth, is an engineer in **Pod 3** of Capital One's **DFS OPF Convergence** program (WS4, DFS Wires). The program moves Discover's GPN and Corporate wires off FIS OPF onto Capital One's PayX in two phases: Phase 1 live April 2027 with OPF kept as the bank gateway by API, legacy Discover shutdown on **May 17, 2027**, Phase 2 live September 2027, OPF off in Q4 2027. Pod 3 builds the Phase 1 bridge from PayX to OPF. The three pods together are the "Clearwater Squad", led by Kaushik Ravichandran and Kiran Iruku.

Vasanth personally owns Jira epic **ENTPMTS-143224, Wire II pain.001 Generation**: turn the PayX payment object into pain.001.001.11 XML, convert that to JSON, publish to SQS, acknowledge PayX. Ten stories were drafted for it on 2026-09-30 and were about to be pasted into Jira. PI 26.4 planning readout was due 2026-10-01. Since the morning of 2026-09-30 he also has the **VPN device and DFS Okta follow-up** (actions 40 to 42).

## Reading order for a cold start

| Order | File | Why |
|---|---|---|
| 1 | `notes/handoff.md` | This file |
| 2 | `notes/system-understanding.md` | How wires work today, in Phase 1 and in Phase 2; what is confirmed |
| 3 | `shelf/generated/2026-09-30-confluence-capture/pod3-digest.md` | Pod 3's nine capabilities in detail, tied to the FIS meeting |
| 4 | `shelf/generated/2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/stories-jira.md` | The stories the owner is taking into Jira |
| 5 | `notes/actions.md` | 53 items, 45 open; who owes what. Actions 40 to 44 and 53 are the owner's newest. |
| 6 | `notes/glossary.md` | About 135 terms. Check here before explaining any acronym. |
| as needed | `shelf/generated/2026-09-30-pi-planning-walkthrough/meeting-summary.md` | PI planning day, morning: Cameron's walkthrough of the whole Pod 3 design, the open status path, VPN and Okta |
| as needed | `shelf/generated/2026-09-30-pod3-pi-planning-call/meeting-summary.md` | PI planning day, afternoon: epics, build order, design choices |
| as needed | `shelf/generated/2026-10-01-solution-options-deck/deck-digest.md` | The leadership deck behind the two-phase plan, with colour coding |
| as needed | `shelf/generated/2026-10-01-opf-decommission-strategy/opf-decommission-strategy.md` | What is retired, why and in what order; the shareable version |
| as needed | `shelf/generated/2026-09-30-confluence-capture/program-digest.md` | Whole program: people, dates, ADR history, open questions |
| as needed | `shelf/generated/2026-09-30-fis-payment-initiation-api-meeting/meeting-summary.md` | FIS API walkthrough, 2026-09-28 |
| to look something up | `shelf/generated/2026-09-30-confluence-capture/pages/IMG_NNNN.md` and `shelf/generated/2026-10-01-solution-options-deck/pages/IMG_NNNN.md` | 123 Confluence transcriptions and 16 deck and Zoom transcriptions. Grep them. |

## What is on the shelf

**Source material, all in `processed/`:**
- `shelf/files/audioRecordings/processed/Opf01-...srt`: FIS Payment Initiation API meeting, 2026-09-28.
- `shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-...srt`: PI planning walkthrough, 2026-09-30 morning. Squad kickoff, then Cameron's Pod 3 walkthrough. 1 h 55 min.
- `shelf/files/audioRecordings/processed/Pod3Call-...srt`: Pod 3 PI planning call, 2026-09-30 afternoon.
- `shelf/files/images/processed/`: 160 photos. IMG_9735 to 9740: 2022 DFS C4 document. IMG_9742 to 9755: FIS deck and Swagger. IMG_9758 to 9881: Confluence space. IMG_9882, 9883: the Jira epic. IMG_9897 to 9911: the "OPF Wires Convergence Solution Options" deck, Sep 2026 (IMG_9903 is named `IMG_9903-2.jpg`). IMG_9912: Zoom screenshot of the 2026-09-30 morning walkthrough.

Nothing is waiting outside `processed/`.

**Produced:**
- `2026-09-29-opf-architecture-review/`: reading of the 2022 C4 document. Historical; superseded by Confluence.
- `2026-09-30-fis-payment-initiation-api-meeting/`: FIS meeting summary and deck-versus-meeting comparison.
- `2026-09-30-confluence-capture/`: program digest, Pod 3 digest, index, 123 transcriptions.
- `2026-09-30-pi-planning-walkthrough/`: `meeting-summary.md` for the morning session of 2026-09-30, with a deck-versus-meeting table and a morning-versus-afternoon table.
- `2026-09-30-pod3-pi-planning-call/`: Pod 3 afternoon call summary.
- `2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/`: `stories-jira.md` is the clean paste-ready version; `stories.md` is the same content with sources.
- `2026-10-01-solution-options-deck/`: `deck-digest.md` plus `pages/`, 16 word-for-word transcriptions with colour coding and legends.
- `2026-10-01-opf-decommission-strategy/`: `opf-decommission-strategy.md` is the clean shareable version, with no sources section and no local paths; `opf-decommission-strategy-sourced.md` is the internal copy with sources.
- `dashboard/index.html`: one-page project view. Not rebuilt since Session 1; rebuild with the `/dashboard` command.

## The owner's epic at a glance

Epic ENTPMTS-143224, Jira project "RBT ENT Pmts: Silver Streak", component "Rail - Wires".

| # | Story | Pts |
|---|---|---|
| 1 | Extend the existing v9 pain.001 converter to support V11 | 5 |
| 2 | Implement pain.001.001.11 XML generation from the payment object | 5 |
| 3 | Implement XML-to-JSON conversion | 5 |
| 4 | Implement Business Application Header wrapping | 3 |
| 5 | Implement SQS publish step | 3 |
| 6 | Implement acknowledgment back to PayX | 3 |
| 7 | Confirm PayX produces the `.OPFRAIL` stage | 2 |
| 8 | Enabler: v9-to-V11 schema delta analysis | 3 |
| 9 | Confirm field mapping and message content with FIS | 2 |
| 10 | Observability and end-to-end verification | 5 |

Stories 1 to 7 are the epic's own recommended stories. 8 to 10 were added from the call. Suggested: sprint 1 = 8, 1, 5, 9 started; sprint 2 = 2, 3, 4, 6; sprint 3 = 7, 10. Not known: whether the owner pasted them as is, changed them, or how the team sized them.

Design facts the stories rest on: a brand-new V11 converter library, Java with Gradle (owner, 2026-10-05; supersedes the 2026-09-30 plan to extend an existing v9 converter in `PmtInfrEngn-wire-ii-intg`, and the Maven note); XML first then JSON because Phase 2 keeps the XML; map to the FIS specification's types, not the ISO V11 XSD; Java 21, Maven; component created through DevNav Hub under the PIE ASV for now; Kaushik Ravichandran is to share the V11 XSD.

Two cautions from the morning walkthrough, both still open:
- Kiran leaned towards a **new ASV** and left open whether OPF pain.001 generation **reuses the existing Wire II service or is a new one**. The afternoon chose the PIE ASV and the existing converter, but Kiran was not a speaker then. Story 1 depends on this. (actions 45, 46)
- Superseded on 2026-10-05: the owner says there is no existing v9 converter; the V11 converter is a brand-new Gradle library. Stories 1 ("extend the existing v9 converter") and 8 ("v9-to-V11 delta analysis") need rewording; the owner's own first story is "Analyzing of converting existing Payment Object to v11 pain.001 xml", 5 points, acceptance criteria on the shelf.
- Story 7 assumes PayX produces `.OPFRAIL`. In the walkthrough that stage is produced by a new **PayX integration service** after it calls Wire II, and who builds that service is unclear. (action 34)

## Live blockers and open threads

1. **Code Connect access.** Capital One ids are rejected; registration needs a Discover id. The owner and Tejaswi can log in with Discover emails but cannot see the OPF tile. Discover's entity id is 8203. The owner owes FIS an email with the user list and the question of tying Capital One users to that entity. (action 31)
2. **Drawdowns.** In scope, 250 to 350 a day from DN and DCI to BNY, JPMC and Citi, unsupported by the FIS API. A FIS call was due 2026-10-01. The deck lists outbound international drawdowns under OnePay. (actions 8, 30, 37)
3. **Encryption.** FIS takes no field-level encryption. Compliance call 2026-10-02; cyber and ISO approval being sought. If refused, the design has to be rethought. (action 36)
4. **Status messages.** FIS's immediate 202 or 422 is certain. Anything later is not designed: no link exists from OPF outward, Kiran doubts one is feasible by May, and the business value is unproven. Ideas are the OneLake reports or Pod 2's reconciliation. (actions 24, 47)
5. **VPN, OVA and Okta (owner's follow-up).** Is OVA still needed (Kiran says yes; business not confirmed)? Are the FIS VPN devices kept, moved or replaced? Is DFS Okta retired by May and who drives it? Known: Okta passes group names to OPF in the SAML token. Contacts: Subha, Shantanu. (actions 26, 27, 40, 41, 42)
6. **New ASV and Wire II reuse.** See the cautions above. (actions 35, 45, 46)
7. **JSON shape risk.** FIS JSON uses its own element names, so a plain XML-to-JSON pass may not match. Flagged in story 3. (action 39)
8. **FIS contract extension** to Q4 2027 is not secured. Program-level gate. (action 22)
9. **Names.** The two new Pod 3 members are Tejaswi Davuluri (probable match to the voice) and a second Kaushik, surname unknown, called "the contractor" once. He is not Kaushik Ravichandran. Still to confirm: these two, and whether Speaker 2 on the afternoon call is Dylan Pensabene. (action 53)
10. **Not on the shelf:** `UEAPI.json`, the V11 XSD, the capabilities and dependencies workbooks, Confluence pages for Capabilities 18 to 20, the five-slide "OPF Wires Convergence Team" file Cameron presented from. The solution-options deck is now on the shelf. (actions 20, 21)
11. **Project `CLAUDE.md` "Current focus"** was brought up to date on 2026-10-01 after the intake: squad leads, Pod 3 membership, the owner's VPN and Okta follow-up, the two extra blockers.

## What to ask the owner at the start of the next session

- Did the stories go into Jira as drafted? Any changes or re-sizing from the team?
- What came out of the 2026-10-01 readout, the confidence vote, and the FIS call on drawdowns?
- Did the Code Connect email go out, and is there access yet?
- Outcome of the 2026-10-02 compliance call?
- Has anything come back from Subha or Shantanu on the VPN devices and DFS Okta?
- Has Kiran settled new ASV versus PIE ASV, and reuse of the existing Wire II service?
- Confirm the names: Tejaswi Davuluri, the second Kaushik's surname, Catherine as the kickoff host, "Zelma".
- Did the OPF upgrade date "10:16" mean 16 October?
- What is Pod 3's team name, and when does sprint 1 start?

## How the owner wants things done

- **Explain plainly.** PayX, OPF, ISO 20022 and bank connectivity are new to the owner; their background is the consumer wire UI up to BPM. Define each term the first time. Lead with the answer.
- **Ground every answer in the shelf** and say when something is thin or a guess.
- **Anything the owner will share with other people** (director, team, Jira) must carry no local references: no shelf or notes paths, no photo numbers, no transcript cues, no sources section. Name program documents in plain words. Keep a separate `-sourced` copy beside it for traceability. (owner, 2026-10-01, repeating the 2026-09-30 Jira correction)
- **Jira stories:** start from the epic's own recommended stories and keep their wording; improve and add where needed. Maximum 5 points per story. Do not split out thin slices such as a story for a header alone. The paste-ready version must stand on its own: no photo numbers, transcript cues, ADR numbers or capability numbers. Keep a sourced copy separately.
- **Two-week sprints.**
- **Intake:** new files land in `shelf/files/audioRecordings/` and `shelf/files/images/`; move to `processed/` once read. The `/meeting` command does the whole intake.
- **Large photo sets:** transcribe word for word into `pages/`, one file per photo, then read and digest. Note colour coding and legends. That is how the 123 Confluence pages and the 16 deck photos were done.
- **Visuals:** diagrams and infographics are welcome. Real company names are fine in generation prompts. Higgsfield is for assets only, never its website builder or publishing. Everything stays as local files.
- **Skills:** pick the right one per task; the routing table is in the workspace `CLAUDE.md`. Do not install more without reading the files first.

## Session log

### Session 3, 2026-10-05 to 2026-10-08
- 2026-10-08: Exported the whole text knowledge base (CLAUDE.md adapted to stand alone, README index, notes/, the three transcripts, every generated markdown file including both pages/ folders; no images, no dashboard) as `shelf/generated/2026-10-08-knowledge-export/OPF-Wires-knowledge-export.zip`, for the owner to load into their enterprise Claude on their Mac.
- Answered: for Discover, OPF hands wires to the correspondent banks by file; it does not send to the Fed itself, and FedLine Advantage appears nowhere on the shelf. The 2022 C4 document reads differently and is superseded.
- Reviewed the director's one-slide "Wires" decommission summary (`shelf/files/images/processed/2026-10-05-director-wires-decom-slide.jpg`). Feedback given in chat: add the correspondent banks and the destinations, add the missing decommission items (Oracle Cash Management, Payment Origination, DFS Okta and VPN), add the two dates and the FIS contract risk, clarify the "Bank" box, and update the wording now that the approach is chosen and the pods exist. No revised slide was built.
- Wrote acceptance criteria for the owner's 5-point analysis story "Analyzing of converting existing Payment Object to v11 pain.001 xml" (a merge of stories 8 and the groundwork for the converter library): `shelf/generated/2026-10-05-story-ac-payment-object-to-v11-analysis/acceptance-criteria.md`. Owner now says the library is Gradle, not Maven as noted on 2026-09-30.
- Wrote paste-ready replacement text for that slide, keeping the director's headings and wording where they held: `shelf/generated/2026-10-05-director-wires-slide-text/wires-slide-text.md`. Clean, no references; its facts are the ones sourced in `2026-10-01-opf-decommission-strategy/opf-decommission-strategy-sourced.md`.

### Session 2, 2026-10-01
- Wrote the OPF decommission strategy for the owner's director discussion: what is retired, why, and in what order. Two files: the clean shareable version and a `-sourced` copy.
- Processed the PI planning walkthrough recording (2026-09-30 morning, 1 h 55 min). Date confirmed from the Zoom screenshot and from the afternoon call referring back to it. Full write-up on the shelf.
- Transcribed the 16 new photos word for word: 15 slides of the "OPF Wires Convergence Solution Options" deck and one Zoom screenshot. Wrote a deck digest with the colour coding (four items are red, "Funding Required").
- Found that there are two Kaushiks: Kaushik Ravichandran leads the squad with Kiran; a different Kaushik and Tejaswi Davuluri (probable) are the two new Pod 3 engineers.
- Filed into the notes: 8 decision entries, actions 40 to 53 and updates to actions 21, 24, 26, 27, 31, 34 and 35, 5 new people, 7 timeline rows, about 35 glossary terms, two new sections in `system-understanding.md`.
- Recorded the owner's rule on shareable documents carrying no local references.
- Moved the recording and the 16 photos to `processed/`.
- After the intake: corrected the decommission strategy (both copies) where the walkthrough moved things on: reports to OneLake sit with Pod 3, and the status path back from OPF is not designed. Updated the project `CLAUDE.md` "Current focus".
- Not done: the dashboard was not rebuilt.

### Session 1, 2026-09-29 to 2026-10-01
- Created the workspace template and the OPF-Wires project.
- Read the 2022 DFS C4 document photos.
- Processed the FIS Payment Initiation API meeting and deck.
- Installed and vetted about 37 skills; built the five workspace commands (`/meeting`, `/actions`, `/timeline`, `/dashboard`, `/new-project`) and tested `/meeting` with a fresh agent.
- Transcribed and digested 123 Confluence pages. This overturned the first brief: the program covers GPN and Corporate wires, not the consumer BPM path.
- Answered questions on Code Connect, ASVs, idempotency, drawdowns.
- Processed the Pod 3 PI planning call and drafted the Wire II stories, revised three times to the owner's format.
