# PI planning walkthrough: squad kickoff and Pod 3 morning breakout, 2026-09-30

Written 2026-10-01. The folder is named for the meeting date, as the owner asked.

## Sources

- Transcript: `shelf/files/audioRecordings/processed/PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt`. 1,093 cues, 1 hour 55 minutes. Cited as `cue N`. Read in full.
- `shelf/files/images/processed/IMG_9912.jpg`: screenshot of the Zoom call, named "...9-30 at 10.07.53 AM", Cameron Mayor sharing the Phase 1 diagram to four participants. Transcribed in `shelf/generated/2026-10-01-solution-options-deck/pages/IMG_9912.md`.
- `shelf/files/images/processed/IMG_9897.jpg` to `IMG_9911.jpg`: 15 slides of the deck "OPF Wires Convergence Solution Options", Sep 2026. Cameron presented the same material from a sibling slide file. Transcribed one file per photo in `shelf/generated/2026-10-01-solution-options-deck/pages/`; digest in `deck-digest.md` there.

## Date

**2026-09-30, morning. Confirmed by three independent pieces of evidence.**

1. The Zoom screenshot is named "9-30 at 10.07.53 AM" and the Dock calendar in the same photo reads "Wed 30"; 30 September 2026 is a Wednesday (IMG_9912).
2. The screenshot shows four participants (Vasanth, Cameron Mayor, Tejaswi Davuluri, Kaushik) and the Phase 1 slide. That matches the transcript between cue 168, when Kaushik joins, and cue 724, when Kiran joins, and the slide Cameron talks through at cues 248 to 300.
3. The meeting ends by handing Pod 3 to "Dylan or Kaushik" for the afternoon (cue 1075). The afternoon session is the call already on the shelf, `Pod3Call-m4a-8d520809-a6a3.srt`, stamped 30 Sep 2026 1:48 PM. Its first minute says "the earlier session we spent time on KT and discussing the first epic" (Pod3Call cue 18), and the owner says there "today morning, Cameron did a very good walkthrough" (Pod3Call cue 347).

The transcript header reads "Meeting created at: 1st Oct, 2026 - 10:56 AM". That is when the transcript was generated, not when the meeting happened. The time zone of the 10:07 clock is not shown. Working back from the screenshot, the recording started at about 9:30 to 9:40 on that clock.

So the order of the day was: this session in the morning, then the Pod 3 call in the afternoon (`shelf/generated/2026-09-30-pod3-pi-planning-call/meeting-summary.md`). Where the two differ, the afternoon is the later word.

## Caveats

- Machine transcript, eight numbered speakers. The recording has two parts: a squad kickoff with more people than labels (cues 1 to 136), then the Pod 3 breakout (cue 137 onward). Stray one-word cues are attributed to the wrong speaker throughout; they are ignored.
- Term corrections applied: "pane one / pane 001 / PAN001 / pain o one" is pain.001; "pain two / pin O to" is pain.002; "Wire AI / wire I / Wire II / ir" is Wire II; "pix / PAX / AX / PACE integration service" is the PayX integration service, and "PayEx / PAX / PX" is PayX; "one leg / one lake" is OneLake; "one pin / one pay" is OnePay; "OBA / oba / VA" is OVA; "OPAC / OPEC" is OFAC; "C mod" is CMOD; "ACMAC file / acts and max" is ack and nack; "ASB / ASP / ISV" is ASV; "PI asv" is the PIE ASV; "Fidel Swift" is Fed and SWIFT; "legacy cofires" is legacy COF (Capital One) wires; "cough sso / call email" is COF SSO / COF email; "ethics" is epics; "prayer" is PI; "the fires / fiscal / FRS" is FIS; "Scupper's" is Discover's; "EBAM" is eBAM; "Kieran / Karen" is Kiran; "Kashik / Kasha / Kaush" is Kaushik; "Shubha / Suba" is Subha; "camera / Kevin" (cues 143, 188, 1089) is Cameron.
- Terms that could not be resolved are listed in section 12.

## 1. The one-paragraph version

This was the morning of PI planning day for the three-pod "Clearwater Squad". After a 13-minute squad kickoff (roles, agenda, a vote on team names), Cameron Mayor gave Pod 3 a two-hour walkthrough: why the program exists, how a wire will travel in Phase 1, and the pod's four pieces of work, which are the PayX-to-OPF integration, reports to OneLake, VPN devices and sign-on, plus coordinating end-to-end testing. Kiran Iruku joined for the last 40 minutes. Three things are new and matter. First, **there are two people called Kaushik**: Kaushik Ravichandran leads the squad with Kiran, and a different Kaushik is a new Pod 3 engineer alongside Tejaswi Davuluri. Second, **the path for status coming back from OPF is not designed**: FIS gives an immediate accepted-or-rejected answer, but nothing connects OPF outward for later status, and Kiran doubts a new link is feasible by May or worth it. Third, **the owner was given the VPN and Okta follow-up**: find out from Subha and Shantanu what happens to the VPN devices and to DFS Okta, and how OPF authorises users. The session ended at lunch with the access epic ready for stories.

## 2. Squad kickoff (cues 1 to 136)

| Topic | What was said | Cue |
|---|---|---|
| Squad shape | The three pods together are the "Clearwater Squad". "Kaushik and Kiran will be leading that overall from the squad level." Cameron is the senior developer on Pod 2 and steps into Pods 1 and 3 when needed. | 4-7 |
| Program manager | Joe is technical program manager for all three pods. About nine months at Capital One. Has been running the OPF upgrade and holds "a lot of the OPF original files". | 14-25 |
| OPF upgrade date | "Pulse is killing me right now, but we should be out the door by 10:16." Read as 16 October 2026 for the OPF upgrade. Inferred: the transcript gives "10:16", and the subject is the upgrade Joe has just named. | 21-22 |
| Agenda | Pods work separately until noon on epics and stories. Success for the day: the first two sprints' stories "entirely ready to go". The pods also owe sprint plans for the whole PI with initiatives and outcomes, and there is a confidence vote at the end of the day. | 32-37 |
| Product support | Speaker 1 (Dylan) covers Pods 1 and 3. Cameron supports Pod 3 in the morning; Dylan comes to Pod 3 in the afternoon and Kaushik (Ravichandran) supports Pod 1. Pod 2 regroups at about 1 pm Eastern. | 45, 112-114 |
| Channels | Each pod has a Slack channel; there is also a wider DFS OPF Convergence product and tech channel. | 47-51 |
| Team names | Five water-themed options: Erie, Hoover, Chesapeake, Mackinac, Hudson. Suggested mapping: Erie for Pod 1, Chesapeake for Pod 2, Hoover for Pod 3. Vote by Slack reaction, result at the end of the day. Needed because the Jira boards have no team yet. | 53-97 |
| How stories get written | Epics are fed to the "BMAD epics and stories" skill, then reviewed and edited by hand. | 115-119 |
| Sprint length | Two weeks. Sprint start dates were on a slide that Cameron could not find. | 961-967 |

## 3. Program context, as Cameron told it (cues 218 to 320)

Plain version, for a reader new to this.

- OPF is FIS's hosted wire platform. Discover uses it for network wires and for corporate wires keyed by hand. (220-222)
- The merger gives two years to retire legacy Discover systems. OPF itself is vendor-hosted and "will still be allowed to persist", but the Discover-hosted systems it connects to, such as Compliance Link for screening and CMOD for reports, go away. Target: "no later than May". (223-234)
- Today: channels send flat files to Monetary Transfers (MTA) on the mainframe; MTA sends one consolidated file format to OPF by FTP; OPF enriches, screens, validates and sends to the correspondent banks. (239-247)
- Phase 1: MTA goes away. Discover builds a Payment Network Originator, which stays on the Discover network side and is allowed past May because it is network-related. It reads the same files and makes **one API call per payment** to a new PayX API built by Pod 1. (269-279, 302-308)
- PayX takes over screening (Bridger), account enrichment (eBAM) and FX. OPF keeps payment validation and filters, holiday calendar, and routing rules, because those have no tie to Discover systems and because OPF already has the bank relationships. (279-300)
- Consumer wires are out of scope; they move under the PIX migration. The owner asked and Cameron confirmed. (253-265)
- The flow in PayX is automated. Exceptions, such as a screening hit, go to a queue worked in OnePay; a separate OnePay pod handles those screens. (310-318)

This matches the deck: IMG_9898, IMG_9900, IMG_9902.

## 4. What Pod 3 builds

Cameron's list from the pod slide: the PayX-to-OPF integration, end-to-end testing, reports to OneLake from OPF, VPN devices, DFS single sign-on, and the OPF API integration with pain.001 output. (329)

### 4a. The integration, step by step (cues 332 to 425, 468 to 483)

| # | Step | Detail | Cue |
|---|---|---|---|
| 1 | PayX finishes its own stages | PayX services are Java Fargate microservices that listen on a private "SDP topic" for a given saga type and stage, then publish the next stage. | 367-369 |
| 2 | **PayX integration service** picks the payment up | A new consumer of that topic. It waits for the OFAC stage, "tentatively the last stage before sending it to OPF". | 370, 413-415 |
| 3 | It calls **Wire II** | A synchronous REST call. It has to be an API registered on Exchange because the call crosses from one ASV to another. | 372-373, 393-396, 416 |
| 4 | Wire II builds the message | Converts the PayX payment object, which is JSON, into pain.001 JSON and puts it on an SQS queue. Returns OK. | 347, 388-397, 416 |
| 5 | PayX integration service records progress | Produces the OPFRAIL stage: the payment reached the OPF rail and is queued. | 417 |
| 6 | **Submit to OPF** service sends it | Listens to the queue and posts the pain.001 to the OPF external API. | 397 |
| 7 | The answer goes back | Submit to OPF calls an endpoint that the PayX integration service exposes, with accepted or rejected. | 418-421 |
| 8 | Final stage | PayX integration service produces OPFCLEARING if accepted, or OPFCLEARING.STOP if rejected. | 424-425 |

- Why the queue: so the call is not held up by latency, and so the Wire II step is not tied to the OPF API and can be re-pointed later. (390-391, 859-861)
- Who builds it: "this will mostly be your pod", including "the PayX integration service, the Wire II service, submit to OPF and then the whole integration to that external API". Cameron's pod overlaps on reconciliation. (475-477)
- The Wire II endpoint has to go through the Exchange portal for approval. (479-483)
- Pod 3 does not touch the pain.002 messages that correspondent banks send to OPF. That path does not change. (562-582)
- The API call to FIS goes over the general internet. It does not depend on the VPN or on sign-on. (700-703)

### 4b. Reports to OneLake (cues 601 to 722)

- Today OPF generates reports, sends them through DFTP to CMOD, an IBM report store where users browse PDFs. (603-606)
- There are nine reports, for example wire user audits, wire exception, end-of-day reconcile, user profile. They are "a mix of PDF and CSV" today. (632-635)
- The OPF upgrade adds the ability to produce all of them as CSV. Whether that is a setting Capital One can change or a ticket to FIS is not known. (607-618, 636-637)
- Design: OPF sends CSV files to Capital One through file transfer (EFG); they land in an S3 bucket; OneStream picks them up and publishes to OneLake. (609-613, 685-688)
- Steps Cameron read from the Confluence guide: collect format, frequency, direction and sensitivity; get the schema of each report from OPF; register the dataset in Exchange; create a data share, which records the contract with the outside party and needs approval; set up an external partner for OPF with its sign-on details, and a partner for the landing bucket; create a route per file, so about nine routes; use PGP encryption if the data is sensitive and FIS can do it; approvals and testing. (639-683)
- Frequency: "I believe they are daily, but we can check." (619-624)
- Scope: land the reports in OneLake and show users where they are. No analysis. Pod 2 may use some reports to reconcile PayX against OPF. (708-719)

### 4c. VPN devices, OVA and sign-on (cues 486 to 560, 759 to 822)

Plain version: operations staff reach two OPF screens. PO (Payment Origination) is where corporate wires are keyed. OVA is where exceptions are worked. Both are reached with Discover sign-on (Okta) through physical VPN devices that FIS supplied and that sit in the Discover data centre.

| Point | What was said | Who | Cue |
|---|---|---|---|
| PO goes away | Corporate wires will be keyed in OnePay, so the PO use of VPN and sign-on ends. | Cameron | 502-506, 528 |
| PO as contingency | Access must be worked out for "both OVA and PO modules ... from a contingency standpoint as well". | Kiran | 761 |
| OVA, Cameron's doubt | He has heard both that OVA is the general exception screen and that it is used only for sanctions-screening exceptions. If only the latter, it is not needed, because screening moves to PayX. He asked a business user on 2026-09-29 (said "yesterday") and is waiting. | Cameron | 489, 507-512, 529-537, 774-777 |
| OVA, Kiran's view | OVA is still needed: "you have all of the risk filters, duplicate queues, repair queues, etc, all of them happening via OPF", and the operations team ("Zelma's team") has to act on them. | Kiran | 765-769 |
| VPN options | FIS requires user traffic to PO and OVA to go through its VPN devices, not the open internet. Options: move the devices from the Discover data centre, or install new ones in parallel. Capital One has space in Equinix colocation sites. | Cameron | 513-520 |
| Three parts | Authentication (Okta today; move to Capital One SSO if Okta is retired by May), authorisation (how OPF decides who may do what), network (the VPN devices). | Kiran | 796-805 |
| Authorisation, answered | Subha told Cameron on 2026-09-29 (said "yesterday") that Okta evaluates the user's groups and passes the group names to OPF in the SAML token. | Cameron | 818-821 |
| Privileges inside OPF | They stay as they are while OPF is in use; the team needs to understand them to validate after the move. | Kiran | 812-814 |
| Sign-on and VPN go together | "Separate initiatives but they very much go hand in hand." | Cameron | 555-560 |

### 4d. End-to-end testing (cues 465 to 466)

"This pod will be tasked with the end to end testing": once all three pods have built, Pod 3 builds the test cases and coordinates the full run.

### 4e. What can run in parallel (cues 689 to 706)

Reports, the API integration and the VPN work do not depend on each other. The only staged sequence is PayX integration service, Wire II, SQS, Submit to OPF, then the acknowledgement path back.

## 5. Status coming back from OPF: not designed yet

This is the most important technical finding of the session.

| Point | What was said | Who | Cue |
|---|---|---|---|
| The owner raised it | FIS described an immediate response that covers validation, then later asynchronous responses on a queue. Since this bridge is temporary, is the team going to build for that, and how will it learn what FIS did afterwards? | Owner | 426-434 |
| No final answer | "That's something I have not heard the final solution on." A 200-type response only means the message passed technical checks; the payment can still be caught by a filter or routing rule inside OPF. | Cameron | 437-445 |
| Ideas floated | Rely on the reports sent to OneLake, or on the reconciliation that Pod 2 is building. | Cameron | 439-446, 714-715 |
| Today's equivalent | MTA gets an ack/nack file from OPF, which Cameron understands to be like the HTTP code the API returns. The pain.002 messages from banks go to OPF and are not passed back to MTA. | Cameron | 451-453, 876-878 |
| The lead architect's position | Bank acknowledgements "flow back from correspondent banks into OPF only. There is no connectivity from OPF that exists today wherein they can send these messages out." Getting them means a new link, effort and a statement of work from FIS; "by May, I don't know if that's going to be feasible"; and the business value for an interim solution has to be shown first. He will discuss it with FIS. | Kiran | 866-874 |
| Response codes | The owner recalled 422 for an error and a 2xx for success, thought to be 202. | Owner | 882-888 |
| Agreed for now | Build the forward path and the synchronous answer; work out reconciliation and acknowledgement detail in parallel. | Owner, Cameron | 454-460 |

Inference, not stated in the meeting: the earlier design line "the outcome arrives as pain.002 over MQ" (`notes/decisions.md`, 2026-09-29) now looks unlikely for Phase 1. Nobody cancelled it; nobody committed to it.

## 6. New ASV and the Wire II question

An ASV is Capital One's unit for one application and its resources; Cameron called it an "application service" (373).

| Point | What was said | Who | Cue |
|---|---|---|---|
| New ASV intended | "I think we're going to be building a new ASV for this", labelled "DFS Wires" on the diagram and probably called "ASV OPF". | Cameron | 376-379 |
| Why separate | "I was leaning towards building a separate one." It will face FIS now, be re-pointed to the correspondent banks after FIS, and be retired only when Capital One connects to Fed and SWIFT directly through the PIE ASV's Wire II layer. Also to stop the PIE ASV growing too large for several teams to manage. | Kiran | 843-846 |
| Process | A new ASV goes through a review process transcribed as "BR ALR", working with Sanjeev. "Something we have to get started pretty soon." Cameron: include it in the first sprint because of the lead time. | Kiran, Cameron | 752-758 |
| Wire II exists already | It handles all legacy Capital One wires and sits in the PIE ASV. | Kiran | 850-855 |
| Reuse or build new: open | "I need to discuss with Cameron and Kaushik ... whether we want to use the same Wire II layer service or we want to build something new." | Kiran | 853-855 |
| Cameron's reading | A separate Wire II service in the new OPF ASV, per Kaushik's thinking, with SQS in between so it is not tied to the OPF API. | Cameron | 857-861 |
| AWS accounts | Enterprise payments shares one dev account. Each ASV has its own QA and prod accounts; the new ASV will get its own. | Cameron | 954-957 |

The afternoon call then decided: use the PIE ASV for now, treat the new ASV as its own epic, and extend the existing converter. See section 8.

## 7. Access and setup (cues 146 to 154, 893 to 1086)

| Item | State on 2026-09-30 morning | Cue |
|---|---|---|
| Laptops | All three engineers set up. Story closed. | 898-900 |
| Capital One VPN | Everyone connected. Story closed. | 925-927 |
| Access list | Alex shared a starter list; Speaker 5 posted it in the meeting chat for the Jira story. | 153, 903-910 |
| PDASH account | Needed for production AWS access. Kaushik (new) has one. The owner and Speaker 5 do not. Cameron found the request link. Lower priority. | 918-940 |
| Jira and Confluence | No longer granted by default. Speaker 5 requested Jira and has not received it. | 929-931 |
| Claude | Everyone has it. | 932-938 |
| GitHub | Group name "GitHub Enterprise Cloud users". Pod 3's repositories do not exist yet. | 1072-1083 |
| OPF PO and OVA test environment | Wanted so the team can see the screens. Waiting for the access team to say how; it appears to be requested through All Access. | 943-944, 982-985 |
| FIS Code Connect | See below. | 986-1064 |
| PayX dev and QA | Comes with the AWS roles. | 947-956, 1066-1068 |

**Code Connect** (FIS's developer portal, where the API is exposed):

- The owner and Speaker 5 registered on 2026-09-29 (said "yesterday") with their Discover email addresses. They can log in but cannot see the API. (989-992)
- The owner recalled that FIS grants the "Universal Execution Origination HostedWires" tile on request, user by user. (1016-1027)
- Cameron believed either email would work. Logging in live with a Capital One address, he saw only Capital One entities and no way to enter the Discover one. (995-1003, 1033-1053)
- The Discover entity id is **8203**. Cameron's understanding: the entity id identifies Discover's instance of OPF, so wires started through the API land in the right environment. (1009-1011, 1044-1054)
- Left open: ask FIS whether a Capital One address can be tied to entity 8203, or whether everyone needs a Discover address. "This might be something y'all can look into." (1056-1064)

By the afternoon the answer was partly in: Kaushik Ravichandran's request with a Capital One id had been rejected (Pod3Call cues 22-44).

## 8. Where this morning session and the afternoon call differ

| Topic | Morning (this session) | Afternoon (Pod3Call, same day) | So what |
|---|---|---|---|
| ASV | Build a new ASV; start the process in sprint 1 (752-758, 843-846) | Use the PIE ASV for now; new ASV is a separate epic (Pod3Call 415-434) | The afternoon stands. Kiran was not a speaker in the afternoon, so his view on timing has not been reconciled. |
| Wire II | Open: reuse the existing service or build a new one; Kiran to discuss (853-855) | Extend the existing version 9 converter; XML first, then JSON (Pod3Call 865-890) | The owner's stories follow the afternoon. Worth confirming with Kiran. |
| Who exposes the callback endpoint | The PayX integration service, which "your pod" builds (418-420, 477) | "Cameron mentioned that he will be exposing an endpoint" (Pod3Call 733) | Ownership of the PayX integration service is unclear. |
| Code Connect ids | Either email should work, to be checked with FIS (995-1003) | Capital One ids are rejected (Pod3Call 22-44) | Settled by the afternoon. |
| OVA | Kiran: still needed (765-769) | Unclear; Beatrice asked (Pod3Call 311-329) | Still unconfirmed by the business. |

## 9. Deck versus meeting

"Deck" is the "OPF Wires Convergence Solution Options" deck, Sep 2026.

| Topic | Deck says | Meeting says | So what |
|---|---|---|---|
| Pod 3's scope | "OPF API integration (pain.001 out, acknowledgements in)"; "smallest scope", finishes first (IMG_9909) | Six items: PayX-OPF integration, end-to-end testing, reports, VPN, sign-on, pain.001 output (329, 465-466) | The pod is carrying more than the deck's staffing argument assumed. |
| Acknowledgements | "acknowledgements in" is part of Team 3's scope (IMG_9909) | No path exists from OPF outward; may not be feasible by May (866-874) | Only the immediate API answer is certain. |
| Wire II | "[E] Wire II (pain.001)", enhance existing (IMG_9907) | Kiran leaning to a separate service in a new ASV; undecided (843-855) | The afternoon went back to the deck's position. |
| CMOD reports | Destination COF OneLake; owner "In Discovery (TBD)" (IMG_9901) | "CMOD for reporting, which this pod 3 will be taking care of"; a nine-step plan exists (230, 601-688) | The owner is Pod 3. The deck is behind. |
| Report timing | "EP: Reporting and OL" bar from about mid-November (IMG_9903-2) | No dependency; can start now in parallel (689-697) | |
| What stays in OPF | Validation and filters, holiday calendar and value date, routing and bank integration, reports (IMG_9902) | The same list (293-297) | Agreement. |
| Consumer wires | "*BPM channel for Consumer wires handled via PIX migration" (IMG_9900) | The same (258-265) | Agreement. |
| VPN and Okta | Next step 5: "Follow up on Network devices (VPN) & DFS SSO/Okta" (IMG_9904) | Given to the owner (759-782, 828-839) | The deck's open item now has a name on it. |
| Operations users | 151 OPF operations users, 500 templates (IMG_9907) | Not mentioned | These are the people whose sign-on and OVA access must keep working. |
| Drawdowns | "[N] OB Intl Drawdowns" under OnePay (IMG_9907) | Not discussed in the morning | Confluence puts it under Pod 3; see action 30. |
| Bank messages | pain (001, 008) out, pain 002 back, between OPF and the banks (IMG_9902) | "That will not change"; not Pod 3's work (577-582) | Agreement. |

## 10. Open issues

1. **How PayX learns what happened to a wire after OPF accepts it.** No design. Kiran to raise effort and statement of work with FIS. (437-449, 866-874)
2. **Is OVA still needed?** Kiran says yes; Cameron is waiting for the business. The VPN work depends on the answer. (507-512, 765-777)
3. **VPN devices:** retained, moved or replaced, and what FIS offers if not VPN. (513-520, 759-763)
4. **DFS Okta:** retired by May or kept, and who drives it. (778-781, 799-800)
5. **New ASV:** when, and whether Wire II for OPF is the existing service or a new one. (752-758, 843-861)
6. **Who owns the PayX integration service.** (475-477 against Pod3Call 733)
7. **Code Connect:** linking Capital One users to Discover entity 8203. (1056-1064)
8. **Reports:** frequency, schemas, sensitivity, and how the switch to CSV is made. (615-624, 645-649)
9. **Sprint start dates** for PI 26.4 were not found in the session. (963-967)
10. **Team name** for Pod 3; Hoover was the suggestion. Result not in the recording. (93-97)

## 11. Decisions and commitments

**Decisions** (the rest of the session was explanation)

| Decision | Cue |
|---|---|
| Squad structure: three pods form the Clearwater Squad, led by Kaushik Ravichandran and Kiran Iruku; Joe is program manager for all three; Cameron is senior developer on Pod 2 and supports Pods 1 and 3. | 4-7, 14-15 |
| Pod 3 coordinates end-to-end testing across the three pods. | 465-466 |
| One API call per payment, both into PayX and from Pod 3's service to OPF. | 304-308 |
| The API integration, the reports work and the VPN and sign-on work run in parallel. | 689-704 |
| Build the forward path now; settle acknowledgement and reconciliation detail alongside. | 454-460 |
| Two-week sprints; stories drafted with the BMAD skill and edited by hand. | 115-119, 961 |

**Not decisions yet:** new ASV versus PIE ASV timing; reuse of the existing Wire II service; whether to bring status messages out of OPF; whether OVA is retained.

**Commitments**

| What | Who | When | Cue |
|---|---|---|---|
| Work with Subha and her team: which VPN devices exist, whether they are kept, and if not how users reach OVA and PO; what FIS offers if VPN is not an option | **Owner** | | 759-763 |
| Find out the disposition of DFS Okta: kept or retired by May, and whether an enterprise team or each application drives it. Follow up with Shantanu. | **Owner** | | 778-782 |
| Chase answers to the questions Cameron added to the Confluence page for DFS Okta integration to Capital One, where the owner is now tagged. "I'll try to chase back the answers on this." | **Owner** | | 828-839 |
| Understand how OPF authorises users today (roles and privileges), so it can be validated after the move | **Owner**, Pod 3 | | 800-805 |
| Set aside time for knowledge transfer: PayX, wire processing, the FIS API documentation | **Owner** | | 749 |
| Ask FIS whether a Capital One email can be tied to Discover entity 8203 in Code Connect, or whether Discover emails are needed | Pod 3 ("y'all") | | 1056-1064 |
| Request a PDASH account | **Owner**, Speaker 5 | | 918-940 |
| Start the new-ASV process with Sanjeev; put it in the first sprint | Kiran, Cameron | Sprint 1 | 752-758 |
| Discuss with Cameron and Kaushik whether to reuse the existing Wire II service | Kiran | | 853-855 |
| Raise with FIS: effort and statement of work to get acknowledgements out of OPF | Kiran | | 866-868 |
| Talk the status scenario through with Kaushik and Kiran | Cameron | | 449 |
| Confirm with the business what OVA is used for | Cameron | Asked 2026-09-29 | 489, 507-512 |
| Check how often the nine reports run | Cameron | | 623-624 |
| Put the authorisation notes on the Confluence page | Cameron | | 824 |
| Follow up the missing Jira entitlement | Speaker 5 | | 930-931 |
| Say how to get PO and OVA test access | Access team | | 982-985 |
| Vote on team names in Slack | Everyone | 2026-09-30 end of day | 64-92 |
| Stories for the access epic | Pod 3, afternoon | 2026-09-30 | 1084-1086 |

## 12. Who was there

Squad kickoff: more people than speaker labels. Pod 3 breakout: four people on the Zoom screenshot, then Kiran.

| Label | Who | Side and role | Evidence | Confidence |
|---|---|---|---|---|
| Speaker 2 | **Cameron Mayor** | Capital One. Full stack engineer, about four years in wires, mostly SWIFT connectivity. Senior developer on Pod 2. | "My name's Cameron" (182-184); addressed as Cameron (138, 468); "Cameron Mayor's screen" (IMG_9912) | Confirmed |
| Speaker 8 | **Vasanth, the owner** | Ex-Discover, about seven years; tech lead for bill pay and consumer wires; full stack, Java. Pod 3. | "Vasanth here" (189-197); tagged by name (828); Zoom tile (IMG_9912) | Confirmed |
| Speaker 6 | **Kiran Iruku** | Capital One. Squad lead with Kaushik Ravichandran; architecture. Joined at 01:15. | "Team, Kiran here" (724); addressed as Kiran (725, 841) | Confirmed |
| Speaker 5 | **Tejaswi Davuluri** | Ex-Discover, 12 years, mostly the bank side, team handles ACH; based in California. New Pod 3 engineer. | Self-introduction, name transcribed as "teacher" (212-213); registered on Code Connect with a Discover email alongside the owner (990); the only other name on the Zoom strip (IMG_9912) | Probable (name by elimination) |
| Speaker 7 | **Kaushik, surname not shown** | With Capital One about six and a half years across teams (transfers; notifications); new to wires; Java, AWS. New Pod 3 engineer. Speaker 5 called him "Kaushik the contractor" in a question (157). **Not Kaushik Ravichandran.** | "This is Kaush" (200-208); "Kaushik is the new, joining Pod three" (160); Kiran checks his laptop access (736-748); Zoom tile "Kaushik" (IMG_9912); Pod3Call 75-79 | Confirmed as a second Kaushik; surname and employment status unknown |
| Speaker 1 | **Dylan Pensabene** | Capital One product lead. Covers Pods 1 and 3. Kickoff only. | "everything that Dylan just said" (44) after Speaker 1 gave the agenda | Probable |
| Speaker 3 | **Catherine Hu** | Capital One product lead. Ran the kickoff logistics. | "Catherine is planner extraordinaire, supplied us with rooms" (125), said just after Speaker 3 spoke about rooms | Inferred |
| Speaker 4 | **Joe Kataoka** | Capital One technical program manager, all three pods | "I am Joe ... TPM for all three pods" (14-15); role matches `notes/people.md` | Probable (surname from the notes) |

Mentioned, not present: Kaushik Ravichandran (5, 113, 374, 449, 853, 859, 1075); Subha, on VPN devices and OPF authorisation (760, 818); Shantanu, working on application disposition from a LeanIX standpoint (778-779); Sanjeev, the contact for the new-ASV process (753); Zelma, whose team works the OPF queues (768, 784), name uncertain; Alex, who shared the access list (153, 905); "our manager", who proposed the team names (94).

## 13. Terms still unclear

- **"BR ALR process"** (752): the review a new ASV goes through. Possibly an architecture review; not resolved.
- **"KDS"** (749): what Kiran asked the owner to keep time for. Probably "KTs", knowledge-transfer sessions.
- **"Cheetah"** (738): a basic access Kiran lists beside VPN.
- **"BA admin membership", changed to "EA membership"** (916-917): an entitlement on the access list.
- **"Append Pay Dev 1"** (955): the shared enterprise payments dev AWS account; the real name is garbled.
- **"new mlpis"** (872): the new link Kiran says would be needed from OPF. Possibly MPLS lines; not resolved.
- **"SDP topic"** (367): the PayX internal event stream. Expansion not given.
- **"David"** (115): may be a mis-hearing rather than a person.
- **"Zelma's team, definite team"** (768): the operations team; both the name and the second phrase are uncertain.
- **"fiber with EW privileges"** (765): garbled.
- **"onboard Tesla"** (556): garbled; the sentence is about user access through sign-on.
- **"Missouri Justice"** (96): garbled, in the team-name discussion.

## 14. Background the meeting assumed

General knowledge, not from the sources.

- **ISO 20022** is the international standard for payment messages. "pain" means payment initiation; pain.001 asks a bank to make a credit transfer, pain.002 reports status, pain.008 is a direct debit.
- **AWS Fargate** runs containers without managing servers. **SQS** is Amazon's message queue. **S3** is Amazon's file storage.
- **SAML** is a sign-on standard: the identity provider, here Okta, sends the application a signed statement of who the user is and which groups they belong to.
- **Okta** is an identity and single sign-on product.
- **Equinix** runs colocation data centres where companies place their own network equipment.
- **LeanIX** is a tool for keeping an inventory of an organisation's applications and what is planned for each.
- **BMAD** is a published method for running agile work with AI agents; "epics and stories" is one of its steps. That would explain the `c1-bmad` label on the Pod 3 epics. Inference.
