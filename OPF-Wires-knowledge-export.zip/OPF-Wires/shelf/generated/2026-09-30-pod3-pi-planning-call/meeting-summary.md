# Pod 3 PI planning call, 2026-09-30

**Sources**
- Transcript: `shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt`, 987 cues, 91 minutes. Cited as `cue N`. Header says "Meeting created at 30th Sep 2026, 1:48 PM".
- Screenshots: `shelf/files/images/processed/IMG_9882.jpg`, `IMG_9883.jpg`: Jira epic ENTPMTS-143224. Identical copies were also placed in `meeting-notes/` and moved to its `processed/`.

**Date.** 2026-09-30. The transcript header and the Jira tab "26.4 PI Planning | Pod 3" agree; the owner said they were in the call the same day.

**Caveats.** Machine transcript with numbered speakers. Terms garbled: "wire AI / YRI / Wire 2" is Wire II; "pane 1 / pane 8" is pain.001 / pain.008; "codecrane" is Code Connect; "Dell Demo Nav Hub / Dev now hub" is DevNav Hub; "bogie file" is Bogiefile; "PI ASV" is the PIE ASV; "one line / one lake" is OneLake; "ethics sheet" is the epics sheet.

## The one-paragraph version

Pod 3 met to turn its Confluence capabilities into Jira epics and stories for the next two sprints, with a readout due the next day. The first half reorganised the capability pages by area (external API, PayX capabilities, OPF integration, OnePay) and surfaced two blockers: Capital One ids are rejected by FIS Code Connect, so a Discover id is needed to register, and the FIS API does not support drawdowns, which run at 250 to 350 a day. The second half walked the epics for environment setup, OPF API integration (Capability 2), Submit Request (Capability 3) and Wire II (Capability 10), agreed the build order, and split the epics among the team. The owner took the Wire II epic.

## Who was on the call

| Label | Who | Evidence |
|---|---|---|
| Speaker 1 | Cameron Mayor | Runs the Confluence reorganisation; referred to as Cameron (cue 236, 733) |
| Speaker 2 | Dylan Pensabene, product lead (probable) | Addressed as Dylan several times (cue 557, 704, 850); owns the epics; once addressed as Beatrice (cue 280), which may be a mis-hearing |
| Speaker 3 | New Pod 3 member, name not clear | Took the enablement epic (cue 963); waiting on Jira access |
| Speaker 4 | Kaushik Ravichandran, tech lead | Addressed as Kaushik (cue 25, 36, 849) |
| Speaker 5 | The owner (Vasanth) | Addressed by name (cue 24); took the Wire II epic (cue 960) |
| Speaker 6 | New Pod 3 member, name not clear | Took the foundation setup epic (cue 967) |

Also mentioned: Catherine Hu, Kiran Iruku, Susan's team, Suba, Beatrice, Alex and Sirisha. One external hire for Pod 1 is in background check (cue 73-75).

## What was decided

1. **Confluence capability pages regrouped by area**, not pod: 1 External API and GPN integration, 2 PayX capabilities, 3 OPF integration, 4 OnePay. Any pod can pick items up. (cue 62-69, 86)
2. **Client Registry:** service changes are Pod 2; registering the new client id is Pod 1. (cue 240-248)
3. **Account Qualification for Corporate moves under OnePay**; it is a OnePay screen concern. (cue 153-166)
4. **FX rate API** backend goes under OnePay; it needs a service in the new ASV calling the JPM external API. (cue 103-119)
5. **Business Rules** not needed; page kept. **Flat Files consolidation** not needed for this team; a "Payment Network Gateway (outside EP scope)" section will track what Discover does. (cue 120-124, 176-202)
6. **Build order for Pod 3** (Kaushik): first register the OPF API in Exchange and get Code Connect access, application, client id and secret; second build the pain.001 V11 message and JSON; third integrate with the OPF API. Wire II has no dependency on the FIS connection and can run in parallel. (cue 903-916)
7. **Wire II design:** produce pain.001 V11 XML, then convert to JSON with a utility. Phase 2 needs the XML; the JSON step is removed then. (cue 872-879)
8. **Repositories:** Wire II; Submit to OPF with the connection in the same repository; possibly a third for infrastructure such as SQS. Created through DevNav Hub, which sets up the Bogiefile and pipeline. (cue 473-497, 435-436)
9. **ASV:** use the PIE ASV for now and migrate later; a new ASV is its own epic and takes a long time. (cue 415-434, 465-466)
10. **Stack:** Java 21, Maven, IntelliJ or VS Code, Artifactory via All Access. (cue 555-580)
11. **Capability 2 acceptance criteria edits:** replace "Payment Exchange" with the OPF integration layer as the caller; encryption criterion becomes "send the payload without field-level encryption and get ISO or cyber approval". (cue 603-616)
12. **The FIS paperwork story moves to the foundation epic**; DevExchange registration stays in Capability 2. (cue 637-657)
13. **Each epic gets an observability, alerting and performance call-out.** (cue 770-788)
14. **Epic split:** owner takes Wire II; Speaker 3 takes enablement; Speaker 6 takes foundation setup. Goal: stories for the first two sprints today; weekly refinement after. (cue 807, 960-967)
15. **Code Connect access:** one application per team; the client id and secret are shared within the team. (cue 459-464)

## Open issues

| Issue | Detail | Ref |
|---|---|---|
| Code Connect rejects Capital One ids | Kaushik's request was rejected. Registration sends a confirmation code to a Discover email, so a Discover id is needed. Not everyone can get one. The owner can log in but cannot see the OPF tile. Owner to email FIS with the user list and ask about migrating to Capital One ids. | cue 22-44, 452-456 |
| Drawdowns unsupported by the FIS API | 250 to 350 a day, from DN and DCI, to BNY, JPMC and Citi. Options floated: a batch file over EFG to OPF's batch component, or export and manual upload at the bank portals. FIS call the next day to check. | cue 216-233, 256-279, 306, 330 |
| Field-level encryption | FIS does not support it. Dylan doubts cyber will approve. Owner noted Bill Pay got a workaround on the basis that FIS encrypts data at rest, with mutual TLS. Compliance call Friday; cyber and ISO conversations starting. | cue 612-616, 664-687 |
| OVA usage | Conflicting information: holistic exception handling versus OFAC exceptions only. Beatrice asked for confirmation. Dylan believes OVA and PO share one UI. | cue 311-329 |
| Volumes and performance | Unknown to the team. Kaushik to comment. | cue 784-788 |
| Reports to OneLake | Needs its own epic; not created yet. It is an EFG route setup. | cue 489-526 |
| Missing capability | The OPF PayX integration service on the PayX side is not on the capabilities page; Kaushik to add. | cue 139-150 |
| Whether pain.001 and pain.008 can both come out of the UEAPI | FIS was to research. | cue 216-224 |

## Commitments

| What | Who | When | Ref |
|---|---|---|---|
| Email FIS: user emails for tile access, Discover versus Capital One id question | Owner | | cue 29-44, 452 |
| Add the OPF PayX integration service capability to the ADR page | Kaushik | | cue 142-143 |
| Create a "Payment Network Gateway (outside EP scope)" section | Cameron | | cue 182-192 |
| Create epics for the remaining capabilities, including Reports to OneLake and a new ASV | Dylan | | cue 524, 979 |
| Program team: team drives, OPF infrastructure onboarding for PO and OVA, DFS infrastructure access | Dylan | | cue 375, 385-386 |
| Stories for Wire II, first two sprints | Owner | for the readout on 2026-10-01 | cue 807, 927, 960 |
| Stories for enablement epic | Speaker 3 | same | cue 963 |
| Stories for foundation setup epic | Speaker 6 | same | cue 967 |
| Share the pain.001 V11 XSD | Kaushik | | cue 892 |
| Confirm with FIS whether the API can produce pain.008 | Kaushik, FIS call next day | 2026-10-01 | cue 222 |
| Compliance call on encryption posture | Dylan, compliance contact | Friday 2026-10-02 | cue 676 |
| Answer the OVA usage question | Beatrice | | cue 321 |

## Terms still unclear

- The names of Speakers 3 and 6, both new Pod 3 members.
- "WSO4 documentation" in the access epic (cue 378).
- "SBA" who pulled Kaushik into another call (cue 619).
- "MI's" in "Fed and Swift MIs": market infrastructures, probably.
