# FIS OPF architecture: what the DFS C4 document says

Extracted 2026-09-29 from photos in `shelf/files/images/processed/`. Source document: "FIS Open Payments Framework (OPF)" C4 diagrams, by RM Arcuri, BT Treasury Product Team, revision v1.0, dated 5/20/2022, marked Discover Financial Services Confidential. Six pages; photos cover pages 2, 3, 4 and 5 of the PDF plus a Google Doc with the overview text. Page 6 (probably Level 2, container diagram) and page 1 are not in the photos.

| Photo | Content |
|---|---|
| IMG_9735.jpg | Google Doc: OPF overview text, hosting, OFAC, SSO |
| IMG_9737.jpg | PDF p2: Level 1 System Context (simplified) |
| IMG_9738.jpg | PDF p3: Business impact, products, capabilities, processes |
| IMG_9739.jpg | PDF p4: Level 1 System Context (detailed, all feeder systems) |
| IMG_9740.jpg | PDF p5: Level 3 Sub-Component diagram (OFAC call path) |

Legend used in the diagrams: orange = New, blue = Modified, black = Existing (as of May 2022).

## 1. What OPF is (IMG_9735, IMG_9738)

- FIS-hosted SaaS, external to Discover. Processes wire transfers received from Discover and forwards them to the Federal Reserve and third-party banks.
- Positioned as an FRB-approved payments hub giving DFS direct connectivity, future real-time payments, faster wire settlement, and a possible home for ACH too (marked TBD).
- Lines of business submit wire requests to Treasury. Treasury uses OPF, with Compliance Link for OFAC screening, then transmits to partner banks. (Note: the diagrams show OFAC screening done by Discover's own OFAC application via API, not Compliance Link. Reconcile which is live.)
- Products served: Pulse, Discover Network, Discover Home Loans, Consumer Deposits, Corporate Activities (HR, AP, Finance, other LOBs).
- Capabilities: submit wires to partner banks, workflow management, reporting (end-of-day reconciliation, payments processed, OFAC, audit).
- Processes: batch wire processing, individual wire processing, wire reporting, OFAC screening, cash accounting.
- Authentication: Discover Okta SSO for Treasury users, TLS 1.2 in transit.

## 2. Level 1 System Context, detailed (IMG_9739)

Feeder systems, all sending files over DFTP (Discover file transfer) into **Discover Monetary Processing System (DMPS)**, internally hosted:

| Group | Systems | Hosting |
|---|---|---|
| Discover Bank Applications | BPM - Deposits | Internal |
| Discover Bank Applications | NetOxygen - DHL | External |
| Payment Services Applications | Pulse, WorldPay | External |
| Payment Services Applications | ACSS, EPP, SCI-FI Interchange | Internal |

Then:
- DMPS -> files over DFTP -> **FIS OPF Application, Managed Solution (SaaS)** [New].
- OPF <-> **Discover OFAC** (AML sanctions screening, internally hosted): application call and response. OPF calls DFS OFAC, DFS OFAC responds.
- OPF -> **Wire Oracle DB** (vendor managed, Oracle TDE, AES-128 tablespace keys, AES-256 master key).
- OPF <-> **Banks / Federal Reserve** (vendor managed SaaS): files over SFTP. FRB receives wire transfer settlements.
- OPF -> **Discover AWS Cloud Data Fabric (CDF)** [Modified] -> **Discover Snowflake** [Modified]: archiving historical OPF account data, files via DFTP.
- **DFS Treasury Users** (internal) -> OPF over Okta, TLS 1.2, to manage and reconcile wire activity.

The simplified version on p2 (IMG_9737) collapses the feeders to "Discover Bank Application" and "Payment Services Application" but shows the same DMPS -> DFTP -> OPF path.

## 3. Level 3 Sub-Component, OFAC call path (IMG_9740)

Shows how OPF (FIS Global, externally hosted) reaches Discover OFAC and gets its answer back:

1. OPF -> application call -> **Layer 7** (IHS Zone 1)
2. Layer 7 -> **Enterprise Common Components API** (IHS Zone 2)
3. ECC API -> **Discover OFAC AML Sanctions Screening** (inside DFS SSB/BDC)
4. OFAC -> **ECC API** -> **Event Bus** (SSB/BDC IHS Zone 3)
5. Event Bus -> **Treasury API (OCP)** [New] -> OPF

So the OFAC response returns asynchronously through an event bus and a Treasury API hosted on OCP (OpenShift Container Platform, assumed). Treasury users connect to OPF via Okta SSO over TLS 1.2.

## 4. What this means for OPF-Wires

**The "mainframe layer" is almost certainly DMPS.** Nothing in the document says "mainframe", but DMPS is the only hop between the feeders and OPF and it is the flat-file sender. Confirm with the owner.

**DMPS is a hub, not a BPM-only pipe.** Seven feeder systems land in DMPS. The owner's description covered BPM -> case -> mainframe -> OPF. Removing DMPS from the wire path raises the question of what happens to the other six feeders: do they stay on DMPS for now, move to the API too, or is OPF-Wires scoped to BPM-Deposits only?

**There is already an API integration pattern between DFS and OPF.** The OFAC path uses Layer 7, ECC API, an event bus and a Treasury API on OCP. The outbound wire API call could reuse the same network zones and the Treasury API component, but OCP is likely on-prem and may itself be in scope for the cloud move.

**Two other file paths touch OPF.** OPF -> CDF -> Snowflake archive (DFTP) and OPF <-> FRB/banks (SFTP, FIS-managed). The archive path is DFS-hosted and should be checked against the cloud deadline; the FRB path is FIS's problem.

**The document is v1.0 from May 2022, before the acquisition.** Treat it as the design intent, not the current state. Ask for the latest revision and page 6.

**OPF already supports single wire processing.** p3 lists "individual wire payment processing" as a supported process, so a per-wire API submission is within OPF's stated capability, not a new mode.

## Open questions raised by this reading

1. Is DMPS the mainframe system the owner referred to? Is it a single system or a mainframe batch suite?
2. Scope: BPM-Deposits only, or all seven feeders?
3. What is the current version of this document, and what does page 6 show?
4. Is Treasury API (OCP) live today, and where is OCP hosted? Is it moving to cloud?
5. Which OFAC path is live: Compliance Link (text) or Discover OFAC via ECC API (diagrams)?
6. Does the DFS-hosted archive path (OPF -> CDF -> Snowflake) need to change?
7. What does DMPS do beyond forwarding: enrichment, dedupe, batching, formatting to OPF's file layout? That logic must move somewhere.
