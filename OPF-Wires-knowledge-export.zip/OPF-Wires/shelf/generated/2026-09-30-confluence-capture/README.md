# Confluence capture: DFS OPF Convergence

123 phone photos of the Capital One Confluence space "Payment Infrastructure Engine" (space key PIE), provided by the owner on 2026-09-30. The pages were photographed around 2026-09-29 to 2026-09-30 and were changing daily at the time.

## What is in this folder

| File | What it is |
|---|---|
| `program-digest.md` | The whole program explained: why, phases, scope, dates, people, architecture, open questions |
| `pod3-digest.md` | Pod 3 in detail, the owner's pod, tied back to the FIS meeting |
| `pages/IMG_NNNN.md` | Word-for-word transcription of each photo, with diagram inventories and legibility notes |
| `README.md` | This index |

Original photos: `shelf/files/images/processed/IMG_9758.jpg` to `IMG_9881.jpg`. There is no IMG_9771.

## How the transcriptions were made

Each photo was cut into enlarged tiles and transcribed verbatim, one file per photo. Consecutive photos of the same page overlap, so text repeats across files. Uncertain characters are marked `[?]`, unreadable text `[illegible]`, and text running off the screen `[cut off]`. Four transcriptions were spot-checked against the photos (IMG_9758, IMG_9820, IMG_9840, IMG_9852) and matched.

To find something, search the `pages/` folder for the term. To read one Confluence page end to end, read its photos in order using the map below.

## Page map

Confluence page tree, as seen in the sidebar (9846):

```
DFS OPF Convergence                                  (charter: Overview and Open Questions tabs)
  ADR
  DFS OPF High level solution workflow:
    File Ingestor
      ADR-0001 Ingesting DFS Wire Payments - pain.001 v9 vs PRAPI JSON over EFG
      ADR-0002 Converge DFS GPN Wires from OPF (FIS) onto PayX (EP) + OnePay
      ADR-0003 Phase 1 Interim - Converge DFS GPN Wires to PayX, Settle in OPF (FIS)
        Pod 1 - ADR-0003        Capabilities 1, 7, 9
        Pod 2 - ADR-0003        Capabilities 5, 6, 8, 12, 13, 14, 26
        Pod 3 - ADR-0003        Capabilities 2, 3, 4, 10, 11, 21, 22, 23, 25
        Pod OnePay - ADR-0003   Capabilities 15 to 20
      ADR-0004 Phase 2 - Complete the OPF (FIS) Exit from the Phase 1 End-State
  High Level Design
    Current OFAC flow
  Pod 2 (PayX) Documentation and Tracking
```

| Photos | Confluence page | What it covers |
|---|---|---|
| 9758 to 9760 | DFS OPF Convergence, Overview tab | Stakeholders, goals, scope, pods, hard deadlines, milestones |
| 9761 to 9770 | DFS OPF Convergence, Open Questions tab | Consolidated open questions tracker v6: 29-row checklist, coverage map of 21 ADR questions, backlog, discrepancy log, takeaways |
| 9772, 9773 | "DFS Integration" diagram (PDF) | Older Option 1 architecture through PIE, Fedwire and SWIFT |
| 9774, 9776 | DFS OPF High level solution workflow | Two options, recommended option, seven decision points |
| 9775 | "DFS Wire Integration - Recommended" diagram (PDF) | Recommended target architecture with sticky-note questions |
| 9777 to 9786 | ADR-0001 | File-based ingestion decision (since overtaken) |
| 9787 to 9796 | ADR-0002 | Full convergence onto PayX; capability list; dependencies; open questions. 9789 is the target-state diagram. |
| 9797 to 9810 | ADR-0003 | Phase 1 interim architecture. The core document. 9802 is the Phase 1 diagram. |
| 9811 to 9813 | Capability 1, Payment API Externalization | External Payment Requests API |
| 9814, 9815 | Capability 7, Client Registry | Who may initiate wires |
| 9816 to 9820 | Capability 9, DFS PayX Submission Service | Decrypt, tokenize, idempotency, validation; field-level encryption detail |
| 9821 | Pod 2 page | Page tree only |
| 9822, 9823 | Capability 5, BIC and ABA Enrichment | |
| 9824 to 9828 | Capability 6, OFAC Screening | Includes the Phase 1 screening diagram |
| 9829 to 9831 | Capability 8, FX Integration (JPM direct API) | |
| 9832, 9833 | Capability 12, WIRE-GPN-OUTBOUND saga | The seven saga stages |
| 9834 | Capability 13, Business Rules | Not needed for Phase 1 |
| 9835, 9836 | Capability 14, Account Qualification for Network | |
| 9837, 9838 | Capability 26, Reconciliation | |
| 9839 | Pod 3 page | Page tree only |
| 9840 to 9846 | **Capability 2, OPF API integration** | FIS API contract, outstanding questions, comments |
| 9847, 9848 | **Capability 3, Submit Request to OPF API** | Ten-step sequence |
| 9849 | **Capability 4, Account Qualification for Corporate (eBAM)** | |
| 9850 to 9853 | **Capability 10, Wire II pain.001 generation** | Version 9 to version 11 mapping |
| 9854 | **Capability 11, Flat Files consolidation** | Blank template |
| 9855 | **Capability 21, Outbound International Drawdowns** | Blank template |
| 9856 | **Capability 22, VPN appliance replacement** | |
| 9857 | **Capability 23, DFS Okta to Capital One SSO** | |
| 9858 to 9864 | **Capability 25, Reports to OneLake** | Includes a full setup guide and reference links |
| 9865 | Pod OnePay page | Page tree only |
| 9866 to 9868 | Capabilities 15, 16, 17 | Blank templates |
| 9869 | Current OFAC flow | Today's screening path |
| 9870 to 9881 | ADR-0004 | Phase 2: full OPF exit |

Bold rows are Pod 3.

## Not captured

Pages and documents that are referenced but not among the photos:

- The very top of the Overview tab, above "Resourcing", and the first bullet of its right-hand risk panel
- Capabilities 18, 19 and 20 (OnePay)
- The "ADR" page, other children of "High Level Design", and "Pod 2 (PayX) Documentation and Tracking"
- Related pages named on the charter: Phase 1 Dependency Map, Skeleton Project Plan
- The PRD pages Catherine Hu mentions, including "PRD: DFS initiated wires (AKA OPF wires) - Saga Flow"
- The source deck "OPF Wires Convergence Solution Options" (rev 2026-09-10, 17 slides)
- `UEAPI.json`, `OPF Convergence_Capabilities.xlsx`, `DFS OPF Convergence_Dependencies.xlsx`
- The draft API contract in `cof-sandbox/ep-external-payment-request-api`
- Several long lines that ran off the right edge of the screen. These are marked `[cut off]` in the transcriptions.
