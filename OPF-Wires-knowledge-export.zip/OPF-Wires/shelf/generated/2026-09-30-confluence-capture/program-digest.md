# DFS OPF Convergence: what the Confluence space says

Digest of 123 photos of the Capital One Confluence space "Payment Infrastructure Engine" (space key PIE), taken by the owner and transcribed on 2026-09-30.

- Word-for-word transcriptions: `pages/IMG_NNNN.md` in this folder, one per photo.
- Original photos: `shelf/files/images/processed/IMG_9758.jpg` to `IMG_9881.jpg` (IMG_9771 does not exist).
- Page-to-photo map: `README.md` in this folder.
- Pod 3 detail: `pod3-digest.md` in this folder.

Citations below give the photo number, for example (9797). The Confluence pages were changing daily when photographed, around 2026-09-29 to 2026-09-30. Treat this as a snapshot.

---

## 1. The program in one page

**Name.** DFS OPF Convergence. Program code WS4, "DFS Wires". (9758)

**Why it exists.** Discover (DFS) wires are processed today by OPF, a wire platform that FIS hosts. Under the Capital One and Discover deal, every DFS-owned application on DFS data centres or DFS cloud must move to Capital One by **May 17, 2027**. This date is hard and contractual. (9797, 9758)

**The key insight.** OPF itself is hosted by FIS, not by DFS, so OPF does not have to move by May 2027. Only the DFS-owned components around it do. That reading of the deal is what makes a two-phase plan possible. It is recorded as an assumption that "should be confirmed in writing". (9797, 9810)

**The DFS-owned components that must go by May 17, 2027** (9797, 9798):
- Monetary Transfers Application (MTA), on the mainframe
- Compliance Link and the DFS services built around it: OFAC service, treasury API, treasury subscriber service
- DFS Quantum
- CMOD and OCM, the reporting stores
- DFS Okta and the DFS-operated VPN appliances

**The plan: two phases.**

| | Phase 1 (ADR-0003) | Phase 2 (ADR-0004) |
|---|---|---|
| Idea | Move wire origination and processing into Capital One's PayX and OnePay. Keep OPF only as the gateway to the correspondent banks, reached by API. | Capital One connects to the correspondent banks itself. OPF is switched off. |
| Go-live | April 2027 | September 2027 |
| End marker | Legacy DFS shutdown, May 17, 2027 | OPF decommission, Q4 2027 |
| Status | In progress | Not started |

**What is in scope** (9759):
- **GPN wires** (Global Network Payments): Discover Network, Pulse, DN, SciFi/ACSS, WorldPay channels. About 95% of wire volume.
- **Corporate wires**: manual and templated, initiated in OnePay. Low volume, high value. Includes net-new outbound international drawdowns.

**What is out of scope** (9759):
- **Consumer and BPM wires.** These belong to a separate program called PIX.
- The Correspondent Bank Adaptor, which is Phase 2.
- GL accounting, Nostro management and Recon+, which Global Finance and Treasury own.

**The biggest risk is commercial, not technical.** The FIS contract for OPF must be extended to about Q4 2027. It is not yet secured. ADR-0003 says: "Without it, Phase 1 is not deliverable." (9798, 9761)

## 2. Milestones

| Date | Milestone | Source |
|---|---|---|
| Oct 2026 to Jan 2027 | Engineering build window for most PayX capabilities | 9799, 9800 |
| Oct 2026 to Feb 2027 | OnePay build window | 9800 |
| Q4 2026 | OPF upgrade, after which OPF reports support CSV. DFS Quantum decommission, about Q4 2026. | 9858, 9798 |
| Early 2027 | Compliance Link decommission. OFAC screening must have moved by then. | 9759 |
| Feb 2027 | Phase 1 development and system integration testing complete. Phase 2 build starts. | 9758, 9870 |
| Mar 2027 | Phase 1 end-to-end and user acceptance testing complete | 9758 |
| Apr 2027 | Phase 1 go-live | 9758 |
| **May 17, 2027** | **Legacy DFS shutdown. Hard, contractual.** | 9758, 9759 |
| Jul 2027 | Phase 2 development and system testing complete | 9758 |
| Aug 2027 | Phase 2 end-to-end and acceptance testing complete | 9876 |
| Sep 2027 | Phase 2 go-live | 9758 |
| Q4 2027 | OPF decommission, gated on the FIS contract extension | 9759 |
| Nov 13, 2027 | ISO 20022 specification update, date to be confirmed | 9873 |

Confirmed wire cut-offs: Pulse to Chase 9:00 AM ET, DN to Chase 10:00 AM ET. Other banks are an open question. (9760)

## 3. Who is who

**Program stakeholders** (9758)

| Role | Name | Notes |
|---|---|---|
| Program sponsor | Rudy Antonini | |
| Product owner | Jen Crowther | |
| Architecture and technical lead | Kiran Iruku (full name on bylines: Naga Kiran Irukuvarjula) | PayX architecture and technical delivery decisions across all pods |
| Product lead | Dylan Pensabene, Catherine Hu | Requirements for Payment API Externalization, PayX capabilities, OPF API integration |
| Pod and team alignment | Kaushik Ravichandran | Author of all four ADRs. Reviews ADR-to-pod mapping with Kiran. |
| NCR legal and data segregation | Rudy, Jen Schaffer, Travis Goad | Sign-off still pending |
| Compliance Link to Bridger cutover | Kenneth McCartney | OFAC contingency |
| Treasury and eBAM | Andre Barker | The new real-time eBAM API |
| Correspondent banks and capital markets | Ryan Kushner | FX rates, bank testing timelines |
| Settlement agent closure | Jason Kemper, EPGO, Legal | Must close before Phase 2 build lock |
| OPF and FIS contract extension | Vendor Management, EPGO | Program-level gate, not yet secured |
| Technical program manager | Joe Kataoka (byline: Yasuhiko Kataoka) | Maintains the open questions tracker |
| Program management lead | Dan Rahusen | |

**Others who appear on the pages**

| Name | Where | Role as shown |
|---|---|---|
| Cameron Mayor | Author of the Pod pages and most capability pages; diagram author | Engineering lead for the capability write-ups |
| Vinod Kumar Gade | 9823, 9835 | Tech lead for the Account Qualification and Bank Availability services |
| Rahul Patel | 9823 | Commented with questions on BIC and ABA enrichment |
| Susan, Scott | 9795, 9808 | GPN and MTA subject experts. Surnames not shown. |
| Beatrice | 9856 | Assigned the question on what OVA is used for |
| Bert at FIS | 9824 | The FIS contact awaited on disabling OFAC in OPF |
| Subha | 9841 | To confirm how batch failures are seen today |
| Jose, Bill | 9807 | Capital Markets contacts for JPM FX |
| Ashwin, Joseph Kim | 9808 | Owners of the contingency and non-OPF wires decisions |
| Raji C | 9807 | PIX programme contact |
| John Tilmon | 9810 | Enterprise Architecture, author of the encryption key rotation pattern |
| Khushboo Shah | 9829 | Author of the DFS to JPMC FX interface specification |
| Zelma | 9793 | Confirmed OPF has only a domestic drawdown template |
| Mathew Flournoy, Vincenzo Sposito, Kelly Z., Jennifer Cruz, Nadia Bolton, Erin Beckmann, Gene Dean, Vivek Gupta, Mike Lehner, Stella Hu, Michelle Provost, Nick Cichon, David McDaniel | 9794 | Contacts on program and business open questions in ADR-0002 |

## 4. How wires work today

From ADR-0002 and ADR-0003 (9787, 9797) and the older diagrams (9775, 9869):

1. GPN channels produce wire instructions: Pulse, EPP, SciFi, ACSS, WorldPay, DN.
2. The **Monetary Transfers Application (MTA)** on the DFS mainframe turns them into flat files and sends them to OPF. MTA also decides which Nostro account is used and produces a daily contingency file that can be uploaded to bank portals by hand.
3. **OPF** at FIS does the rest: enrichment, origination including DCI, validation and risk filters, OFAC screening through Compliance Link, holiday calendar and value dating, routing rules, FX, and reporting through CMOD and OCM.
4. OPF sends files to the **correspondent banks**: JPMC, Citi, BNY, BoA. The banks hold the Nostro accounts and settle the wires. Capital One is not the settlement agent.
5. Corporate wires are keyed manually by operations staff in OPF's Payment Origination (PO) screens, using templates.
6. When a bank rejects a wire, the rejection arrives as a NACK and OPF leaves the payment marked "processed". The documents call this out as something the new design must improve. (9793)

**Current OFAC path** (9869): OPF, then FSIS and its adaptor, then the DFS Layer 7 gateway, then the OFAC Screening Service, then Accuity Compliance Link. The approve or reject answer returns through Kafka MQ, the Treasury OFAC Subscriber Service and the Treasury API back to OPF.

## 5. Phase 1 in detail (ADR-0003)

ADR-0003 is titled "Phase 1 Interim: Converge DFS GPN Wires to PayX, Settle in OPF (FIS)". Author Kaushik Ravichandran, dated 2026-09-10, status Proposed, pending Architecture Review Board. Review by 2026-10-31. (9797)

### The five defining changes (9799)

| # | Change | Lasting or temporary |
|---|---|---|
| 1 | GPN connects to PayX through the External Gateway and a new API, instead of sending files | Permanent |
| 2 | **PayX connects to OPF by API.** PayX submits processed wires to OPF and consumes acknowledgements. OPF keeps routing rules, bank integration, value dating. | **Transitional. Thrown away in Phase 2.** |
| 3 | PayX connects to JPMorgan directly for FX rates | Permanent |
| 4 | Reports go to OneLake instead of CMOD and OCM | Permanent |
| 5 | DFS VPN appliances replaced; DFS Okta moved to Capital One single sign-on | Permanent |

### The flow (9802, 9818)

```
DFS Payment Network Originator            OnePay (operators, templates, approvals)
        |  internet, OAuth, encrypted account numbers        |  manual wires
        v                                                    v
DX External Gateway --> DFS PayX Submission Service ----> Payment Request API (PRAPI)
                        (decrypt, tokenize)                  |
                                                             v
                 PayX saga WIRE-GPN-OUTBOUND
   INIT -> CLIENTREGISTRY -> BANKVALIDATION -> ACCOUNTQUALIFICATION -> OFAC -> OPFRAIL -> OPFCLEARING
                                                                                |           |
                                                         Wire II builds pain.001 V11 JSON   |
                                                         and puts it on a queue (SQS)       |
                                                                                            v
                                                     Submit Request to OPF API --> FIS CodeConnect --> OPF
                                                                                                        |
                                                                                   files to JPM, Citi, BNY, BoA
```

### The 26 capabilities (9799 to 9801)

N is net new, E is an enhancement. The table on the page says "25 line items" but runs to 26.

| # | Capability | Class | Pod | Note |
|---|---|---|---|---|
| 1 | Payment API externalization | N | Pod 1 | Hard gate. Nothing reaches PayX until this exists. |
| 2 | OPF API integration | N | **Pod 3** | Hard gate. Transitional. |
| 3 | Submit Request to OPF API | N | **Pod 3** | Transitional. Depends on 10. |
| 4 | Account Qualification for Corporate (eBAM) | N | Pod 3 in the page tree, Pod 2 in the tracker | Blocked on a new eBAM API |
| 5 | BIC and ABA enrichment | E | Pod 2 | Extends the Bank Validation service |
| 6 | OFAC screening | E | Pod 2 | Cannot be deferred |
| 7 | Client Registry | E | Pod 1 | |
| 8 | FX integration (JPM direct API) | N | Pod 2 | Blocked on contract and design. Largest engineering item. |
| 9 | DFS PayX Submission Service | N | Pod 1 | |
| 10 | Wire II: pain.001 generation | E | **Pod 3** | Cannot be deferred |
| 11 | Flat Files consolidation | N | **Pod 3** | Scope in question. Page is blank. |
| 12 | WIRE-GPN-OUTBOUND saga | N | Pod 1 in the tracker, Pod 2 in the page tree | |
| 13 | Business Rules | N | Pod 2 | Not needed for Phase 1 (9834) |
| 14 | Account Qualification for Network | N | Pod 2 | |
| 15 to 20 | OnePay: creation and approval, templates and roles, user access, repairs and cancellations, template management, template migrations | N | Pod OnePay | 151 operations users and 500 templates to migrate. Pages 15 to 17 are blank templates. |
| 21 | Outbound international drawdowns | N | **Pod 3** in the page tree, OnePay track in the ADR table | Page is blank |
| 22 | VPN appliance replacement | N | **Pod 3** | |
| 23 | DFS Okta to Capital One single sign-on | N | **Pod 3** | |
| 24 | DFTP rule change | N | Reporting | Assumed to be configuration only |
| 25 | Reports to OneLake | E | **Pod 3** | |
| 26 | Reconciliation | E | Pod 2 | |

Items 2 and 3 are the only transitional ones. Two items cannot slip out of Phase 1: OFAC screening, and Wire II pain.001 generation. (9803)

### Pods and delivery (9759, 9804)

- **Pod 1: Externalize PRAPI.** Clears the first hard gate, then joins Pod 2.
- **Pod 2: PayX capabilities.** Runs the whole phase. Builds the permanent assets.
- **Pod 3: Connect to OPF and Reports.** Vendor-facing and transitional. "Smallest scope, so frees up earliest", then joins Pod 2.
- **Pod OnePay.** A separate, larger track. It paces the February 2027 milestone.
- Staffing: 9 engineers, three per pod. This is recorded as closed at 9, although the ADR text still shows a "3 or 9" question.

### Explicitly not in Phase 1 (9803)

Correspondent Bank Adaptor; outbound file transfers and bank acknowledgements through EFG; routing rules in PayX; clearing date and holiday calendars; duplicate checks and risk filters; Nostro, GL and Recon+; a batch ingestor; ACH convergence.

### If OnePay is late (9806)

Manual fallback: keep using PO in OPF for initiation at about 80 wires a day, screen those manually for OFAC, and process about 6 FX wires a day through bank portals.

## 6. Phase 2 in brief (ADR-0004)

Author Kaushik Ravichandran, dated 2026-09-10, status Proposed. Review by 2027-01-31. (9870, 9871)

- Capital One builds a **Correspondent Bank Adaptor** that sends pain.001 and pain.008 files to the banks through EFG and receives pain.002 acknowledgements. Six banks: JPMC, Citi, BNY, BoA, Mellon, Wells. (9874)
- Banks are cut over **one at a time**, with a parallel run and the option to fall back to OPF. Teardown happens only after the last bank is stable. (9875, 9876)
- The critical path is each bank's connectivity specification and certification. It is externally paced. "No staffing level compresses bank certification windows." (9875)
- 29 line items: 16 new, 6 enhancements, 7 teardown. The teardown items have no effort estimate anywhere. (9874, 9875)
- **What Phase 2 removes** (9873): the PayX to OPF API integration, the OPF acknowledgement ingestion, the OPF-shaped status mapping, the FIS credentials, the FIS runbooks. In other words, most of what Pod 3 builds in Phase 1.
- Seven-step OPF decommission plan ending in terminating the FIS contract. Step 6, extracting wire history from OPF before access is lost, is flagged as easy to miss. (9877)
- End state is called **Clearwater**: all wires processed in PayX with no dependency on PIE. (9871)

## 7. How the design got here: the four ADRs

| ADR | Date | Decision | Standing now |
|---|---|---|---|
| ADR-0001 (9777 to 9786) | 2026-08-19 | DFS builds a Network Payment Gateway that converts channel files to pain.001 v9 and sends them through EFG. Capital One converts them to PRAPI. | Overtaken. ADR-0003 replaced file delivery with an API. |
| ADR-0002 (9787 to 9796) | 2026-08-27 | Rebuild everything in PayX and OnePay with direct bank connectivity, all by May 2027. | This is now the Phase 2 target. Judged too risky for one step. |
| ADR-0003 (9797 to 9810) | 2026-09-10 | Phase 1 interim: process in PayX, settle through OPF by API. | Current working document. |
| ADR-0004 (9870 to 9881) | 2026-09-10 | Phase 2: finish the OPF exit. | Current. |

All four are "Proposed". None is ratified by the Architecture Review Board.

An older page, "DFS OPF High level solution workflow" (9774, 9776), lists seven decision points and two options. Its diagrams (9772, 9773, 9775) predate the phased plan.

## 8. Open questions that matter most

The charter page carries a consolidated tracker, version 6, re-confirmed 2026-09-29 (9761 to 9770). It has 29 rows and maps to 21 numbered questions in ADR-0003 (9808, 9809).

| Topic | State | Ref |
|---|---|---|
| FIS contract extension to Q4 2027 | Not secured. Gates everything. | 9798 |
| Wire Watch fraud screening for Corporate wires | Not addressed on any page. Highest-priority unassigned item. | 9762 |
| OPF acknowledgement mechanism | Design now exists: 202 means accepted for processing, the real outcome comes as pain.002 over MQ. Not yet validated with FIS. | 9763 |
| pain.001 version | Resolved: build to the FIS specification's version 11, which keeps version 9 type names. Do not use the ISO version 11 schema. | 9763, 9853 |
| FX design | Two conflicting designs. No JPM contract. No way to unwind a booked trade. Cannot be sized. | 9763, 9830 |
| eBAM real-time API | Does not exist. Another team must build it. | 9762, 9849 |
| Which fields DFS encrypts; whether DFS is onboarded for key exchange | Open | 9764 |
| Flat Files consolidation | May disappear now that ingestion is by API | 9764 |
| Compliance Link to Bridger | Cannot be deferred. Waiting on FIS. | 9762, 9824 |
| Contingency if systems are down | Build or accept the manual route: undecided | 9764 |
| Consumer and BPM wires if the PIX program slips past May 2027 | No solution. Logged as a risk. | 9794, 9807 |

## 9. Inconsistencies in the source pages

These are in the Confluence pages themselves, not transcription errors.

1. **Saga name.** Capability pages say `WIRE-GPN-OUTBOUND`. The tracker says it was renamed `WIRE-OPF-OUTBOUND` on 2026-09-29. A comment on the page says "update saga name". (9761, 9832, 9833)
2. **Routing key.** The Capability 12 page says PRAPI accepts `paymentTypeCode` of `opf`, then says "on receiving `paymentType = "gpn"`". (9832)
3. **Pod ownership.** Capability 4 is Pod 2 in the tracker and under Pod 3 in the page tree. Capability 12 is Pod 1 in the tracker and under Pod 2 in the page tree. Capability 21 is under Pod 3 in the page tree and on the OnePay track in the ADR table. (9761, 9821, 9839, 9800)
4. **Counts.** "25 line items" but 26 rows. "Five capability pages advanced" but six listed. (9799, 9761)
5. **Template count.** 300+ in ADR-0002, 500 in ADR-0003. (9790, 9800)
6. **Corporate share of volume.** "Under 1%" in ADR-0002, "under 5%" in ADR-0003. (9787, 9797)
7. **Which banks.** Four today (JPMC, Citi, BNY, BoA); six in the Phase 2 target (adds Mellon and Wells). Added 2026-10-05 after the owner's question: "BNY" and "Mellon" are listed as separate entries on every page that gives the six (9767, 9788, 9791, 9823, 9874 to 9876, 9879), but BNY and Mellon merged in 2007 and are one banking group. Either the pages double-count, or they mean two separate legal entities or connections inside that group. Not confirmed; see action 54.
8. **ADR-0003 main text lags its capability pages.** It still lists the acknowledgement mechanism and staffing as open.
9. **Kenneth McCartney** in the stakeholder table is written "Kenney McCarthey" in the ADR-0003 dependency table. (9758, 9807)
