# Pod 3: Connect to OPF and Reports

What the Confluence pages say about the pod the owner belongs to. Snapshot from photos taken around 2026-09-29 to 2026-09-30. Transcriptions are in `pages/`. Citations give the photo number.

Read `program-digest.md` first for the program context.

---

## 1. What Pod 3 is for

Pod 3 builds the bridge from Capital One's PayX to FIS OPF, plus the reporting and access changes around OPF. ADR-0003 describes it as "vendor-facing and transitional, retired at the full OPF exit. Smallest scope, so frees up earliest", after which its engineers join Pod 2. (9804)

Two things follow from that:
- Most of what Pod 3 builds for the OPF connection is **thrown away in Phase 2** (9873). The design should be as thin as it can safely be.
- Pod 3 owns one of the two **hard gates** of Phase 1. No wire reaches a correspondent bank until the OPF connection works. (9799)

**Capabilities under the Pod 3 page** (9839, 9846):

| # | Capability | State of the page | Lasting? |
|---|---|---|---|
| 2 | OPF API integration | Written. Many questions pending with FIS. | Transitional |
| 3 | Submit Request to OPF API | Written 2026-09-29 | Transitional |
| 4 | Account Qualification for Corporate (eBAM) | Written. Blocked on another team. | Permanent |
| 10 | Wire II: pain.001 generation | Written in detail | Transitional conversion, reusable converter |
| 11 | Flat Files consolidation | Blank template | In question |
| 21 | Outbound International Drawdowns | Blank template | Permanent |
| 22 | VPN appliance replacement | Written. Decision waits on FIS. | Temporary |
| 23 | DFS Okta to Capital One single sign-on | Short | Permanent |
| 25 | Reports to OneLake | Written, with a full setup guide | Permanent |

The pod pages were created by Cameron Mayor on 2026-09-28. Capability pages are mostly by Cameron Mayor, updated by Kaushik Ravichandran.

## 2. The core path: three capabilities that work together

Capabilities 10, 3 and 2 form one chain. The pages give the same ten-step sequence on both the Capability 3 and Capability 10 pages (9847, 9851):

```
PayX            Wire II          SQS        Submit Request      OPF API
                                              to OPF API
 | (1) call        |               |               |                |
 |---------------->|               |               |                |
 |     (2) convert Payment Object  |               |                |
 |         -> pain.001.001.11 (V11)|               |                |
 |         -> convert XML to JSON  |               |                |
 |                 | (3) publish msg               |                |
 |                 |-------------->|               |                |
 | (4) acknowledgment              |               |                |
 |<----------------|               |               |                |
 | (5) produce .OPFRAIL            |               |                |
 |                 |               | (6) consume   |                |
 |                 |               |-------------->|                |
 |                 |               |               | (7) POST pain.001 (JSON)
 |                 |               |               |--------------->|
 |                 |               |               | (8) 202 + pain.002 (async/MQ)
 |                 |               |               |<---------------|
 |       (9) final status (accepted / rejected)    |                |
 |<------------------------------------------------|                |
 | (10) accepted -> produce .OPFCLEARING           |                |
 |      rejected -> produce .OPFCLEARING.STOP      |                |
```

In plain words: once a wire has passed all the PayX checks, Wire II writes it in the format OPF wants and drops it on a queue. A separate small service picks it up, calls FIS, and later tells PayX whether FIS accepted or rejected it.

Where this sits in the PayX saga (9832, 9833): the last two stages.
- `OPFRAIL` is Capability 10. PayX reaches this stage when Wire II acknowledges.
- `OPFCLEARING` is Capability 3. Accepted ends at `.OPFCLEARING`. Rejected ends at `.OPFCLEARING.STOP`, which is terminal.

### Capability 10: Wire II, pain.001 generation (9850 to 9853)

**Job.** Turn the PayX payment object into a pain.001.001.11 message, render it as JSON, publish it to SQS, and acknowledge PayX. Wire II does not call FIS itself.

**Approach chosen.** Extend the existing version 9 converter instead of writing a new one.

**The existing converter** (9851):
- Repository `PmtInfrEngn-wire-ii-intg`, package `com.capitalone.wirerail.wireiiintg.converter.painv9`, about 820 lines.
- `PaymentInitiationV9Converter` implements Spring's `Converter<SDPPayload, InitiatePain001V09Payments>`.
- It delegates to `GroupHeaderConversionUtilV9` and `PaymentInfoUtilV9`, with party helpers in `model.v9`: `Debtor`, `Creditor`, `UltimateDebtor`, `UltimateCreditor`.
- The source object is `SDPPayload`.

**Type changes from version 9 to version 11, per the FIS specification** (9852, checked against the photo):

| Element | Version 9 type | Version 11 type | What changes |
|---|---|---|---|
| Message root | `CustomerCreditTransferInitiationV09` | `CustomerCreditTransferInitiationV11` | Adds message-level `supplementaryData` |
| Group header | `GroupHeader85` | `GroupHeader95` | Adds `initiationSource` |
| Payment instruction | `PaymentInstruction30` | `PaymentInstruction40` | Adds `requestedAdviceType`, `instructionForDebtorAgent`, `chargesAccount`, `chargesAccountAgent` |
| Credit transfer transaction | `CreditTransferTransaction34` | `CreditTransferTransaction54` | Adds a third intermediary agent, `instructionForDebtorAgent`, `mandateRelatedInformation`, `chequeInstruction` |
| Instruction for creditor agent | `InstructionForCreditorAgent1` | `InstructionForCreditorAgent3` | Code plus 140-character text |
| Remittance information | `RemittanceInformation16` | `RemittanceInformation21` | Structured form is `StructuredRemittanceInformation17` |
| Cash account | `CashAccount38` | `CashAccount40` | Renamed |
| Payment identification | `PaymentIdentification6` | `PaymentIdentification6` | Unchanged, but see UETR below |
| Party, agent, address, amount, payment type | `PartyIdentification135`, `PostalAddress24`, `AmountType4Choice`, `PaymentTypeInformation26`, `ExchangeRate1`, `DateAndDateTime2Choice`, agent type with suffix 6 | Same names | No change. Existing mapping carries over. |

**What actually needs work** (9852, 9853):
1. **Output format.** The old converter produces XML through JAXB. OPF takes JSON. The page calls this "the largest single change and easy to underestimate". Supplementary data must become a JSON object. Dates become ISO-8601 strings.
2. **Business Application Header.** New. Five mandatory fields with no version 9 equivalent: `from`, `to`, `businessMessageIdentifier`, `messageDefinitionIdentifier`, `creationDate`.
3. **UETR.** The old code does not populate it. Confirm whether OPF requires it.
4. **Supplementary data.** The shape changes to one type per containing element. "Confirm with FIS what OPF expects inside the envelope." Existing properties for FX debit currency, FX debit amount, initiator and approver need a home.
5. **Enumerations become plain strings**, so validation moves into explicit code.
6. **New optional fields** need an explicit decision each.
7. **Known workarounds** in the old code must be consciously kept or dropped: a structured-address flag that works around a PIE defect, sender-specific clean-up of bank-to-bank text, and 140-character chunking.
8. **Structure.** Add a parallel `painv11` package and `model.v11` helpers. Both versions must coexist.

**Two warnings on the page** (9853):
- The FIS "version 11" is FIS's own JSON rendering. It is not the ISO 20022 version 11 schema. ISO renamed several types that FIS did not. "Do not map against the published ISO V11 XSD. Map against the FIS specification." (Open question 20)
- The program has talked about pain.001 version 9 for the inbound side while OPF needs version 11 outbound. Either Wire II produces both, or one reference is wrong. (Open question 12; the tracker marks it resolved in favour of the FIS version 11.)

pain.008, used for drawdowns, is Phase 2 scope for Wire II.

### Capability 3: Submit Request to OPF API (9847, 9848)

**Job.** A dedicated queue consumer that:
1. Takes the JSON pain.001 from the SQS queue.
2. Calls `POST /customer-credit-transfer-initiations` with the `uuid` and `idempotency-key` headers.
3. Reports the final status back to PayX.

**Why a separate service.** A slow or failing FIS call must not block PayX. One component owns idempotency and status feedback. The alternative, submitting from inside Wire II, was rejected for coupling generation to submission.

**Responsibility that is easy to miss.** This service "handles the asynchronous pain.002/MQ outcome and maps OPF sync/async responses to a Payment Exchange status". So it is a consumer of FIS's MQ as well as a caller of FIS's API.

### Capability 2: OPF API integration (9840 to 9846)

**Job.** Establish, secure and catalogue the connection to FIS. It covers authentication, the CodeConnect path, network egress, firewall rules and registration. Generating the message is Capability 10. Sending each payment is Capability 3.

**The contract** (9840, 9844; header and response tables checked against the photo):

| Item | Value |
|---|---|
| Specification | FIS "Enterprise Payments: POM Customer Credit Transfer Initiation", also called the Universal Execution API (UEAPI). OpenAPI 3.0.3, version 1.4.0. File `UEAPI.json`. Owner EP.POMCC.TEAM@fisglobal.com |
| Operation | `POST /customer-credit-transfer-initiations`, operation id `postUniversalExecutionPain1v11` |
| Reached through | FIS CodeConnect |
| Authentication | OAuth 2.0 client credentials, bearer token. Credentials kept in AWS Secrets Manager. |
| Header `uuid` | Required. Identifies the interaction. |
| Header `idempotency-key` | Required. A replay with a different payload is rejected with 422. |
| Header `organization-id` | Optional. FIS processing organization. |
| Body | `businessApplicationHeader` plus `businessDocument.customerCreditTransferInitiation`, which has one `groupHeader` and one or more `paymentInformation` |
| 202 | Accepted for processing. No body. The outcome comes later as pain.002 over MQ. |
| 400 | Syntax validation error |
| 401, 403 | Unauthorized, forbidden |
| 422 | Idempotent request replayed with a different payload |
| 500, 503 | Internal error, unavailable |

**Design points the page draws out** (9844):
- **Idempotency is central.** Keys must be deterministic per payment and stored durably so a retry after a crash reuses the same key. Getting it wrong means duplicate wires or rejected legitimate retries.
- **202 with no body** means acknowledgement handling is a separate piece of work that has to be specified with FIS.
- **`paymentInformation` is an array.** One call can carry several payments. Batch size and frequency are Capital One's to choose, which gives a throughput lever at GPN volume.
- **Account numbers are not encrypted by this contract.** Protection depends on the CodeConnect channel. Pending with FIS.
- The OPF API must be **registered in DevExchange** as a consumed external API.
- A temporary "OPF Integration" service is stood up. Temporary security group and firewall rules are needed, which "will result in a temporary UTEP if they will not be baselined".
- A new application container may be created for it: either `ASVOPF` or `ASVPAYXEXTERNAL`, pending technical leadership. Diagrams already draw an "OPF Integration service" inside `ASVOPF`. (9842)

**Outstanding questions on the page.** Items the page shows in red are waiting on FIS. (9841, 9842)

| Question | State on the page |
|---|---|
| How today's DFS files map to pain.001 (customer info to Ultimate debtor, DFS info to Debtor) | Pending FIS |
| Paperwork required to connect; lead times for UAT and production | Pending FIS |
| Whether FIS must allow-list Capital One subnets | Pending FIS |
| Subnets and ports for firewall rules | Open |
| Encryption or protection for account numbers | FIS "usually do not support this, need to meet with Code Connect on encryption options". Current batch data is PGP encrypted. |
| Whether traffic must be NAT'd on the Capital One side | Cameron Mayor to investigate |
| How processing failures come back | Via MQ as pain.002. Pending FIS. |
| How batch failures are seen today | In OPF screens. Pending FIS and Subha. |
| Retiring the batch component once on the API | Pending FIS |
| Rotating the client secret in Code Connect, and how often | Open |
| Drawdown support | "No support on current API, works for BTR/CTR. Pending confirmation from FIS product." |
| Which pain.002 messages come back today | Only the initial validation message, by file. Not the second or third. |
| UETR versus idempotency key | Can use the same value for each |

**Comments by Kaushik Ravichandran, dated 2026-09-28** (9844, 9845): whether a Capital One id can be used; what the Entity ID is; how to get a client id and secret; whether pain.001.001.11 is the only option; a note reading "MTA - OPF BATCH - OVA - code connect - POST - CTR/BTR / drawdown? should we consume pain.002V10, camt.054V6 (multiple messages), 422 error code, ACCP/RJCT"; and "MTLS/MPLS".

## 3. How this lines up with the FIS meeting

The FIS meeting the owner recorded (see `shelf/generated/2026-09-30-fis-payment-initiation-api-meeting/meeting-summary.md`) is the source of most of the Capability 2 open questions. The Confluence comments dated 2026-09-28 repeat the meeting's topics almost word for word, which also confirms the meeting date.

| Topic | FIS meeting | Confluence | Result |
|---|---|---|---|
| Endpoint, headers, 202 and 422 | Same | Same | Consistent |
| Spec version | 1.4.0 seen on screen | 1.4.0 | Consistent |
| Outcome delivery | pain.002 over MQ; callbacks are future | pain.002 over MQ | Consistent. The design now depends on an MQ link that does not exist yet for Discover, which gets a file today. |
| First status code | Deck showed both ACTC and ACCP | Comment mentions ACCP and RJCT; page mentions ACTC and ACCC as the later ones | Still unclear which code is first. Ask FIS. |
| Drawdowns | Not supported by the API | Same, pending FIS product | Consistent. Capability 21 page is blank. |
| Encryption | Transport only | Same, meet Code Connect | Consistent and open |
| Internet exposure | Code Connect is internet-facing | "REST APIs are exposed via the internet" | Consistent |
| OVA | Used without explanation | "PEX (aka OVA) - batch ingestion layer" and "Operations Visibility Application" | Resolved |
| PO | Used without explanation | Payment Origination, OPF's manual initiation screens | Resolved |
| VPN alternatives | FIS allows VPN or MPLS | "FIS offers 3 connectivity options"; waiting for details | Partly consistent. The third option is not named. |
| Who calls the FIS API | Not discussed | The Submit Request service in the OPF integration container, fed by Wire II through SQS | Resolved |
| What replaces the mainframe | Not discussed | The mainframe MTA is replaced on the DFS side by a Payment Network Originator that calls Capital One's external API | Resolved |

## 4. The other Pod 3 capabilities

### Capability 4: Account Qualification for Corporate, eBAM (9849)
- Before a wire proceeds, the debit account (a Nostro account) must be confirmed open. Today OPF does this using CBIS and Quantum. It must move to eBAM, Capital One's Nostro system of record.
- OnePay users creating a manual corporate wire must be shown that the account is qualified.
- **Blocker:** eBAM has no real-time API. There is only a dataset refreshed daily at about 22:30, so data can be 24 hours stale.
- **Decision:** partner with the eBAM team to build an API. The Account Qualification service "cannot be extended until the eBAM API is available in non-prod".
- The tracker lists this capability under Pod 2, the page tree under Pod 3. Worth confirming who owns it.

### Capability 11: Flat Files consolidation (9854)
- Blank template. Its scope is in question because GPN ingestion moved from files to an API. If files persist for some channels, those channels have to be named. (9800, 9808)

### Capability 21: Outbound International Drawdowns (9855)
- Blank template.
- Known from elsewhere: OPF has only a domestic drawdown template today, so international drawdown is net new (9793). The external API requires `debtorAgent` for drawdown wire types (9813). ADR-0002 describes it as "DN Issuer Wires to JPMC/BOFA; pain.008 is the outbound instruction; funds flow inward" (9791). An older requirements list mentions pain.013 (9769). The FIS API does not support drawdowns today.
- This is the least defined item in the pod and it collides with an FIS limitation.

### Capability 22: VPN appliance replacement (9856)
- Operations staff reach OPF's PO and OVA screens over VPN. The VPN devices sit in the DFS data centre and would have to move to a Capital One colocation site.
- Open assumption: can they stay, since they serve a vendor-hosted application?
- FIS offers three connectivity options, the physical VPN being one. Waiting on FIS for details. Decision is to be determined.
- PO is not needed after Phase 1 because OnePay replaces it. **OVA is still needed for exception handling**, so one option must be implemented.
- Question assigned to Beatrice: what is done in OVA today, and is it still needed once screening moves to PayX? Pending.
- Temporary. Not needed after Phase 2.

### Capability 23: DFS Okta to Capital One single sign-on (9857)
- Users log into PO and OVA with legacy Discover sign-on. Reconfigure OVA to use Capital One sign-on. PO is not migrated.
- Likely side effect: usernames in OPF change.

### Capability 25: Reports to OneLake (9858 to 9864)
- Today nine PDF reports go from OPF through DFTP to CMOD. CMOD is being decommissioned.
- **Decision:** OPF sends CSV files through EFG into new OneLake datasets, one per report. OneStream tokenizes sensitive fields through Turing on the way in. No custom encryption is built.
- **Constraint:** OPF can only produce CSV after its Q4 upgrade. FIS must commit to changing destinations and file types.
- **Assumption:** report users can move from PDFs to querying CSV data with analytics tools.
- The page includes a seven-step setup guide with internal links: register the dataset in Exchange Catalog, obtain a OneShare, create internal and external partners, set up PGP, create the route, wait for approval, verify delivery. Approval has taken about three weeks in some cases.
- Known traps recorded on the page: dataset registration and route registration are different pages; "delivered by EFG" does not mean "landed in OneLake"; PGP direction is easy to get backwards; tokens may not match the original field length.
- Open question 3: does this replace Mercury streaming for DFS wire data, or run beside it?
- This capability also feeds reconciliation: the OPF report in OneLake is one of the data sources for checking PayX against OPF. (9837)

## 5. What Pod 3 depends on

| Dependency | Who | Why it matters to Pod 3 | Ref |
|---|---|---|---|
| FIS contract extension | Vendor Management, EPGO | Without it there is no Phase 1 | 9806 |
| OPF API specification gaps: acknowledgement mechanism, throughput and rate limits, batch size, OAuth token endpoint and scopes per environment, sandbox and certification access | FIS, Kiran | Blocks Capabilities 2 and 3 | 9806 |
| FIS change request and statement of work | FIS | FIS will not start without them (from the meeting) | meeting summary |
| Code Connect access and credentials | FIS Code Connect team | Needed to call anything | 9841, meeting |
| MQ connectivity for pain.002 | FIS, Capital One network | The status path in Capability 3 | 9847 |
| Network path and firewall rules | Network Engineering, Connectivity Review Forum | Egress to FIS | 9841 |
| eBAM real-time API | Treasury, Andre Barker | Blocks Capability 4 | 9807 |
| OPF Q4 upgrade and FIS commitment on report formats | FIS | Blocks Capability 25 | 9858 |
| FIS detail on the three VPN options | FIS | Blocks Capability 22 | 9856 |
| Payment object from PayX saga | Pods 1 and 2 | Wire II's input | 9832 |

## 6. Questions worth raising, from reading the pages together

These are observations from comparing the pages and the FIS meeting. They are not statements from the sources.

1. **MQ is assumed but not arranged.** The status design rests on pain.002 over MQ. Discover gets a file today. Nobody on the pages owns standing up the MQ link.
2. **Which pain.002 messages will be switched on, and which status means "accepted"?** The saga needs one clear accepted signal and one rejected signal. FIS described up to three reports and the deck was inconsistent on the first code.
3. **OPF marks payments "processed" even when a bank rejects them.** If PayX maps OPF's acceptance to `.OPFCLEARING`, a later bank rejection is invisible in Phase 1. The pages accept this as a known weakness until Phase 2.
4. **Drawdowns have no route.** The FIS API does not support them and the capability page is blank, yet they are Phase 1 scope.
5. **Sensitive data crosses the internet to FIS without field-level encryption**, while the inbound side from DFS requires it. The asymmetry will need a security position.
6. **Rate limits and batch size at GPN volume** are unknown. GPN is about 95% of wires.
7. **Trace context across the FIS boundary.** ADR-0003 warns that the settlement leg becomes unobservable if tracing does not survive the OPF API call. (9805)
8. **Ownership of Capabilities 4 and 21** differs between the tracker, the ADR table and the page tree.
9. **Teardown.** Everything in Capabilities 2 and 3 is scheduled for removal in Phase 2, including credentials and firewall rules. Building with removal in mind is cheaper than discovering it later.
