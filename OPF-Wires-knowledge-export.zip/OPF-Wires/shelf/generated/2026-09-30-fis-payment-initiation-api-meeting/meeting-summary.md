# FIS meeting: Payment Initiation API for OPF wires

**Sources**
- Transcript: `shelf/files/audioRecordings/processed/Opf01-mp3-c4293ac6-bacd.srt` (676 captions, 57 minutes). Cited below as `cue N`.
- Deck photos: `shelf/files/images/processed/IMG_9742.jpg` to `IMG_9755.jpg` (FIS deck "Payment Initiation API", 11 slides, plus 3 photos of the Swagger spec shown live).

**Date.** Most likely 2026-09-28. The slide photos show a recording timestamp of "09-28 at 10.11 to 10.14 AM" (IMG_9753 to IMG_9755). The transcript header says "Meeting created at 29th Sep 2026, 7:47 AM", which is probably when the transcript was generated. Confirm.

**Caveat on the transcript.** It is machine-generated. Speakers are numbered, not named, and some lines are attributed to the wrong speaker. Payment terms are garbled: "pane 1 / pin one / pain one" is pain.001, "paint tools / pain 2" is pain.002, "CAM54" is camt.054, "palm" is POM, "pegs / pecs" is PEX, "C rec" is CR (change request), "item potency key" is idempotency key, "honest transfer" is on-us transfer.

---

## 1. The one-paragraph version

Today a Discover mainframe application bundles wires into flat files and sends them to FIS OPF over DFTP. An OPF batch component converts each file into pain.001 messages and hands them to the OPF processing engine. Capital One/DFS wants to drop the mainframe and instead call an FIS REST API once per wire, sending the pain.001 content as JSON. FIS confirmed the API exists, walked through it, and said the rest of OPF processing stays the same. Two things are not settled: the API does not currently support drawdown requests, and encryption and network connectivity have to be worked out with a different FIS team (Code Connect). Nothing formal can start until a change request is open in the FIS client portal and a statement of work is signed.

## 2. How it works today vs. with the API

**Today (batch)** (cue 24-25, 61-64, 105-117)

```
UI -> BPM case -> mainframe app -> flat file (PGP-encrypted, DFTP) -> OPF batch processor
   -> converted to pain.001, dropped on MQ -> PEX (payment execution) -> files to partner banks
```

**Target (API)** (cue 26-27, 65-80; slide 3 IMG_9744.jpg)

```
DFS/Capital One caller -> HTTPS POST (JSON pain.001 v11) -> Code Connect (FIS API gateway: auth)
   -> POM (Payment Order Manager: quick checks) -> PEX (same engine as today) -> files to partner banks
```

What changes and what does not:
- **Changes:** only the way payments get into OPF. The batch processor is bypassed. A new layer, POM, sits in front of PEX. (cue 65-74, 317-319)
- **Does not change:** PEX, Discover's existing customizations, and what OPF sends onward to the banks. FIS expects no impact "as long as the messages have the same information that you send over the batch". A data mapping exercise will confirm. (cue 313-326)
- **Onward leg:** for Discover, PEX creates batch files that go to partner banks rather than straight to Fedwire. The banks acknowledge, positively or negatively, by dropping a file that OPF picks up. (cue 75-79, 395-410)

## 3. The API

Source: slides 4 and 11 (IMG_9745.jpg, IMG_9755.jpg), Swagger photos (IMG_9746.jpg to IMG_9748.jpg), cue 130-184.

| Item | Value |
|---|---|
| Spec title | Enterprise Payments: POM Customer Credit Transfer Initiation, version 1.4.0, OpenAPI 3.0.3 |
| Spec file shown | `OPF_Wires_Payment_Initiation_CodeConnect_API_S...json` |
| Endpoint | `POST /customer-credit-transfer-initiations` |
| Only endpoint? | Yes, the only one exposed for payment initiation today (cue 130-132) |
| Security | oauth2. Client id and secret come from an application you create in Code Connect (cue 547-555) |
| Header `uuid` | Required. Identifies the API interaction. Echoed in responses. |
| Header `idempotency-key` | Required. Unique per payment. Same value on a retry so OPF can detect duplicates. |
| Header `organization-id` | FIS processing organization id, example 1000. FIS will supply the value. (cue 167-169) |
| Body | `application/json`, a JSON rendering of ISO 20022 pain.001.001.11 |
| Gateway | Code Connect, `https://codeconnect.fisglobal.com/app/home` |
| Product tile | "Product: EP, Universal Execution Origination HostedWires", API "POM Customer Credit Transfer Initiation V1" |
| Environments | Sandbox with mocked responses first, then UAT end to end to the banks (cue 502-507) |

**Payload shape** (slide 4):

```
Pain001v11UniversalApplicationMessage1
  businessApplicationHeader   (1..1, based on head.001.001.02)
    from, to, businessMessageIdentifier, creationDate
  businessDocument            (1..1, based on pain.001.001.11)
    customerCreditTransferInitiation
      groupHeader                            1..1  = OPF "interchange"
      paymentInformation                     1..n  = OPF "instruction"
        creditTransferTransactionInformation 1..n  = OPF "transaction"
          supplementaryData                  0..1  (transaction level)
      supplementaryData                      0..n  (instruction level)
      supplementaryData                      0..1  (interchange level)
```

- The "to" system is always OPF ("XCP or OPF" in the transcript). "from" identifies the sending channel so OPF knows where to send responses. (cue 173-179)
- Supplementary data carries FIS-specific fields. Some will become mandatory once FIS understands the Discover use cases. (cue 265-268)
- JSON is v11 because it is richer. OPF converts it to v9 internally. (cue 149-151)
- UETR: if the caller sends one, OPF passes it on where the downstream format has a field for it. Otherwise OPF generates one if needed. Sending the same value in UETR and idempotency key is acceptable. (cue 188-206)
- Supported payment types: CTR (customer transfer) and BTR (bank transfer). (cue 215, 233)

## 4. What comes back

**Synchronous** (slides 5 and 6: IMG_9749.jpg, IMG_9750.jpg; cue 276-298, 364-371)

| Response | Meaning |
|---|---|
| 202 | Accepted for processing. Passed gateway auth, staging (idempotency key unique, payload intact, byte-for-byte duplicate check) and parsing. Not a confirmation that the wire went out. |
| 422 (and other codes in the spec) | Synchronous reject. Payload could not be read or failed the intake checks. |

**Asynchronous** (slides 7 to 10: IMG_9751.jpg to IMG_9754.jpg; cue 299-312, 355-363, 417-493)

| Channel | Format | Delivery | Notes |
|---|---|---|---|
| Payment Status Report (PSR) | pain.002.001.10 XML | MQ | Up to three per payment, see below |
| Credit/debit notification | camt.054.001.06 XML | MQ | One per successful payment only |
| Business events | FIS JSON | MQ topic (slide also says webhooks) | Lightweight milestone events, carry the same ids |

The three PSRs (slide 8):
1. PSR 1: validation completed in OPF on receipt.
2. PSR 2: debit accounting complete.
3. PSR 3: acknowledgement received from the Fed. For Discover this is the partner bank's file acknowledgement.

A reject at any point produces a PSR with status RJCT, whether OPF rejected it or the bank sent a negative acknowledgement. (cue 372-414)

Status codes (slide 9): ACCP validated and accepted, ACSC debit booking done, ACSP submitted to Fedwire/SWIFT gateway, RJCT rejected, ACCC credit booked for on-us payments.

**What Discover gets today** (cue 327-341, 361-363, 467-483):
- Only the first pain.002 is sent. The later ones are turned off.
- It is delivered by file transfer, not MQ.
- OPF does no accounting for Discover, so PSR 2 does not apply. With the API, FIS expects Discover would want PSR 1 and PSR 3.
- No book transfers through OPF, so ACCC does not apply.

## 5. Deck vs. meeting: where they differ

| # | Topic | Deck says | Meeting says | So what |
|---|---|---|---|---|
| 1 | Business events delivery | "Event Broker (Webhooks) or MQ Topic" (slide 7) | Supported "right now" via MQ topic. Status reports go "only via MQ". Callback API is a "future capability". (cue 302-304, 419) | Do not design around webhooks until FIS confirms they are available in Discover's version. |
| 2 | First status code | Slide 5 shows "ACTC"; slide 9 lists "ACCP" and no ACTC | FIS says Discover currently gets the first and the reject only (cue 467-476, code garbled) | The deck contradicts itself. Ask FIS which code Discover's first pain.002 carries. |
| 3 | PSR 3 trigger | "Acknowledgement received from Fed" (slide 8) | For Discover it is the partner banks' file acknowledgement (cue 395-414, 438-441) | The deck is the standard product; Discover's setup is bank files, not direct Fedwire. |
| 4 | PSR 2 and ACCC | Shown as part of the happy path (slides 5, 8, 9) | Not applicable: no accounting and no on-us transfers for Discover (cue 461-483) | Expect fewer statuses than the deck shows. |
| 5 | pain.002 delivery | To "Bank MQ Manager" (slide 8) | Today Discover receives it by file transfer (cue 340-341) | Moving to MQ is new connectivity on the DFS side. Not discussed as a decision. |
| 6 | Drawdowns | Not in the deck | Not supported by the API today; open item (cue 208-259) | Biggest functional gap. See section 6. |
| 7 | Encryption and network | Not in the deck | TLS only, no field-level encryption; gateway is internet-facing; details deferred to Code Connect team (cue 81-121) | Security review needed on the Capital One side. |
| 8 | Commercials and process | Not in the deck | CR must be open first; SOW needed even for a POC (cue 1-6, 574-596) | Gating items before any build. |
| 9 | Overview diagram | PEX talks to CBIS, Fraud, Sanctions; gateway "e.g. Fedwire" (slide 3) | Not discussed beyond PEX and gateway | Generic product picture. Discover's sanctions path is its own OFAC integration (see the C4 review). |

Everything else in the deck (endpoint, payload structure, 202/422, the three async channels, Code Connect tile) matches what was said.

## 6. Open issues from the meeting

1. **Drawdown support.** The batch path supports drawdowns today. The API is a pain.001 API and supports only CTR and BTR. FIS says pain.001 is the wrong message for a drawdown request and POM validates more strictly than PEX, so repurposing pain.001 needs product input. FIS will check support and roadmap. Capital One called it an important use case and asked for an answer within a day. (cue 208-259, 664-667)
2. **Encryption.** FIS encrypts in transit only. Today the flat file is PGP-encrypted as a whole. Capital One cannot tokenize NPI fields and needs to know its options. To be covered with the Code Connect team. (cue 94-121)
3. **Network path.** Code Connect is exposed over the internet today. Other mechanisms exist depending on the bank. IP whitelisting and alternatives go to the Code Connect call. (cue 81-89, 37-39)
4. **How DFS will receive async responses.** MQ server-to-server, or DFS as an MQ client to an FIS-hosted MQ server. Events via MQ topic subscription. Which pain.002s to turn on. (cue 342-350)
5. **Compliance Link, FX/JPM, VPN access.** Capital One asked for walkthroughs of the Compliance Link workflow and the FX workflow with JPM, and for alternatives to the VPN device operations staff use to reach the OPF screens. FIS usually allows VPN or an MPLS line only. Separate sessions to be scheduled. (cue 616-643, 668-671)
6. **Code Connect access.** The API tile is on request only. FIS needs the list of user emails and Discover's entity id. One DFS team member (Praveen) lost access after logging in once; a ticket is open. (cue 512-533, 556-559, 609-615)
7. **Customizations.** FIS expects no impact but will confirm in data mapping. (cue 313-326)

## 7. Decisions and commitments

- Full conversion to API is the goal. No permanent coexistence. Cutover is phased by file type, with batch staying only during the cutover period. (cue 41-47)
- One CR covers all topics for now; more only if FIS asks. (cue 652-658)
- Capital One wants a POC before signing the full SOW, then integration "within the next couple of months". FIS says even a POC needs a small SOW. Not resolved. (cue 33, 588-596)

## 8. Who was there

17 to 19 participants per the meeting toolbar. Identified from the transcript:

| Transcript label | Who | Side | Evidence |
|---|---|---|---|
| Speaker 1 | Robert, also called Bert and Bob | FIS, engagement lead | Runs the meeting, owns CR and SOW, schedules Code Connect (cue 1-17, 574-577, 673) |
| Speaker 4 | Sujith Sukumaran | FIS, API and solution presenter | Name on screen share (IMG_9746.jpg); cue 17, 48 |
| Speaker 3 | Probably Saurabh | FIS, knows Discover's OPF setup | Answers when Sujith asks "Bert or Saurabh" (cue 328-341) |
| Speaker 2 | Kiran (transcript says "Karen"; corrected by owner) | Capital One/DFS lead | Addressed by name at cue 13; states the plan cue 23-33 |
| Speaker 5 | Koushik (name supplied by owner) | Capital One/DFS technical lead | Asks about encryption, versions, UETR, subscription |
| Speaker 6 | Beatrice | Capital One/DFS | Opening the CR (cue 9, 579-582); has the entity id |
| Mentioned | Praveen | Capital One/DFS | Code Connect login and ticket (cue 512, 547) |

## 9. Terms still unclear

- **OVA** and **PO**: OPF modules with screens that operations staff log into over VPN; payments can be created and modified there. Expansion of the names not given. (cue 25, 627-635)
- **"POS files" / "BTF proc"**: how drawdowns arrive in the batch today. Garbled. (cue 222-223)
- **"five banks"**: possibly the number of partner banks Discover submits to, possibly a transcription error. (cue 400)
- **"callback API"**: Discover is said to already use a callback endpoint on Code Connect. Possibly the OFAC response path shown in the C4 Level 3 diagram. Not confirmed. (cue 499, 612)

## 10. Background the meeting assumed (not from the sources)

These are general ISO 20022 facts added to help read the above. They are not from the transcript or deck.
- pain.001 is a customer credit transfer initiation: "please send this money". pain.002 is the status report on it. camt.054 is a debit/credit notification.
- A drawdown is the reverse of a normal wire: you ask another bank to send funds from an account there. FIS referred to "pain 8" for this. In Fedwire's ISO 20022 implementation the drawdown request message is generally pain.013, and pain.008 is a direct debit initiation. Worth clarifying with FIS which message they mean.
- An idempotency key lets the caller retry safely after a timeout without creating a second wire.
