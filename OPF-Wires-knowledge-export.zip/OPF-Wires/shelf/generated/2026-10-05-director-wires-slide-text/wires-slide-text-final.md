Current Challenges in Wire Operations:
• Outgoing wires rely on DFS-owned legacy integrations due for decommissioning by May 17, 2027, creating complex interdependencies.
• FIS OPF (SaaS) sits at the center of these integrations. Being vendor-hosted, it can remain past May 2027 as the gateway to the correspondent banks, while Monetary Transfer, Compliance Link, DFS Quantum, CMOD and FX move to Capital One. OPF itself is decommissioned in Q4 2027.

Ongoing Efforts and Strategic Coordination:
• Technical Solutioning in Progress: Phase 1 (Apr 2027) moves processing to PayX and OnePay; Phase 2 (Sep 2027) connects PayX directly to the correspondent banks.
• Cross-LOB/Team Coordination: Rigorous collaboration across GPN, Treasury, Finance, Compliance, Operations and FIS is actively taking place to ensure comprehensive solutioning.
• Squad and Pod Formation: Three engineering pods and a OnePay track are in place, planning the Oct 2026 to Jan 2027 build.
• Key Dependency: Phase 1 relies on extending the FIS OPF contract to about Q4 2027, which is not yet secured.
