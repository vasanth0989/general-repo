Wires

Current Challenges in Wire Operations:
• Outgoing wire operations involve multiple legacy DFS integrations slated for decommissioning by May 17, 2027, creating complex interdependencies.
• The FIS OPF (SaaS) component occupies a central position among these integrations. As a vendor-hosted platform OPF is outside the May 2027 mandate, but every DFS-owned system around it is in scope: Monetary Transfer (mainframe), Compliance Link, DFS Quantum, CMOD, Oracle Cash Management, JPM FX, DFS Okta and VPN.
• Each integration has unique functional requirements and its own destination (PayX, OnePay, Bridger, OneLake, COF Quantum, FINx), requiring a substantial development effort to reach the target state.

Approach and Timeline:
• Phase 1 (go-live Apr 2027): wire processing converges to PayX and OnePay. OPF is retained, via API, only for correspondent bank connectivity (JPMC, Citi, BNY, BoA).
• Phase 2 (go-live Sep 2027): PayX connects to the correspondent banks directly. OPF is decommissioned in Q4 2027.

Ongoing Efforts and Strategic Coordination:
• Technical Solutioning: the phased approach is recommended and the architecture for both phases is documented, pending Architecture Review Board ratification.
• Cross-LOB/Team Coordination: rigorous collaboration across GPN, Treasury, Global Finance, AML, Capital Markets, Operations and FIS is actively taking place to ensure comprehensive solutioning.
• Squad and Pod Formation: three engineering pods and a OnePay track are in place and planning the Oct 2026 to Jan 2027 build.

Key Risk:
• Phase 1 depends on extending the FIS OPF contract to about Q4 2027. The extension is not yet secured.
