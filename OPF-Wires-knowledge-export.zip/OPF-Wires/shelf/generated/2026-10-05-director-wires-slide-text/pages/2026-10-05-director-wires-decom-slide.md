# 2026-10-05-director-wires-decom-slide

- **Page title:** Wires (slide heading); the Google Slides document title is above the visible area and not in view
- **URL:** not in view (Google Slides editor; browser chrome is cropped out)
- **Breadcrumb / space:** none; the editor shows the "Internal" label badge and the menu bar
- **Active tab or section:** single slide in the editor canvas; the right-hand "Decom Scope" box is selected (move cursor over it)
- **Position on page:** whole slide in view, plus the Slides toolbar above it and the bottom of the canvas below it
- **First visible line:** Internal (label badge at the top-left of the editor)
- **Last visible line:** CONFIDENTIAL|4 (slide footer, bottom-right)

## Content

(Google Slides editor chrome, top: "Internal" badge (blue) · [@ icon] · [star icon] · [move-to-folder icon] · [cloud-saved icon]; menu bar cut off at the left: "ormat" [cut off] · Slide · Arrange · Tools · Extensions · Help; at the right: two user avatars (one photo, one blue "T") · history icon · comments icon · camera/present icon ▾ · [Slideshow ▾] button · a warning-triangle icon at the far right edge [cut off])

(Toolbar: [undo/redo cut off] · print icon · zoom icon · "Fit" ▾ · select-arrow tool (active) · Tt text tool · shapes tool · line tool ▾ · insert-image icon · Background · Layout · Theme · Transition)

(Blue notification bar across the editor: "missing fields." [cut off at the left] ... "Fill in required" [cut off at the right])

(Horizontal ruler: 1 2 3 4 5 6 7 8 9)

## Wires

### Diagram (left two thirds of the slide)

Boxes, all dark navy fill with white bold text and rounded corners unless stated:

1. **GPN** — dark navy; left column, upper.
2. **Bank** — dark navy; left column, lower, directly below GPN.
3. **Monetary Transfer** — dark navy, two lines ("Monetary" / "Transfer"); second column, vertically between GPN and Bank.
4. **OPF** — dark navy; third column, level with Monetary Transfer.
5. **Quantum** — dark navy; right column, top.
6. **CMOD** — dark navy; right column, second.
7. **Compliance Link** — dark navy, two lines ("Compliance" / "Link"); right column, third, level with OPF.
8. **FX** — dark navy; right column, fourth.
9. **Decom Scope** — white fill, thin grey outline, small grey two-line text ("Decom" / "Scope"); right column, fifth, directly below FX; this box is selected and the four-way move cursor sits on its bottom edge.

Arrows, all yellow/gold solid block arrows:

- GPN → Monetary Transfer: from the right edge of GPN, diagonally down-right into the left edge of Monetary Transfer. No label.
- Bank → Monetary Transfer: from the right edge of Bank, diagonally up-right into the left edge of Monetary Transfer. No label.
- Monetary Transfer → OPF: horizontal, left to right. No label.
- OPF → right column: horizontal, left to right, from OPF's right edge to the left edge of the right column, level with Compliance Link. No label; it points at the column as a whole rather than at one box.

Floating labels (small grey text, two lines each):

- "Decom Scope" — below the Bank box, at the bottom of the left column.
- "Decom Scope" — below the Monetary Transfer box.

### Text (right third of the slide)

**Current Challenges in Wire Operations:**

- Outgoing wire operations involve multiple legacy integrations currently slated for decommissioning, creating complex interdependencies.
- The FIS OPF (SaaS) component occupies a central position among these disparate integrations. Each integration possesses unique functional requirements, necessitating sophisticated architectural solutions and a substantial development effort to achieve the target destination state.

**Ongoing Efforts and Strategic Coordination:**

- **Technical Solutioning in Progress:** Evaluation of current functionalities and future-state architecture is underway to facilitate the decommissioning of legacy components.
- **Cross-LOB/Team Coordination:** Rigorous collaboration across lines of business and teams is actively taking place to ensure comprehensive solutioning.
- **Squad and Pod Formation:** Dedicated teams are currently being established to develop and execute the transition and destination states.

(Slide footer: small red/pink circular logo at the bottom-left; "CONFIDENTIAL|4" in small grey letter-spaced capitals at the bottom-right)

[below the slide: a short grey horizontal bar at the centre of the canvas (speaker-notes drag handle)]

## Legibility notes

- The photo is of a laptop screen at 1024x768; the slide text is small and slightly soft, but every word in both bullet sections was read with confidence after enlargement.
- The footer "CONFIDENTIAL|4" is tiny letter-spaced capitals; the character between "CONFIDENTIAL" and "4" is read as a vertical bar but could be a thin space or another separator. The "4" is the slide number.
- The small logo at the bottom-left of the slide is a red/pink circular mark with a white shape inside; it carries no legible text.
- The two floating "Decom Scope" labels and the right-column "Decom Scope" box use the same small grey text; only the right-column one has an outline (and is the selected object).
- The blue notification bar text is cut at both ends of the frame: "missing fields." at the left and "Fill in required" at the right. It is a Slides placeholder warning, not slide content.
- The "Slideshow" button, user avatars and toolbar icons are editor chrome, listed for completeness only.
- No arrow in the diagram carries a label.
