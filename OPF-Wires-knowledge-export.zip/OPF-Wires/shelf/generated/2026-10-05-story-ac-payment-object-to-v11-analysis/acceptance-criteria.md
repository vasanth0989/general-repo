Story: Analyzing of converting existing Payment Object to v11 pain.001 xml
Points: 5

Acceptance criteria

[ ] Existing payment object fields are inventoried and documented
[ ] pain.001 V11 XSD is in the new repo and Java classes generate from it under Gradle
[ ] Field mapping from payment object to V11 XML is documented, including gaps and decisions on optional elements
[ ] Differences between the FIS specification and the ISO V11 schema are documented
[ ] A reference V11 XML message is produced from a sample payment object and validates against the XSD
[ ] Library design note (repo, build, package layout, public API) is written
[ ] Open questions for FIS are listed with owners
[ ] Analysis is published on the Wire II design page and reviewed with the tech lead
