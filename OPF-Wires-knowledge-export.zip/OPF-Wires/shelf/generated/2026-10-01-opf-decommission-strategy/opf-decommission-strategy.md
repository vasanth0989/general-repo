# OPF decommission strategy: what we retire, why, and in what order

Prepared 2026-10-01. A summary of the program's plan as documented in the "OPF Wires Convergence Solution Options" deck (Sep 2026) and the Phase 1 and Phase 2 architecture decision records on Confluence. Both decision records are still "Proposed", so details can move.

## The answer in five lines

1. **We decommission in two layers, not one.** First the Discover-owned systems around OPF (by May 17, 2027), then OPF itself (Q4 2027).
2. **Why two layers:** the May 17, 2027 mandate covers DFS-owned infrastructure only. OPF is hosted by FIS, a vendor, so it is exempt and can stay a little longer.
3. **Phase 1 (go-live April 2027):** wire origination and processing move into Capital One's PayX and OnePay. OPF is kept only as the gateway to the correspondent banks, reached by a new API. Every DFS-owned piece that touches OPF is retired.
4. **Phase 2 (go-live September 2027):** PayX connects to the correspondent banks directly, banks are cut over one at a time, the temporary PayX-to-OPF bridge is torn down, and the FIS contract is terminated in Q4 2027.
5. **Biggest risk is commercial:** the FIS contract must be extended to about Q4 2027 and that is not yet secured.

## Why we are decommissioning

- **Contractual deadline.** Under the Capital One and Discover deal, every DFS-owned application on DFS data centres or DFS cloud must be on Capital One ecosystems by **May 17, 2027**. Hard date.
- **Vendor exit.** The long-term target is zero dependency on OPF and FIS: all wires processed in PayX (the "Clearwater" end state), no ongoing vendor product overhead.
- **Why not do it all by May.** A single-step exit needs new connectivity and certification with four or more correspondent banks plus Treasury and Finance deliveries, all in one window with no slack. The deck calls it "too much risk to be done by May". Leadership asked the program to de-risk the date.
- **ISO 20022.** Specification updates are due Nov 13, 2027 (to be confirmed). The plan is to be off OPF before that deadline so message work is not done twice.

## Options considered

| | Option 1: full convergence by May 2027 | Option 2: PayX with interim OPF settlement (recommended and chosen) |
|---|---|---|
| Idea | Build everything in PayX, connect to banks directly, switch OPF off, all by May | Move only what the May mandate requires; keep OPF for core processing and bank integration; exit OPF by Q4 2027 |
| Pros | Target architecture in one step. No vendor overhead. | Retires the DFS-owned surrounds on time. No new bank connectivity needed for May. Higher confidence on both milestones. |
| Cons | Aggressive, high-risk timeline. New bank connectivity and exhaustive bank testing. Ops retrained on everything at once. | Ops run PayX initiation alongside OPF settlement for a while. Existing manual workarounds stay until the full exit. Needs continuous FIS engagement. |

## Layer 1: what is decommissioned on the DFS side by May 17, 2027

| DFS item being retired | What it does today | Replaced by | Owner and commitment status |
|---|---|---|---|
| **Monetary Transfers Application (MTA)**, DFS mainframe | Consolidates settlements from all network channels into flat files for OPF | Payment Network Originator, a new build in GPN, sending to PayX by API | GPN owned and committed, in build |
| **Compliance Link and DFS OFAC services** | OFAC sanctions screening | Bridger and the PayX OFAC service | EP and AML (Bridger), active engagement. Compliance Link goes early 2027, so this cannot slip. |
| **DFS Quantum** (treasury) | Treasury management, cash positioning, system of record for Nostro accounts | COF Quantum | COF Treasury, active discussion (eBAM, Nostro account qualification). Targeted about Q4 2026. |
| **CMOD** (reporting) | Enterprise data and statement reporting | COF OneLake | Shown as "In Discovery (TBD)" on the deck. The reports-to-OneLake work sits with Pod 3. |
| **Oracle Cash Management (OCM)** (accounting) | General ledger and reconciliation | FINx | EP and COF Treasury, active. Testing support needed from Global Finance. |
| **Payment Origination (PO)**, the FIS manual-entry screens | Manual creation and entry of corporate wires | OnePay | EP and Ops, active, in refinement. 151 operations users and 500 templates to migrate. |
| **FX (Chase FX for corporate wires)** | FX rates and conversion for corporate wires | Direct JPMC FX rate integration from PayX | EP and Capital Markets, active |
| **FIS dependencies** (legacy integration services) | Vendor integration between DFS and OPF: flat files, FTP | PayX-to-OPF API (new integration pattern) | EP and FIS |
| **DFS Okta and DFS VPN appliances** | Sign-on and network path for operations users into OPF | Capital One single sign-on and a Capital One network path | Pod 3. Follow-up is listed in the deck's immediate next steps. |

On the deck, DFS Quantum, Oracle Cash Management, FX and FIS dependencies are shown in red, which the legend labels "Funding Required".

**What stays in OPF during Phase 1** (the capabilities with no DFS component involved): payment validation, filters and checks; holiday calendar and value dating; routing rules and correspondent bank integration (JPMC, Citi, BNY, BoA); OPF reports and BIC2 reports, which are redirected to COF OneLake.

**What moves out of OPF into PayX in Phase 1:** corporate wire initiation including DCI (OnePay), ABA/BIC enrichment, OFAC screening, FX integration, account qualification (eBAM).

## Layer 2: decommissioning OPF itself (Phase 2, Q4 2027)

**Build first.** Correspondent Bank Adaptor, routing rules, clearing date and holiday calendars, duplicate checks and risk filters, outbound file transfers and bank acknowledgements, Nostro management, reconciliation with banks and GPN, pain.008 for drawdowns.

**Cut over bank by bank,** with a parallel run and the option to fall back to OPF. Teardown only starts after the last bank is stable.

**The seven-step decommission sequence (from the Phase 2 decision record):**

| Step | Action | Gate before moving on |
|---|---|---|
| 1 | All correspondent banks certified on the PayX Corr Bank Adaptor | Per-bank certification sign-off |
| 2 | Per-bank cutover complete; PayX settling 100% of live traffic | Each bank stable for an agreed observation window |
| 3 | Treasury and Finance capabilities live (Nostro, GL, Recon+, end-of-day reports) | Global Finance and Treasury sign-off |
| 4 | Reconciliation clean across a full cycle with no OPF involvement | Zero unexplained breaks |
| 5 | Execute teardown of the Phase 1 bridge | Rollback formally no longer required. **Point of no return.** |
| 6 | Confirm retention obligations for wire history held in OPF are met before access is lost | Records-retention and audit sign-off. Must precede step 7. |
| 7 | Terminate the FIS contract and decommission OPF | Vendor Management; contractual notice period observed |

**What the teardown in step 5 removes** (this is mostly what our pod builds in Phase 1):

- The PayX-to-OPF API client, the FIS credentials, the OPF branch of the payment flow, its alerting and dashboards
- OPF acknowledgement ingestion, replaced by pain.002 acknowledgements direct from the banks
- OPF-shaped status mapping, replaced by true bank-driven status
- OPF-specific data products, re-pointed or retired
- The OPF contingency and portal-upload path, replaced or formally risk-accepted
- FIS runbooks, on-call procedures, monitoring and vendor escalation paths

The principle in the decision record: transitional integrations "must be removed, not left dormant", because dead settlement paths in a payments system are an operational and audit risk.

## Timeline

| When | Milestone |
|---|---|
| Oct 2026 to Jan 2027 | Phase 1 build (PayX capabilities, GPN Payment Network Originator); OnePay build runs to Feb 2027 |
| About Q4 2026 | DFS Quantum decommission |
| Early 2027 | Compliance Link decommission |
| Feb 2027 | Phase 1 development and system testing complete. Phase 2 build starts. |
| Mar 2027 | Phase 1 end-to-end and acceptance testing complete |
| Apr 2027 | Phase 1 go-live |
| **May 17, 2027** | **Legacy DFS shutdown. All DFS-owned components retired.** |
| Jul 2027 | Phase 2 development and system testing complete |
| Aug 2027 | Phase 2 end-to-end and acceptance testing complete |
| Sep 2027 | Phase 2 go-live; all banks cut over to PayX settlement |
| Q4 2027 | OPF decommissioned, FIS contract terminated |
| Nov 13, 2027 (to be confirmed) | ISO 20022 specification update |

## Where our team (Pod 3) sits in this

- Pod 3, "Connect to OPF and Reports", builds the Phase 1 bridge: generate the pain.001 payment message, submit it to the FIS API, bring the outcome back. Plus reports to OneLake, VPN replacement and the Okta-to-Capital-One sign-on move.
- The bridge is deliberately transitional. It exists only because OPF is retained in Phase 1 and it is removed in step 5 above. The pain.001 generation itself survives and is extended in Phase 2 (pain.008, bank-specific variants).
- From the PI planning walkthrough: the new ASV (the application container for this integration) is intended to be re-pointed from FIS to the correspondent banks in Phase 2 rather than thrown away, and retired only later when Capital One connects to Fed and SWIFT directly. This is the current thinking, not yet a recorded decision.

## Risks and open items the director should know

1. **FIS contract extension to about Q4 2027 is not secured.** Without it Phase 1 is not deliverable and the program is back to the single-step exit.
2. **The exemption for vendor-hosted systems is an assumption** that the Phase 1 decision record says should be confirmed in writing.
3. **Teardown is not costed anywhere.** The deck's Phase 2 slide has no teardown line item; the Phase 2 decision record flags this as an open discrepancy.
4. **Step 6, data retention, is easy to miss.** Once the FIS contract ends, wire history held in OPF may be inaccessible. What to extract, in what format and where it lands must be decided before notice is served.
5. **Bank certification is externally paced.** "No staffing level compresses bank certification windows."
6. **CMOD to OneLake is still marked "In Discovery" on the deck.** The reporting move to OneLake has been placed with Pod 3, but the design is at an early stage.
7. **Okta and VPN disposition is unclear.** On the walkthrough the open questions were: is DFS Okta decommissioned by May, who drives it (enterprise or each application), and how OPF authorization works. Known so far: Okta evaluates the user's groups and passes them to OPF in the SAML token.
8. **Pending program decisions:** NCR data segregation, Capital One as settlement agent, Compliance Link contingency, DCI to Citi scope, whether wires keyed directly in bank portals are out of scope.
9. **Consumer (BPM) wires** are out of scope and move under the PIX program. If PIX slips past May 2027 there is no solution yet; it is logged as a risk.
10. **Phase 1 bridge blockers on our side:** the FIS API does not support drawdowns (250 to 350 a day); no field-level encryption to FIS (compliance call 2026-10-02); the path for status updates back from OPF, beyond the immediate accept or reject response, is not yet designed and has no owner; Code Connect access needs a Discover id.
11. **Fallback if OnePay is late:** keep using PO in OPF for manual initiation (about 80 wires a day) with manual OFAC screening.
12. **Governance:** all four architecture decision records are "Proposed", none ratified by the Architecture Review Board. The Phase 1 record is due for review by 2026-10-31.

## Immediate next steps listed on the deck

1. Ratify commitments from all stakeholders
2. Formalize pending decisions (NCR, settlement agent)
3. Secure resource commitment, including after May 2027 for full convergence
4. Define detailed contingency plans
5. Follow up on network devices (VPN) and DFS SSO/Okta
