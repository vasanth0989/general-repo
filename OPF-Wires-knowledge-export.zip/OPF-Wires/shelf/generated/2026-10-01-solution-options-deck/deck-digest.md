# Deck digest: OPF Wires Convergence Solution Options (Sep 2026)

Written 2026-10-01 from 16 photos provided by the owner. Word-for-word transcriptions are in `pages/`, one file per photo. Original photos: `shelf/files/images/processed/IMG_9897.jpg` to `IMG_9912.jpg` (IMG_9903 is named `IMG_9903-2.jpg`).

This closes the "solution-options deck" part of action 21 in `notes/actions.md`. It is the deck that ADR-0004 reconciles itself against (`shelf/generated/2026-09-30-confluence-capture/pages/IMG_9877.md`).

## What the deck is

A Capital One leadership deck, dated "Sep 2026", that argues for the two-phase plan: move what the May 17, 2027 mandate requires into PayX now, keep FIS OPF as the settlement gateway for a while, and leave OPF by Q4 2027. The photos show it in slideshow mode on a laptop. Only the day is missing from the date, and no revision marker is printed, so it cannot be tied for certain to the "rev 2026-09-10" that ADR-0004 cites.

## Slide map

Slide numbers are inferred from photo order, except slide 8, which is printed. ADR-0004's slide references (2, 7, 11, 12, 13, 14) agree with this order if one slide between 8 and 11 was not photographed.

| Photo | Slide (inferred) | Title | What it gives you |
|---|---|---|---|
| IMG_9897 | 1 | OPF Wires Convergence Solution Options | Title, "Sep 2026", Confidential |
| IMG_9898 | 2 | Executive Summary | The May mandate covers DFS-owned infrastructure; vendor-hosted OPF is exempt. 6 + 3 engineers. OPF decommission by Q4 2027. |
| IMG_9899 | 3 | We identified an interim solution to help de-risk our delivery in May 2027 | Original approach versus phased approach; phased is recommended |
| IMG_9900 | 4 | Multiple initiation channels feed the current DFS workflow into OPF... | Current-state diagram |
| IMG_9901 | 5 | May 17, 2027 Scope: Breakdown of OPF items to decommission | Eight DFS items, what replaces each, who owns it. Four-column version. |
| IMG_9902 | 6 | Converge to PayX, settle in OPF for May 2027 | Phase 1 target diagram |
| IMG_9903-2 | 7 | High level Delivery Migration Plan... | Timeline, Sept 2026 to May 2027 |
| IMG_9904 | **8 (printed)** | Immediate next steps | Five next steps; number 5 is VPN and DFS SSO/Okta |
| IMG_9905 | 9 | Target Full convergence to PayX by May 2027: This was too much risk to be done by may | The rejected single-step target diagram |
| IMG_9906 | 10 or 11 | Solution Options Comparison — Pros & Cons | Option 1 versus Option 2; recommends Option 2 |
| IMG_9907 | 12 (per ADR-0004) | Delivery Plan Overview - Phase 1: De-risk May 2027 | Build lists, milestones, partner commitments |
| IMG_9908 | 13 (per ADR-0004) | Delivery Plan Overview - Phase 2: Continue with Full convergence | Phase 2 build lists and milestones |
| IMG_9909 | 14 (per ADR-0004) | Recommendation: Deliver Phase 1 with 3 Pods (EP scope) | The three pods. Stamped DRAFT. |
| IMG_9910 | 15 | Dependencies & Pending Decisions | Five dependencies and six pending decisions with owners |
| IMG_9911 | unknown | May 17, 2027 Scope... (three-column variant) | Same as slide 5 without "Functionality"; three wording differences |
| IMG_9912 | not a deck slide | Zoom screenshot, 2026-09-30 10:07:53 AM | Cameron Mayor sharing the Phase 1 diagram from a different file, "OPF Wires Convergence Team". Evidence for the walkthrough's date and attendees. |

## The argument in six lines

1. The May 17, 2027 mandate applies to DFS-owned infrastructure. OPF is hosted by FIS, so it is exempt. (IMG_9898)
2. Doing everything by May was "too much risk": it needs new bank connectivity and exhaustive bank testing. (IMG_9905, IMG_9906)
3. So Phase 1 moves only the DFS-owned surrounds into PayX and OnePay, and reaches OPF by API. OPF keeps validation and filters, holiday calendar and value date, routing rules and bank integration, and reports. (IMG_9902)
4. Milestones: Phase 1 dev and SIT Feb 2027, E2E and UAT Mar 2027, go-live Apr 2027, legacy shutdown May 17, 2027. (IMG_9907)
5. Phase 2: build Feb to July 2027, E2E and UAT Aug 2027, go-live Sep 2027, OPF decommission by Q4 2027, before ISO 20022 specs due Nov 13, 2027 (to be confirmed). (IMG_9908, IMG_9898, IMG_9899)
6. Delivered by three pods of three engineers, with OnePay staffed separately. (IMG_9909)

## Colour coding and legends

| Slide | Legend | What matters |
|---|---|---|
| IMG_9900 current state | Orange DFS, light blue Vendor (FIS), grey Corr Banks | Orange marks everything DFS-owned that has to go: the channels' hand-off, the mainframe, CBIS/Quantum, Compliance Link, FX (JPM), CMOD, Quantum, Oracle Cash Management |
| IMG_9901 and IMG_9911 scope breakdown | **Red Funding Required**, orange DFS, navy COF, green Commitment Secured, grey In Discovery, yellow Planning Underway | **Four items are written in red (Funding Required): DFS Quantum, Oracle Cash Management, FX (Chase FX for Corp), FIS dependencies.** One owner cell is green (Commitment Secured): GPN's Payment Network Originator. One is grey (In Discovery): CMOD to OneLake, owner "TBD". The other six owner cells are yellow (Planning Underway). The slide does not label the red text; the match to the legend is by colour. |
| IMG_9902 Phase 1 target | Light blue Vendor (FIS), orange DFS, navy COF, green COF Integrations, grey Corr Banks | Navy boxes are what PayX takes over; light blue boxes are what stays in OPF |
| IMG_9903-2 timeline | Lavender EP, orange DFS | Only the Payment Network Originator bar is DFS |
| IMG_9905 full convergence | Orange DFS, navy COF, green COF Integrations, grey Corr Banks | No vendor colour at all: OPF is gone. Half the title is red. |
| IMG_9906 pros and cons | Green Pros, red Cons | |
| IMG_9907 Phase 1 plan | [N] Net New, [E] Enhance existing | "May 17, 2027" is the only red date. The GPN build box has an orange header. |
| IMG_9908 Phase 2 plan | [N] Net New, [E] Enhance existing | July 2027, Aug 2027 and the ISO date are red; Sep 2027 go-live is green |
| IMG_9909 pods | none | Red DRAFT stamp |

## What concerns Pod 3

| Deck says | Photo | Note |
|---|---|---|
| Team 3 owns "OPF API integration (pain.001 out, acknowledgements in)". "Vendor-facing and transitional — retired when we fully exit OPF." | IMG_9909 | "Acknowledgements in" is not settled. See the walkthrough write-up, section 5. |
| "Pod 3 finishes first (smallest scope)", then joins PayX capabilities | IMG_9909 | The pod's actual list is longer: reports, VPN, sign-on, end-to-end testing |
| Phase 1 COF EP build includes "[N] OPF API integration", "[E] Wire II (pain.001)", "[N] Submit Request to OPF API" | IMG_9907 | Wire II is tagged "enhance existing" |
| "[N] OB Intl Drawdowns" sits under OnePay | IMG_9907 | Confluence lists outbound international drawdowns as Capability 21 under Pod 3 (action 30) |
| "Flat Files consolidation" and "Business Rules" sit under the GPN build | IMG_9907 | Consistent with the 2026-09-30 decision that this team does not need them |
| Reports: "generated out of OPF but to be send to COF OL"; timeline bar "EP: Reporting and OL" about mid-Nov to mid-Jan | IMG_9902, IMG_9903-2 | CMOD to OneLake is "In Discovery (TBD)" on the scope slide |
| "FIS dependencies" to PayX is red, Funding Required; owner "EP/FIS (New Integration pattern, decomm legacy services)" | IMG_9901, IMG_9911 | This is the Pod 3 bridge |
| Next step 5: "Follow up on Network devices (VPN) & DFS SSO/Okta" | IMG_9904 | Assigned to the owner on the 2026-09-30 walkthrough |
| Phase 2: "[E] Wire II — pain001 / pain008", "[N] Corr Bank Adaptor", "[N] DFS Rail Integration Service" | IMG_9908 | Wire II carries on into Phase 2 |
| 151 current OPF operations users, 500 templates | IMG_9907 | The users who need OVA access and sign-on migration |

## How this copy compares with ADR-0004's discrepancy list

ADR-0004 (IMG_9877.md) checked deck revision 2026-09-10. The photographed slides agree with every statement it makes:

| ADR-0004 item | ADR status | In the photographed deck |
|---|---|---|
| D1 Wire II in Phase 1 | Resolved | Yes: "[E] Wire II (pain.001)" on IMG_9907; "pain001 / pain008" on IMG_9908 |
| D2 FX in both phases | Open | Still so: Phase 1 "[N] FX Integration"; Phase 2 partner commitments name FX twice |
| D3 Submission Service in both phases | Resolved | Yes; "DFS Rail Integration Service" is still on IMG_9908 |
| D4 Reporting sits in Phase 2 | Open | Still so: "[E] EOD reports", "[E] Data Product Enhancements for OPF" on IMG_9908; "EP: Reporting and OL" in the Phase 1 timeline |
| D5 Flat Files consolidation beside PR API Integration | Open | Still so, in the GPN build on IMG_9907 |
| D6 No teardown line item | Open | Still so on IMG_9908 |
| Slide 14 watermarked DRAFT | | Yes, IMG_9909 |

So the photographed deck is the 2026-09-10 revision or one very close to it. That is an inference; no revision date is printed.

One legibility point is settled: the timeline label is "EP: Reporting and OL" (OneLake), not "QL" (IMG_9903-2).

## Not explained on the slides

- "MSK" on the PayX box (IMG_9902).
- "BIC2 reports" (IMG_9902, IMG_9912). Possibly BAI2.
- "CONA" (IMG_9910).
- "the two blockers" and "the two hard gates" (IMG_9909).
- "AI Pilot" beside "EP Wires: 3 engineers" (IMG_9898).
- Which of IMG_9901 and IMG_9911 is the current version of the scope slide.
