# ENTPMTS-143224 Wire II -- pain.001 Generation: stories

---

## Story 1: Extend the existing v9 pain.001 converter to support V11

**Story points:** 5

**User story**
As the Wire II developer, I want the existing v9 pain.001 converter extended with a V11 path, so that the Payment Exchange payment object maps to the V11 types OPF expects without rewriting the converter.

**Description**
Add a painv11 package and model.v11 helpers alongside the existing v9 ones; both versions must coexist. Generate the V11 classes from the pain.001.001.11 XSD. Port PaymentInitiationV9Converter, GroupHeaderConversionUtilV9, PaymentInfoUtilV9 and the party helpers to V11.

Type changes from v9 to V11:
- CustomerCreditTransferInitiationV09 to CustomerCreditTransferInitiationV11
- GroupHeader85 to GroupHeader95
- PaymentInstruction30 to PaymentInstruction40
- CreditTransferTransaction34 to CreditTransferTransaction54
- InstructionForCreditorAgent1 to InstructionForCreditorAgent3
- RemittanceInformation16 to RemittanceInformation21
- CashAccount38 to CashAccount40
- Party, agent, address, amount and payment-type types keep their v9 names and carry over

Map against the FIS specification's types, not the published ISO V11 XSD, where the two differ. Decide each new optional field explicitly: initiationSource, requestedAdviceType, intermediaryAgent3, chargesAccount. Carry over the existing v9 workarounds deliberately: the structured-address feature flag, the sender-specific bank-to-bank text clean-up, and the 140-character chunking of bank-to-bank instructions.

**Acceptance criteria**
- V11 converter classes exist alongside v9; v9 behaviour is unchanged and its existing tests pass.
- Every V11 element is mapped, and a mapping note on the Wire II design page records the source of each V11 field and the decision on each optional field.
- Enumerations that become strings in V11 are validated in code, with a clear error on an unknown value.
- Each of the three v9 workarounds has a recorded decision: kept, changed, or dropped.
- Unit tests cover group header, payment instruction, credit transfer transaction, and all four party roles (debtor, creditor, ultimate debtor, ultimate creditor).

**Dependencies**
- pain.001.001.11 XSD shared by the tech lead
- Access to the PmtInfrEngn-wire-ii-intg repository

---

## Story 2: Implement pain.001.001.11 XML generation from the Payment Exchange payment object

**Story points:** 5

**User story**
As the Wire II developer, I want a complete, schema-valid pain.001.001.11 XML document produced from a Payment Exchange payment object, so that Wire II has a permanent Phase 2 asset and a valid input for the Phase 1 JSON conversion.

**Description**
Wire the V11 converter into a generation service: accept the payment object, produce the V11 document, marshal it with JAXB, and validate it against the XSD. Populate UETR on PaymentIdentification6 if OPF requires it, generated once and stored with the payment. Move the existing supplementary data (FX debit currency and amount, initiator, approver) into the V11 per-context supplementary data; confirm the expected envelope contents with FIS.

**Acceptance criteria**
- Golden-file tests: every existing v9 sample produces a V11 document that validates against the pain.001.001.11 XSD.
- numberOfTransactions and controlSum are correct.
- UETR handling is decided and, if generated, is persisted and appears in logs by correlation id only.
- Supplementary data is present in the V11 shape; open items with FIS are listed on the Wire II design page.
- No account number, name or amount appears in logs.

**Dependencies**
- Story 1
- FIS confirmation of supplementary data contents (Story 8)

---

## Story 3: Implement XML-to-JSON conversion for the generated pain.001.001.11 message

**Story points:** 5

**User story**
As the Wire II developer, I want the generated V11 XML converted to the JSON representation the OPF API accepts, so that the Submit Request to OPF API service can submit it without further transformation.

**Description**
Phase 1 only; removed in Phase 2. Convert the V11 XML to JSON with a conversion utility and validate the result against the FIS OpenAPI schema (UEAPI.json). Dates become ISO-8601 strings; supplementary data becomes a JSON object; enumerations become plain strings.

Verify early that a direct XML-to-JSON conversion produces the element names the FIS contract expects (for example businessApplicationHeader, groupHeader, paymentInformation) rather than the ISO XML tag names. If a name-mapping layer is required, it is part of this story.

**Acceptance criteria**
- JSON output validates against UEAPI.json for every golden-file sample.
- One sample compared against the FIS example payload from the Code Connect specification and reviewed by the tech lead.
- Conversion failure produces an explicit error, never a partial message.
- The JSON step is isolated in its own class or module so it can be removed in Phase 2 without touching XML generation.

**Dependencies**
- Story 2
- UEAPI.json from the Code Connect tile

---

## Story 4: Implement Business Application Header (BAH) wrapping per the OPF API contract

**Story points:** 3

**User story**
As the Wire II developer, I want every generated message wrapped in a Business Application Header, so that it matches the OPF API request body.

**Description**
New mapping with no v9 equivalent. Populate the five mandatory fields: from, to, businessMessageIdentifier, messageDefinitionIdentifier, creationDate. The "to" system is OPF. Identifier values for from and to are configuration per environment and are confirmed with FIS.

**Acceptance criteria**
- BAH is present on every message in both the XML and the JSON output.
- businessMessageIdentifier is unique per message and traceable to the payment id.
- from and to values are configuration, not code, per environment.
- Schema validation covers the header.

**Dependencies**
- Stories 2 and 3

---

## Story 5: Implement SQS publish step for the JSON message

**Story points:** 3

**User story**
As the Wire II developer, I want the JSON message published to the SQS queue that the Submit Request to OPF API service consumes, so that submission to OPF is decoupled from message generation.

**Description**
The queue and dead-letter queue are provisioned by the infrastructure component; this story implements the publish. Define the message contract with the owner of the Submit Request to OPF API service: body is the V11 JSON; message attributes carry payment id, correlation id and message version. Retry transient failures with backoff; persistent failures go to the dead-letter queue and raise an alarm. A message is never published twice for the same payment on retry.

**Acceptance criteria**
- Message contract documented and agreed with the owner of the Submit Request to OPF API service.
- Successful publish returns the SQS message id, which is stored against the payment.
- Retry and dead-letter behaviour covered by tests.
- IAM permits send only from Wire II; the queue is encrypted at rest.

**Dependencies**
- SQS queue and dead-letter queue provisioned (infrastructure or foundation epic)
- Can be built in parallel with Story 2

---

## Story 6: Implement acknowledgment back to PayX on successful publish

**Story points:** 3

**User story**
As Payment Exchange, I want an acknowledgment from Wire II once the message is queued, so that the saga can advance without waiting on OPF submission.

**Description**
Define the endpoint PayX calls with the payment object and the acknowledgment it receives. Acknowledge only after the SQS publish succeeds. On conversion, validation or publish failure, return a distinguishable error so the saga does not advance.

**Acceptance criteria**
- Request and response contract documented and agreed with the PayX saga owner.
- Acknowledgment carries the payment id, the SQS message id and a timestamp.
- Failure responses distinguish conversion failure, validation failure and publish failure.
- Contract test runs in the pipeline.

**Dependencies**
- Story 5
- Can be built in parallel with Story 2

---

## Story 7: Confirm PayX correctly produces the .OPFRAIL stage on acknowledgment

**Story points:** 2

**User story**
As the Pod 3 team, I want to verify in the PayX test environment that a payment reaching the OPFRAIL stage calls Wire II and completes the stage on the acknowledgment, so that the saga advances immediately without waiting on OPF.

**Acceptance criteria**
- In dev or QA, a test payment on the WIRE-GPN-OUTBOUND saga reaches OPFRAIL, Wire II is called, and the stage completes on the acknowledgment.
- A failure response from Wire II leaves the payment at the stage without advancing, and the outcome is visible in PayX.
- Result recorded on the Wire II design page.

**Dependencies**
- Story 6
- OPFRAIL stage wired on the PayX side (Pod 2)

---

## Story 8: Enabler: v9-to-V11 schema delta analysis

**Story points:** 3

**User story**
As the Wire II developer, I want the differences between the existing v9 converter output and the FIS V11 specification analysed and documented, so that the converter is built from confirmed differences rather than assumptions.

**Acceptance criteria**
- A side-by-side of a v9 sample and its V11 equivalent is on the Wire II design page, showing the delta, usable by QA for automation test cases.
- The FIS canonical JSON types that differ from the ISO V11 XSD are listed.
- Open questions for FIS are listed with an owner.

**Dependencies**
- pain.001.001.11 XSD
- Access to the v9 converter repository

---

## Story 9: Confirm the DFS batch-to-pain.001 field mapping and message content with FIS

**Story points:** 2

**User story**
As the Wire II developer, I want written confirmation from FIS on the points the specification leaves open, so that the mapping is confirmed and documented, not assumed.

**Description**
Questions for FIS: the DFS batch-to-pain.001 field mapping (customer info to ultimate debtor, DFS info to debtor); what OPF expects inside the supplementary data envelope; whether UETR and the Business Application Header are mandatory; whether pain.001.001.11 is the only accepted version.

**Acceptance criteria**
- Answers recorded on the Wire II design page with date and FIS contact.
- Story 1 mapping note updated.

**Dependencies**
- FIS session. Blocked until then.

---

## Story 10: Observability and end-to-end verification for Wire II

**Story points:** 5

**User story**
As the on-call engineer, I want Wire II to emit structured logs, metrics and alarms, and the team to have an automated end-to-end test with the Submit Request to OPF API service, so that a generation or publish failure is seen before the cut-off and the epic's definition of done is proven.

**Acceptance criteria**
- Structured logs with correlation and trace ids; trace context propagated onto the SQS message.
- Metrics for conversion count, failure count, publish latency and dead-letter depth.
- Alarms on conversion failure rate and on dead-letter queue depth greater than zero.
- A panel on the operations dashboard in dev and QA.
- Automated end-to-end test: payment object in, Wire II, SQS, consumed by the Submit Request to OPF API service, JSON compared against the expected FIS payload. Runs in the pipeline.

**Dependencies**
- Stories 5 and 6
- Submit Request to OPF API consumer available

---

## Suggested sprint plan

| Sprint | Stories | Points |
|---|---|---|
| Sprint 1 | 8, 1, 5, 9 (started) | 13 |
| Sprint 2 | 2, 3, 4, 6 | 16 |
| Sprint 3 | 7, 10 | 7 |

Sequencing: Story 1 first, then Story 2. Stories 5 and 6 have no dependency on Story 2 and run in parallel with it. Story 7 is last.
