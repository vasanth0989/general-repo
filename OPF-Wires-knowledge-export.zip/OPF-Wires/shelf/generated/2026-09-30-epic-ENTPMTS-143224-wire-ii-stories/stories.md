# Stories for epic ENTPMTS-143224: Wire II, pain.001 Generation (Capability 10)

Revised 2026-09-30 after the owner's feedback. Base: the seven recommended stories on the epic (screenshot IMG_9883), kept in their order and wording, with fuller content. Three additions from the Pod 3 call are marked "added". No story exceeds 5 points. Two-week sprints.

Sources: epic screenshots `shelf/files/images/processed/IMG_9882.jpg`, `IMG_9883.jpg`; Pod 3 call `shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt` (cue N); Capability 10 page, Confluence photos 9850 to 9853.

## Fixed points from the epic and the call

- Phase 1 flow: payment object to pain.001.001.11 **XML**, then XML **to JSON**, then SQS, then acknowledgment to PayX, which produces `.OPFRAIL`. Phase 2 keeps the XML and drops the JSON step. (epic description; cue 872-879)
- Extend the existing v9 converter in `PmtInfrEngn-wire-ii-intg`; do not build V11 natively. (epic; photo 9850)
- Scope is pain.001 only. pain.008 is Phase 2.
- Wire II has no dependency on FIS access and can be built in parallel. (cue 911-916)
- Epic acceptance criteria: 1 valid V11 message from the payment object; 2 rendered as JSON in a valid Business Application Header; 3 published to SQS and consumable by Capability 3; 4 PayX acknowledged and produces `.OPFRAIL` without waiting on OPF; 5 DFS batch-to-pain.001 field mapping confirmed and documented.
- Definition of done: verified end to end in a test that Capability 3 can consume.

## Point scale

1 under a day. 2 one to two days. 3 a few days. 5 about a week including tests, or real unknowns. Nothing above 5; anything that looks bigger is split.

---

## Story 1. Extend the existing v9 pain.001 converter to support V11, per the v9-to-V11 delta in ADR-0003 section 4d

**Points: 5**

**As** the Wire II developer, **I want** the existing v9 converter extended with a V11 path, **so that** the payment object maps to the V11 types OPF expects without rewriting the converter.

**Description.** Add a `painv11` package and `model.v11` helpers next to the v9 ones; both versions must coexist. Generate the V11 classes from the XSD Kaushik is sharing. Port `PaymentInitiationV9Converter`, `GroupHeaderConversionUtilV9`, `PaymentInfoUtilV9` and the party helpers to V11. The renames from ADR-0003 §4d: `CustomerCreditTransferInitiationV09` to `V11`, `GroupHeader85` to `95`, `PaymentInstruction30` to `40`, `CreditTransferTransaction34` to `54`, `InstructionForCreditorAgent1` to `3`, `RemittanceInformation16` to `21`, `CashAccount38` to `40`. Party, agent, address, amount and payment-type types keep their v9 names and carry over. Map against the FIS specification's types, not the ISO V11 XSD, where they differ (photo 9853). Decide each new optional field explicitly: `initiationSource`, `requestedAdviceType`, `intermediaryAgent3`, `chargesAccount`. Carry over the v9 workarounds deliberately: structured-address flag, sender-specific bank-to-bank text clean-up, 140-character chunking.

**Acceptance criteria**
- V11 converter classes exist alongside v9; v9 behaviour is unchanged and its tests still pass.
- Every element in the §4d table is mapped, and a mapping note on the Capability 10 page records the source of each V11 field and the decision on each optional field.
- Enumerations that become strings in V11 are validated in code, with a clear error on an unknown value.
- Each of the three v9 workarounds has a recorded decision: kept, changed, or dropped.
- Unit tests cover group header, payment instruction, transaction, and all four party roles.

**Dependencies:** V11 XSD from Kaushik (cue 892). Story 0 if the team keeps it.

---

## Story 2. Implement pain.001.001.11 XML generation from the Payment Exchange payment object

**Points: 5**

**As** the Wire II developer, **I want** a complete, schema-valid pain.001.001.11 XML document produced from a payment object, **so that** the output is the permanent asset Phase 2 will send to the banks.

**Description.** Wire the converter from Story 1 into a generation service: take the payment object (`SDPPayload`), produce the V11 document, marshal it with JAXB, validate against the XSD. Populate UETR on `PaymentIdentification6` if OPF requires it, generated once and stored with the payment. Move the existing supplementary data (FX debit currency and amount, initiator, approver) into the V11 per-context supplementary data; confirm the envelope contents with FIS.

**Acceptance criteria**
- Golden-file tests: every existing v9 sample produces a V11 document that validates against the pain.001.001.11 XSD.
- `numberOfTransactions` and `controlSum` are correct.
- UETR handling decided and, if generated, persisted and visible in logs by correlation id only.
- Supplementary data present in the V11 shape; open items with FIS are listed on the Capability 10 page.
- No account number, name or amount appears in logs.

**Dependencies:** Story 1. FIS answer on supplementary data (Story 8).

---

## Story 3. Implement XML-to-JSON conversion for the generated pain.001.001.11 message

**Points: 5**

**As** the Wire II developer, **I want** the V11 XML converted to the JSON the OPF API accepts, **so that** Capability 3 can submit it unchanged.

**Description.** Phase 1 only; removed in Phase 2. Convert the XML with a utility as agreed on the call (cue 877). Validate the result against the FIS OpenAPI schema `UEAPI.json`. Dates become ISO-8601 strings; supplementary data becomes a JSON object; enumerations become plain strings.

**Check first.** FIS said its JSON tag names were "made more descriptive" (FIS meeting cue 184), and the contract uses names such as `businessApplicationHeader` and `groupHeader`, not `GrpHdr`. If a straight XML-to-JSON pass does not match, add a name-mapping layer inside this story. That is why it is 5, not 3.

**Acceptance criteria**
- JSON output validates against `UEAPI.json` for every golden-file sample.
- One sample compared by hand against the FIS example payload from the Code Connect spec and signed off by Kaushik.
- Conversion failure produces an explicit error, never a partial message.
- The JSON step is isolated in one class or module, so it can be removed in Phase 2 without touching XML generation.

**Dependencies:** Story 2. `UEAPI.json` from the Code Connect tile.

---

## Story 4. Implement Business Application Header (BAH) wrapping per the OPF API contract

**Points: 3**

**As** the Wire II developer, **I want** every message wrapped in a Business Application Header, **so that** it matches the OPF API request body.

**Description.** New mapping with no v9 equivalent (photo 9852). Populate the five mandatory fields: `from`, `to`, `businessMessageIdentifier`, `messageDefinitionIdentifier`, `creationDate`. The "to" system is OPF. Identifier values for `from` and `to` come from configuration and are confirmed with FIS.

**Acceptance criteria**
- BAH present on every message in both the XML and the JSON output.
- `businessMessageIdentifier` is unique per message and traceable to the payment id.
- `from` and `to` values are configuration, per environment.
- Schema validation covers the header.

**Dependencies:** Stories 2 and 3.

---

## Story 5. Implement SQS publish step for the JSON message

**Points: 3**

**As** the Wire II developer, **I want** the JSON message published to the queue Capability 3 consumes, **so that** submission to OPF is decoupled from generation.

**Description.** Queue and dead-letter queue are provisioned by the infrastructure component (cue 476); this story is the publish. Define the message contract with the Capability 3 owner: body is the V11 JSON; attributes carry payment id, correlation id, message version. Retry transient failures with backoff; persistent failures go to the dead-letter queue and alarm. Never publish twice for the same payment on retry.

**Acceptance criteria**
- Message contract documented and agreed with the Capability 3 owner.
- Successful publish returns the SQS message id, stored against the payment.
- Retry and dead-letter behaviour covered by tests.
- IAM permits send only; the queue is encrypted at rest.

**Dependencies:** Queue provisioned (foundation or infrastructure epic). Can be built in parallel with Story 2 (cue 934-943).

---

## Story 6. Implement acknowledgment back to PayX on successful publish

**Points: 3**

**As** Payment Exchange, **I want** an acknowledgment from Wire II once the message is queued, **so that** the saga can advance without waiting on OPF.

**Description.** Define the endpoint PayX calls with the payment object and the acknowledgment it gets back. Acknowledge only after the SQS publish succeeds. On conversion, validation or publish failure, return a distinguishable error so the saga does not advance.

**Acceptance criteria**
- Request and response contract documented and agreed with the PayX saga owner (Cameron).
- Acknowledgment carries the payment id, the SQS message id and a timestamp.
- Failure responses distinguish conversion failure, validation failure and publish failure.
- Contract test in the pipeline.

**Dependencies:** Story 5. Can be built in parallel with Story 2 (cue 934-943).

---

## Story 7. Confirm PayX correctly produces the .OPFRAIL stage on acknowledgment

**Points: 2**

**As** the Pod 3 team, **I want** to verify in the PayX test environment that a payment reaching `OPFRAIL` calls Wire II and completes the stage on the acknowledgment, **so that** epic acceptance criterion 4 is proven.

**Acceptance criteria**
- In dev or QA, a test payment on the `WIRE-GPN-OUTBOUND` saga reaches `OPFRAIL`, Wire II is called, and the stage completes on the acknowledgment without waiting for OPF.
- A failure response from Wire II leaves the payment at the stage without advancing, and the outcome is visible in PayX.
- Result recorded on the Capability 10 page.

**Dependencies:** Story 6; the saga stage wired on the PayX side (Pod 2 or Cameron). Last in the sequence (cue 941).

---

## Added from the call

### Story 0. Enabler: v9-to-V11 schema delta analysis

**Points: 3**. Added because Kaushik said the delta "we haven't done the analysis yet" and asked for an enabler under this epic (cue 855-861).

**As** the Wire II developer, **I want** the differences between the v9 converter output and the FIS V11 specification analysed and written down, **so that** Story 1 works from confirmed differences.

**Acceptance criteria**
- Side-by-side of a v9 sample and its V11 equivalent on the Capability 10 page, showing the delta, as the new team member asked for testing (cue 844-846).
- List of FIS canonical JSON types that differ from the ISO V11 XSD.
- Questions for FIS listed with an owner.

**Dependencies:** V11 XSD from Kaushik; access to the v9 repository.

### Story 8. Confirm the DFS batch-to-pain.001 field mapping and message content with FIS

**Points: 2**. This is the struck-through recommended story. Kept because epic acceptance criterion 5 still requires the mapping to be "confirmed and documented, not assumed", and Dylan said on the call it is confirmed (cue 842) while the ADR says pending. Blocked on FIS.

**Acceptance criteria**
- Written answers recorded on the Capability 10 page: customer info to ultimate debtor and DFS info to debtor mapping; supplementary data envelope contents; whether UETR and the BAH are mandatory; whether pain.001.001.11 is the only accepted version.
- Story 1 mapping note updated.

### Story 9. Observability and end-to-end verification

**Points: 5**. Added because the call asked for observability and alerting on every epic (cue 770-783) and the definition of done requires an end-to-end test with Capability 3.

**Acceptance criteria**
- Structured logs with correlation and trace ids; trace context propagated onto the SQS message.
- Metrics for conversion count, failure count, publish latency, dead-letter depth; alarms on failure rate and dead-letter depth greater than zero; a panel on the operations dashboard.
- Automated end-to-end test: payment object in, Wire II, SQS, consumed by the Capability 3 service, JSON compared against the expected FIS payload. Runs in the pipeline.

**Dependencies:** Stories 5 and 6; Capability 3 consumer available.

---

## Sprint shape

| Sprint | Stories | Points |
|---|---|---|
| 1 | Story 0, Story 1, Story 5, Story 8 started | 3 + 5 + 3 + 2 = 13 |
| 2 | Story 2, Story 3, Story 4, Story 6 | 5 + 5 + 3 + 3 = 16 |
| 3 | Story 7, Story 9 | 2 + 5 = 7 |
| Total | 10 stories | 36 |

Order follows the call: Story 1 first, then Story 2; Stories 5 and 6 in parallel with Story 2 since they have no dependency on it; Story 7 last (cue 903-945). If one engineer is on this epic alone, sprint 1 and 2 as shown are heavy; move Story 5 to sprint 2 and Story 4 to sprint 3.

## Add to the epic

1. A performance expectation. Nobody knew the volume (cue 784-788). GPN is about 95% of wires with 9:00 and 10:00 AM ET cut-offs.
2. A note that account numbers are not field-level encrypted in the message, pending cyber and ISO approval (cue 612-616, 664-681), and which service detokenizes them for FIS. The pages do not say.
3. A note that the XML is the permanent Phase 2 asset and the JSON step is removed in Phase 2, so the two-step design is not questioned later.
