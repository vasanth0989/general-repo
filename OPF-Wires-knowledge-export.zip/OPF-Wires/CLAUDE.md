# OPF-Wires: project knowledge base

This folder is an exported knowledge base for the owner's work on **DFS OPF Convergence** at Capital One. It holds everything a previous assistant learned about the project between 2026-09-29 and 2026-10-08: meeting transcripts, word-for-word transcriptions of Confluence pages and slide decks, digests, the owner's working notes, and deliverables. Learn the project from these files. Read `README.md` for the file map, then `notes/handoff.md` for the current state, then `notes/brief.md`.

## What it is
The owner's part of DFS OPF Convergence (program WS4, DFS Wires). The program moves Discover's GPN and Corporate wires off FIS OPF onto Capital One's PayX and OnePay in two phases. The owner is in **Pod 3, "Connect to OPF and Reports"**, which builds the Phase 1 bridge from PayX to OPF: generate a pain.001 version 11 message (Wire II), submit it to the FIS API, bring the outcome back, plus reports to OneLake, VPN and sign-on changes. Full brief in `notes/brief.md`.

## Context
- Capital One acquired Discover Financial Services (DFS). Every DFS-owned application must be off DFS infrastructure by **May 17, 2027**, hard and contractual. That includes MTA, the mainframe application feeding OPF.
- Phase 1 (live April 2027): PayX processes, OPF settles by API. Phase 2 (live September 2027): Capital One connects to the correspondent banks directly and OPF is decommissioned in Q4 2027. The correspondent banks stay throughout.
- Consumer and BPM wires are out of scope. They belong to the PIX program.
- Pod 3's OPF connection is transitional and is removed in Phase 2.
- Phase 1 depends on an FIS contract extension to about Q4 2027 that is not yet secured.

## Who is on it
See `notes/people.md`. Key names: Kiran Iruku (architecture lead), Kaushik Ravichandran (ADR author, squad lead with Kiran), Cameron Mayor (capability pages, senior developer), Robert and Sujith Sukumaran at FIS. Pod 3's engineers are the owner, Tejaswi Davuluri (probable) and a second Kaushik, surname unknown. The owner knows the consumer wire UI and APIs up to BPM; PayX, OPF, ISO 20022 and bank connectivity are newer to them, so explain plainly and define terms on first use.

## Current focus (as of 2026-10-08)
- The owner owns the Wire II epic ENTPMTS-143224 (Capability 10). Ten stories were drafted on 2026-09-30 (`shelf/generated/2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/`). On 2026-10-05 the owner stated that the V11 converter is a brand-new Java/Gradle library, not an extension of an existing v9 converter, so stories 1 and 8 of that draft need rewording. The owner's first story is "Analyzing of converting existing Payment Object to v11 pain.001 xml", 5 points; its acceptance criteria are in `shelf/generated/2026-10-05-story-ac-payment-object-to-v11-analysis/`.
- The owner also has the VPN device and DFS Okta follow-up (actions 40 to 42 in `notes/actions.md`).
- Live blockers: FIS Code Connect access needs a Discover id; drawdowns are unsupported by the FIS API; encryption of account numbers to FIS is with compliance; the status path back from OPF beyond the immediate accept or reject is not designed; new ASV versus PIE ASV is unsettled.

## How to work with this material
- Ground every answer in `notes/` and `shelf/`. Name the file you relied on. Say when something is thin or a guess.
- `notes/` is the project memory: brief, decisions, actions, timeline, people, meetings, glossary, system-understanding, handoff. Check `notes/glossary.md` before explaining any acronym. Keep the notes current if you continue the work: add, mark done, or mark superseded; never rewrite history.
- Every extracted fact carries its source, for example `(source: shelf/files/audioRecordings/processed/Pod3Call-m4a-8d520809-a6a3.srt, cue 960)` or a photo number such as `(9797)`. Photo numbers refer to word-for-word transcriptions in a `pages/` folder: `shelf/generated/2026-09-30-confluence-capture/pages/` (Confluence, IMG_9758 to 9881), `shelf/generated/2026-10-01-solution-options-deck/pages/` (leadership deck, IMG_9897 to 9912), `shelf/generated/2026-09-30-fis-payment-initiation-api-meeting/pages/` (FIS deck and Swagger, IMG_9742 to 9755), `shelf/generated/2026-09-29-opf-architecture-review/pages/` (2022 C4 document, IMG_9735 to 9740) and `shelf/generated/2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/pages/` (the Jira epic, IMG_9882 and 9883). `README.md` has the full map. The photos themselves are not in this export; the transcriptions carry everything that was on them.
- Search the `pages/` folders for any term before answering from memory. The Confluence pages were changing daily when captured (2026-09-29 and 2026-09-30); say so when a detail may have moved on.
- Transcripts (`.srt`) are machine-generated with numbered speakers and garbled payment terms. Cite by cue number and flag uncertain names. The meeting summaries give the probable speaker names.
- The owner's format rules:
  - Jira stories: start from the epic's own recommended stories, maximum 5 points each, no thin slices, two-week sprints.
  - Acceptance criteria: a checklist of one-line checkable items (`[ ] ...`), six to eight for a 5-point story, not granular tasks.
  - Anything the owner will share with other people (director, team, Jira) carries no local references: no file paths, photo numbers, transcript cues or sources section. Keep a separate `-sourced` copy for traceability.
  - Lead with the answer. Short paragraphs and lists.
