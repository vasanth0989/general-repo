# OPF-Wires knowledge export

Exported 2026-10-08 from the owner's project workspace. Text only: markdown, transcripts and acceptance criteria. No images. Start with `CLAUDE.md`, then `notes/handoff.md`.

## Reading order for a cold start

| Order | File | Why |
|---|---|---|
| 1 | `CLAUDE.md` | Project brief and how to work with the material |
| 2 | `notes/handoff.md` | Current state, live blockers, what to ask the owner next, session log |
| 3 | `notes/brief.md` | Goal, scope, dates, constraints, open questions |
| 4 | `notes/system-understanding.md` | How wires work today, in Phase 1 and in Phase 2; confidence per fact |
| 5 | `shelf/generated/2026-09-30-confluence-capture/program-digest.md` | The whole program from the Confluence space |
| 6 | `shelf/generated/2026-09-30-confluence-capture/pod3-digest.md` | Pod 3, the owner's pod, capability by capability |
| 7 | `notes/actions.md`, `notes/decisions.md`, `notes/people.md`, `notes/timeline.md`, `notes/glossary.md` | The working notes |
| 8 | The meeting summaries under `shelf/generated/` | What was said in each meeting, with speaker attribution |
| as needed | `pages/` folders | Word-for-word transcriptions, for looking anything up |

## Folder map

```
CLAUDE.md                                   project brief for an assistant
README.md                                   this file
links-index.md                              every address captured from the pages, and every link whose target was not visible
notes/
  brief.md                                  one-page brief (revised 2026-09-30; original kept below it)
  decisions.md                              dated decisions, newest first, each with its source
  actions.md                                54 action items: what, who, due, status, source
  timeline.md                               milestones from program start to Q4 2027
  people.md                                 who is on the program and what they own
  meetings.md                               one entry per meeting
  glossary.md                               about 135 project terms
  system-understanding.md                   the end-to-end model with confidence levels
  handoff.md                                cold-start note and session log
shelf/files/audioRecordings/processed/
  Opf01-mp3-c4293ac6-bacd.srt               FIS Payment Initiation API meeting, 2026-09-28
  PIIPlanningWalkThrough-mp3-e1d75c84-da60.srt   PI planning walkthrough, 2026-09-30 morning, 1 h 55 min
  Pod3Call-m4a-8d520809-a6a3.srt            Pod 3 PI planning call, 2026-09-30 afternoon
shelf/generated/
  2026-09-29-opf-architecture-review/       reading of the 2022 DFS C4 document (historical, superseded) and pages/ (5 transcriptions)
  2026-09-30-fis-payment-initiation-api-meeting/   FIS meeting summary, deck-versus-meeting comparison, pages/ (14 deck and Swagger transcriptions)
  2026-09-30-confluence-capture/            program digest, Pod 3 digest, README page map, pages/ (123 transcriptions)
  2026-09-30-pi-planning-walkthrough/       morning walkthrough summary
  2026-09-30-pod3-pi-planning-call/         afternoon Pod 3 call summary
  2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/   ten Wire II stories: stories-jira.md (clean), stories.md (sourced), pages/ (the epic, 2 transcriptions)
  2026-10-01-opf-decommission-strategy/     decommission strategy: clean and -sourced versions
  2026-10-01-solution-options-deck/         deck digest and pages/ (16 transcriptions of the leadership deck)
  2026-10-05-director-wires-slide-text/     replacement text for the director's one-slide summary (several lengths) and pages/ (the original slide, transcribed)
  2026-10-05-story-ac-payment-object-to-v11-analysis/   acceptance criteria for the owner's analysis story
```

## What the transcriptions cover

| Transcriptions | Source | Where |
|---|---|---|
| IMG_9758 to IMG_9881 (no 9771) | Confluence space "Payment Infrastructure Engine": charter, open questions tracker, four ADRs, pod pages, capability pages, OFAC flow | `shelf/generated/2026-09-30-confluence-capture/pages/`; page map in that folder's `README.md` |
| IMG_9897 to IMG_9911 | "OPF Wires Convergence Solution Options" deck, Sep 2026 | `shelf/generated/2026-10-01-solution-options-deck/pages/` |
| IMG_9912 | Zoom screenshot of the 2026-09-30 walkthrough | same folder |
| IMG_9735 to IMG_9740 (no 9736) | 2022 DFS C4 architecture document about OPF | `shelf/generated/2026-09-29-opf-architecture-review/pages/` |
| IMG_9742 to IMG_9755 | FIS "Payment Initiation API" deck and Swagger screenshots, shown 2026-09-28 | `shelf/generated/2026-09-30-fis-payment-initiation-api-meeting/pages/` |
| IMG_9882, IMG_9883 | Jira epic ENTPMTS-143224, Wire II pain.001 Generation | `shelf/generated/2026-09-30-epic-ENTPMTS-143224-wire-ii-stories/pages/` |
| 2026-10-05-director-wires-decom-slide | The director's one-slide "Wires" decommission summary | `shelf/generated/2026-10-05-director-wires-slide-text/pages/` |

Every photo the owner provided is transcribed; nothing was read without being written down.

## Conventions in these files

- Facts carry their source: a transcript cue, a photo number, or a file path. Photo numbers map to `pages/IMG_NNNN.md`.
- Transcripts have numbered speakers. The meeting summaries give probable names and say how confident they are.
- `[?]` marks an uncertain reading, `[cut off]` text running off the screen, `[illegible]` unreadable text.
- Notes are never rewritten: superseded facts are marked superseded, with the date.
- Files whose names end `-jira` or that are the "clean" version carry no references, because they are meant to be pasted or shared. The `-sourced` or `stories.md` versions beside them carry the sources.

## Links

Confluence shows hyperlinks as link text, not addresses. Where a page printed the address itself (repository tables, portal pages) it is captured exactly; otherwise the transcription marks `[link]` after the link text and the target is unknown. `links-index.md` lists both kinds with the file and line, and each transcription's header carries the Confluence address of the page it came from. To get the real targets, open that page on Confluence or export it as text there.

## Caveats

- The Confluence pages were changing daily when photographed (2026-09-29 and 2026-09-30). All four ADRs were "Proposed", not ratified.
- Not available anywhere in this export: the FIS API file `UEAPI.json`, the pain.001 V11 XSD, the capabilities and dependencies workbooks, Confluence pages for Capabilities 18 to 20, and the photos themselves.
- The "six correspondent banks" in Phase 2 list BNY and Mellon separately, which the owner questions; see action 54.
- Speaker names in the PI planning walkthrough are provisional; see action 53.
