# Links index

Generated 2026-10-08 from the transcriptions. Confluence shows hyperlinks as link text, not as addresses, so a photo of a page captures the text and not the target. Two kinds of entry below:

1. **Addresses written out on a page** and therefore captured exactly.
2. **Links whose target is not visible**: the transcriptions mark these `[link]` right after the link text. The entry gives the file, the line and the text around the marker, so the page and the linked item can be found on Confluence. The page's own Confluence address is in the header block of each transcription.

## 1. Addresses captured exactly

| Address | Found in |
|---|---|
| `http://openapi-preview.example/` | 2026-09-30-fis-payment-initiation-api-meeting/pages/IMG_9746.md |
| `http://www.fis` | 2026-09-30-fis-payment-initiation-api-meeting/pages/IMG_9746.md, 2026-09-30-fis-payment-initiation-api-meeting/pages/IMG_9747.md, 2026-09-30-fis-payment-initiation-api-meeting/pages/IMG_9748.md |
| `https://api.capitalone.com/oauth2/token` | 2026-09-30-confluence-capture/pages/IMG_9813.md |
| `https://capitalone.enterprise.slack.com/archives/C011GPS1SFP/p1699902740526279?thread_ts=` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C011GPS1SFP/p1785349813287669?thread_ts=1785255194.410739&cid=C011GPS1SFP` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C011GPS1SFP/p1786372199846579?thread_ts=1786372199.846579&cid=C011GPS1SFP` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C011GPS1SFP/p1787066295406009?thread_ts=1787066295.406009&cid=C011GPS1SFP` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C011GPS1SFP/p1788290211263779?thread_ts=1788290211.263779&cid=C011GPS1SFP` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C011GPS1SFP/p1788900286532059?thread_ts=1788900286.532059&cid=C011GPS1SFP` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C011GPS1SFP/p1789493923700499?thread_ts=1789489612.455569&cid=C011GPS1SFP` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C08BA9MFA2Y/p1788972745530919?thread_ts=1788972745.530919&cid=C08BA9MFA2Y` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C08FERQGSF2/p1758056490729999?thread_ts=1757971534.637409&cid=C08FERQGSF2` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/C09JAQZEKK3/p1759239891267759?thread_ts=1759239891.267759&cid=C09JAQZEKK3` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/CM4H43QKG/p1777302346917109?thread_ts=1777299981.315829&cid=CM4H43QKG` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://capitalone.enterprise.slack.com/archives/CM4H43QKG/p1789069251953839?thread_ts=1789068764.467049&cid=CM4H43QKG` | 2026-09-30-confluence-capture/pages/IMG_9864.md |
| `https://codeconnect.fisglobal.com/app/home` | 2026-09-30-fis-payment-initiation-api-meeting/meeting-summary.md, 2026-09-30-fis-payment-initiation-api-meeting/pages/IMG_9755.md |
| `https://confluence.kdc.capitalone.com/display/EFG/Creating` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://confluence.kdc.capitalone.com/spaces/CRYPTO/pages/3036482389/PGP` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://confluence.kdc.capitalone.com/spaces/CRYPTO/pages/3036482419/XXX` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://crypto-intake.cloud.capitalone.com/` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://devnavhub.cloud.capitalone.com/docs/default/component/ci636098482` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange-qa.clouddqt.capitalone.com/file-transfers/routes/register/route-details` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange.cloud.capitalone.com/apis/3609245/1.0/docs` | 2026-09-30-confluence-capture/pages/IMG_9829.md |
| `https://exchange.cloud.capitalone.com/dataset/register` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange.cloud.capitalone.com/dataset/register/external-data/eligibility` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange.cloud.capitalone.com/datashares/register/team` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange.cloud.capitalone.com/file-transfers/dashboard/` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange.cloud.capitalone.com/file-transfers/routes/register/route-details` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange.cloud.capitalone.com/help/assets/file-transfers/create/route-creation` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://exchange.cloud.capitalone.com/help/assets/file-transfers/partner-management/connectivity` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://filetransferportal-qa.clouddqt.capitalone.com/partner-controller/requests/new` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://filetransferportal.cloud.capitalone.com/partner-controller/requests/new` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://github.com/cof-primary/PaymentExchange-bad-bank-account-backend-fg` | 2026-09-30-confluence-capture/pages/IMG_9823.md |
| `https://github.com/cof-primary/PaymentExchange-bad-bank-account-fg` | 2026-09-30-confluence-capture/pages/IMG_9823.md |
| `https://github.com/cof-primary/PaymentExchange-payx-bank-availability-gen3` | 2026-09-30-confluence-capture/pages/IMG_9823.md |
| `https://immerse.cloud.capitalone.com/edatasupport/enterprise-data-customer-support-intake` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://immerse.cloud.capitalone.com/file-transfer-onboarding/file-transfer-intake-form` | 2026-09-30-confluence-capture/pages/IMG_9863.md |
| `https://lucid.app/lucidchart/8563b01f-a800-4af1-9f39-7e3d2eac3f82/edit?invitationId=inv_8b43d44f-5d9e-4f2c-9aca-` | 2026-09-30-confluence-capture/pages/IMG_9776.md |
| `https://lucid.app/lucidchart/c345908a-11f4-4fd8-8d9c-ce7be30d6877/edit?viewport_loc=-941%2C-494%2C4235%2C2207%2C0_0&invitationId=inv_d8d9e7ec-e9d4-403e-a59e-e88446e8a509` | 2026-09-30-confluence-capture/pages/IMG_9774.md |
| `https://oneplace.capitalone.com/oneplace/ls/community/external-file-gateway-efg` | 2026-09-30-confluence-capture/pages/IMG_9863.md |

## 2. Links with the target not visible (119 markers)

| File | Line | Text around the link |
|---|---|---|
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 19 | dy/Jen Schaffer, Travis Goad / — (§10 Pending Decision, not a numbered OQ) / ADR-0003 §10 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 20 | ub-page open questions, not a main-ADR §11 OQ) / Capability 6 (OFAC Screening) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 21 | Unassigned / — (not tracked as an OQ anywhere) / Capability 6 (OFAC Screening) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 22 | Unassigned / — (not tracked as an OQ anywhere) / Capability 6 (OFAC Screening) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 24 | an ADR OQ) / ADR-0003 §4a Change 1; Capability 1 (Payment API Externalization) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 25 | / — (not tracked as an OQ anywhere) / Capability 18 (Repairs / Cancellations) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 26 | eclassify to Phase 2 / LOB owners / FinX / — (resolved via §4h, not an OQ) / ADR-0003 §4h [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 27 | 9 Dependency 6, not a numbered OQ) / Capability 22 (VPN appliance replacement) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 28 | , not a numbered OQ) / Capability 4 (Account Qualification for Corporate/eBAM) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9762.md | 38 | - Blue text in the Source Location column is link text (marked [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 17 | option still pending FIS / [cut off] / [cut off] not a numbered OQ) / [cut off] ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 18 | , not a numbered OQ) / Capability 4 (Account Qualification for Corporate/eBAM) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 19 | -precedence rule) / ADR-0003 §4e; Capability 8 (FX Integration JPM direct API) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 21 | gned / — (not tracked as an OQ anywhere) / Capability 5 (BIC & ABA Enrichment) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 22 | / Unassigned (Pod 2) / — (not in ADR at all) / Capability 26 (Reconciliation) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 23 | / ADR-0003 §4e / OQ1, OQ14, OQ15; Capability 8 (FX Integration JPM direct API) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 24 | Vendor Management, Kiran / **OQ13** / Capability 3 (Submit Request to OPF API) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 24 | ty 3 (Submit Request to OPF API) - ADR-0003 [link] v4; Capability 10 (Wire II) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 24 | ) - ADR-0003 [link] v4; Capability 10 (Wire II) - ADR-0003 [link] v3; ADR-0003 §4c / OQ13 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 25 | II (item 10) / Kiran, FIS/Vendor Management / **OQ12, OQ20** / ADR-0003 §4d / OQ12, OQ20 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9763.md | 26 | the precedence *rule*, not the [cut off] / WS4, Capital Markets / **OQ2** / ADR-0003 §11 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 18 | , not the source-conflict design question / WS4, Capital Markets / **OQ2** / ADR-0003 §11 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 19 | Engineering, PayX / **OQ3** / ADR-0003 §11; Capability 25 (Reports to OneLake) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 20 | . Affects GPN-side build scope (Pod 3/GPN) / Susan, Scott, Kiran / **OQ4** / ADR-0003 §11 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 21 | rations needs confirming. Affects Pod OnePay scope / OnePay, EWO / **OQ5** / ADR-0003 §11 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 22 | se on this tracker / EPGO / EWO, Risk / **OQ6** / ADR-0003 §11; ADR-0003 §8 (Contingency) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 23 | cott, Kiran / **OQ9** / ADR-0003 §11; Capability 11 (Flat Files consolidation) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 24 | ayX architecture / **OQ11** / ADR-0003 §11; Capability 2 (OPF API integration) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 25 | iran / **OQ16** / ADR-0003 §11; Capability 12 (WIRE-OPF-OUTBOUND SAGA in PayX) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 26 | itecture / **OQ17** / ADR-0003 §11; Capability 9 (DFS PayX Submission Service) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 27 | sk, currently untracked elsewhere / Kiran, DXGW/KRS owners, DFS / **OQ18** / ADR-0003 §11 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 28 | off] / **OQ19** / ADR-0003 §11; Capability 1 (Payment API Externalization) - ADR-0003[?] [link] |
| 2026-09-30-confluence-capture/pages/IMG_9764.md | 40 | - Blue text in the Source Location column is link text (marked [link] |
| 2026-09-30-confluence-capture/pages/IMG_9765.md | 17 | itecture / **OQ17** / ADR-0003 §11; Capability 9 (DFS PayX Submission Service) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9765.md | 18 | sk, currently untracked elsewhere / Kiran, DXGW/KRS owners, DFS / **OQ18** / ADR-0003 §11 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9765.md | 19 | itecture / **OQ19** / ADR-0003 §11; Capability 1 (Payment API Externalization) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9765.md | 20 | ure, DXGW/KRS owners / **OQ21** / ADR-0003 §11; Capability 7 (Client Registry) - ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9776.md | 23 | [link] |
| 2026-09-30-confluence-capture/pages/IMG_9797.md | 13 | off] to backup your space. For instructions on doing this and more details, refer to this [link] |
| 2026-09-30-confluence-capture/pages/IMG_9811.md | 19 | ion)** in §4b. [cut off] **separate from** the DFS PayX Submission Service (Capability 9) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9811.md | 25 | cut off] Requests API v1.0** — initial draft: cof-sandbox/ep-external-payment-request-api [link] |
| 2026-09-30-confluence-capture/pages/IMG_9812.md | 19 | is capability is **separate from** the DFS PayX Submissio[cut off] Service (Capability 9) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9812.md | 25 | Payment Requests API v1.0** — initial draft: cof-sandbox/ep-external-payment-request-api [link] |
| 2026-09-30-confluence-capture/pages/IMG_9813.md | 39 | .** Partner fetches the current Capital One public key via DevExchange Public Key Sharing [link] |
| 2026-09-30-confluence-capture/pages/IMG_9813.md | 39 | e public key via DevExchange Public Key Sharing [link] and follows Field-level encryption [link] |
| 2026-09-30-confluence-capture/pages/IMG_9813.md | 52 | - The DFS PayX Submission Service (Capability 9) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9814.md | 23 | Only authorised initiators may start a `WIRE-GPN-OUTBOUND` payment (Capability 12 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9814.md | 28 | - The `CLIENTREGISTRY` stage of the WIRE-GPN-OUTBOUND saga [link] |
| 2026-09-30-confluence-capture/pages/IMG_9814.md | 49 | - the DFS PayX Submission Service [link] |
| 2026-09-30-confluence-capture/pages/IMG_9814.md | 56 | e.g. initiation source = DFS Submission AP[cut off] Network Originator). See Capability 9 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9814.md | 69 | - The `CLIENTREGISTRY` stage of the WIRE-GPN-OUTBOUND saga [link] |
| 2026-09-30-confluence-capture/pages/IMG_9814.md | 71 | - Authorises the initiating DevExchange/Exchange client ID (see main ADR §4g, ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9814.md | 71 | R-0003 [link]); the client is externalised via Capability 1 (Payment API Externalization) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9815.md | 45 | risation (Phase 1).** For the OPF-routed outbound wire saga (`WIRE-GPN-OUTBOUND`, item 12 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9815.md | 45 | es for downstream attribution, routing, and reporting. See Capability 7 (Client Registry) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9816.md | 13 | off] to backup your space. For instructions on doing this and more details, refer to this [link] |
| 2026-09-30-confluence-capture/pages/IMG_9816.md | 21 | As part of ADR-0003 Phase 1 Interim — Converge DFS GPN Wires to PayX, Settle in OPF (FIS) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9816.md | 21 | and as well as ADR-0004 Phase 2 — Complete the OPF (FIS) Exit from the Phase 1 End-State [link] |
| 2026-09-30-confluence-capture/pages/IMG_9816.md | 33 | - Accepts Field Level Encryption [link] |
| 2026-09-30-confluence-capture/pages/IMG_9816.md | 51 | ntract (External Payment Requests API v1.0, initial draft ep-external-payment-request-api [link] |
| 2026-09-30-confluence-capture/pages/IMG_9816.md | 51 | st-api [link]) — is a separate capability: see Capability 1 (Payment API Externalization) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9821.md | 13 | ut off] backup your space. For instructions on doing this and more details, refer to this [link] |
| 2026-09-30-confluence-capture/pages/IMG_9822.md | 13 | off] to backup your space. For instructions on doing this and more details, refer to this [link] |
| 2026-09-30-confluence-capture/pages/IMG_9839.md | 13 | d t[cut off] backup your space. For instructions on doing this and more details, refer to [link] |
| 2026-09-30-confluence-capture/pages/IMG_9839.md | 17 | Created by [link] |
| 2026-09-30-confluence-capture/pages/IMG_9839.md | 17 | Created by [link] Mayor, Cameron on [link] |
| 2026-09-30-confluence-capture/pages/IMG_9840.md | 13 | [cut off] to backup your space. For instructions on doing this and more details, refer to [link] |
| 2026-09-30-confluence-capture/pages/IMG_9840.md | 17 | Created by [link] |
| 2026-09-30-confluence-capture/pages/IMG_9840.md | 17 | Created by [link] Mayor, Cameron, last updated by [link] |
| 2026-09-30-confluence-capture/pages/IMG_9840.md | 23 | As part of [link] |
| 2026-09-30-confluence-capture/pages/IMG_9841.md | 36 | hing, securing, and cataloguing the integration. Generating the `pain.001.001.11` JSON is [link] |
| 2026-09-30-confluence-capture/pages/IMG_9841.md | 36 | `pain.001.001.11` JSON is [link] Capability 10 (Wire II), and submitting each payment is [link] |
| 2026-09-30-confluence-capture/pages/IMG_9847.md | 21 | / **Problem Statement** / After Capability 10 (Wire II) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9847.md | 22 | firewall, DevExchange registration) is established by Capability 2 (OPF API integration) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9847.md | 22 | is established by Capability 2 (OPF API integration) [link].<br>• Capability 10 (Wire II) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9847.md | 25 | PF API:<br><br>1. **Consumes** the JSON `pain.001.001.11` from the SQS queue that Wire II [link] |
| 2026-09-30-confluence-capture/pages/IMG_9847.md | 25 | T /customer-credit-transfer-initiations`) over the connection established in Capability 2 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9848.md | 16 | PF API:<br><br>1. **Consumes** the JSON `pain.001.001.11` from the SQS queue that Wire II [link] |
| 2026-09-30-confluence-capture/pages/IMG_9848.md | 16 | T /customer-credit-transfer-initiations`) over the connection established in Capability 2 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9848.md | 18 | / **Implications** / • Depends on Capability 10 (Wire II) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9848.md | 18 | Depends on Capability 10 (Wire II) [link] for the JSON `pain.001` on SQS and Capability 2 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9849.md | 23 | t connects to eBAM. There is a dataset that is populated daily around 22:30 (dataset link [link] |
| 2026-09-30-confluence-capture/pages/IMG_9850.md | 22 | is extended to V11.<br>• The v9→V11 delta is as summarised in the main ADR §4d (ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9850.md | 23 | ess Application Header, per the OPF API contract — see Capability 2 (OPF API integration) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9850.md | 25 | y — submission is decoupled via SQS and owned by Capability 3 (Submit Request to OPF API) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9851.md | 15 | y — submission is decoupled via SQS and owned by Capability 3 (Submit Request to OPF API) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9851.md | 17 | xisting v9 `pain.001` converter to V11; the v9→V11 delta is in the main ADR §4d (ADR-0003 [link] |
| 2026-09-30-confluence-capture/pages/IMG_9851.md | 17 | `pain.001.001.11` placed on SQS and consumed by Capability 3 (Submit Request to OPF API) [link] |
| 2026-09-30-confluence-capture/pages/IMG_9854.md | 24 | heir pros and cons. For pros and cons, consider how did the options meet Enterprise NFRs [link] |
| 2026-09-30-confluence-capture/pages/IMG_9854.md | 24 | sider how did the options meet Enterprise NFRs [link], Cyber requirements, and Enterprise [link] |
| 2026-09-30-confluence-capture/pages/IMG_9854.md | 24 | the options meet Enterprise NFRs [link], Cyber requirements, and Enterprise [link] & C1S [link] |
| 2026-09-30-confluence-capture/pages/IMG_9855.md | 24 | heir pros and cons. For pros and cons, consider how did the options meet Enterprise NFRs [link] |
| 2026-09-30-confluence-capture/pages/IMG_9855.md | 24 | sider how did the options meet Enterprise NFRs [link], Cyber requirements, and Enterprise [link] |
| 2026-09-30-confluence-capture/pages/IMG_9855.md | 24 | the options meet Enterprise NFRs [link], Cyber requirements, and Enterprise [link] & C1S [link] |
| 2026-09-30-confluence-capture/pages/IMG_9858.md | 27 | support exists via EFG Office Hours (Tue/Wed/Thu 2–3pm ET) and the #enterprise-data-help [link] |
| 2026-09-30-confluence-capture/pages/IMG_9859.md | 17 | support exists via EFG Office Hours (Tue/Wed/Thu 2–3pm ET) and the #enterprise-data-help [link] |
| 2026-09-30-confluence-capture/pages/IMG_9860.md | 47 | - Go to `exchange.cloud.capitalone.com/dataset/register/external-data/eligibility` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9860.md | 53 | - `exchange.cloud.capitalone.com/datashares/register/team` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9860.md | 58 | - QA: `filetransferportal-qa.clouddqt.capitalone.com/partner-controller/requests/new` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9860.md | 59 | - Prod: `filetransferportal.cloud.capitalone.com/partner-controller/requests/new` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 19 | - `exchange.cloud.capitalone.com/datashares/register/team` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 24 | - QA: `filetransferportal-qa.clouddqt.capitalone.com/partner-controller/requests/new` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 25 | - Prod: `filetransferportal.cloud.capitalone.com/partner-controller/requests/new` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 37 | exchange.cloud.capitalone.com/help/assets/file-transfers/partner-management/connectivity` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 37 | PGP key details/status are also centrally listed at `crypto-intake.cloud.capitalone.com` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 41 | - Support for PGP-specific questions: #pgp-support [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 45 | - QA: `exchange-qa.clouddqt.capitalone.com/file-transfers/routes/register/route-details` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9861.md | 46 | - Prod: `exchange.cloud.capitalone.com/file-transfers/routes/register/route-details` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 19 | - QA: `exchange-qa.clouddqt.capitalone.com/file-transfers/routes/register/route-details` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 20 | - Prod: `exchange.cloud.capitalone.com/file-transfers/routes/register/route-details` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 29 | an OneStream schema/platform-attachment issue, not EFG. Raise it in #enterprise-data-help [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 36 | / Portal/onboarding/route/partner questions / #enterprise-data-help [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 37 | EFG Office Hours — Tue/Wed/Thu 2:00–3:00 PM ET, Zoom link posted in #enterprise-data-help [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 38 | form: `immerse.cloud.capitalone.com/edatasupport/enterprise-data-customer-support-intake` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 39 | est publishing issues (file delivered but not in OneLake) / #onestream-publishing-support [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 40 | / Tokenization/detokenization (Turing) / #turing-support [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 40 | port [link], docs at `devnavhub.cloud.capitalone.com/docs/default/component/ci636098482/` [link] |
| 2026-09-30-confluence-capture/pages/IMG_9862.md | 41 | PGP key questions (rotation, import, which key to use, keypair generation) / #pgp-support [link] |
| 2026-09-30-confluence-capture/pages/IMG_9881.md | 45 | - **ADR-0003** — [link] |
