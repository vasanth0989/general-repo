# Billpay explorer — development release 0.10.0

Source, standalone tests and the prebuilt app are included. Sample datasets, benchmark files, screenshots and node_modules are excluded.

## Run on Mac or Windows

Stop the previous server with Ctrl+C. Extract this ZIP into a separate folder, open Terminal there and run:

```sh
npm start
```

Open http://127.0.0.1:4173 and refresh. The footer should say 0.10.0. No npm install is needed to use the prebuilt app.

For local editing through your approved Artifactory registry:

```sh
npm config get registry
npm ci
npm run dev
```

Open http://127.0.0.1:5173. Save source changes for live updates. Run npm run check to test and build, then npm start to serve the new dist. Node >=22.12 required. Vite stays at 8.3.1; no new dependencies were added. Do not copy Windows node_modules to Mac. Keep Mac node_modules for source-only updates; run npm ci when dependencies change. Back up local edits before replacing source. Preserve enterprise credentials/settings and use the approved registry. The supplied .npmrc disables dependency lifecycle scripts and does not override registry or authentication.

Keep input files outside public/, dist/ and project source folders, which development servers may serve.

## Customer master correction

Member is the authoritative customer master. Distinct sponsor + Member ID values in accepted Member rows define customer count and the Customers list. Consumer rows are funding accounts, never additional customers. Repeated Member rows remain one customer; accepted Member row counts are reported separately. Without Member, customer count is zero and source records remain in an unlinked review view.

Member is processed first. Consumer and Payee rows first use exact sponsor + Member ID. If that Member ID is not found, a unique sponsor + Sponsor Member ID alias can link the row; the differing Member ID is reported in match evidence. Exact matches can register source aliases only after conflict checks. Payment rows use the same unambiguous scoped aliases. Known Member IDs pointing to different customers, ambiguous aliases and different sponsors are not merged. No matching by customer name or CIF. Customer IDs and account identifiers are never numerically converted or stripped of zeros. These are explicit source reconciliation rules, not a vendor-approved join contract; actual delivery equality still requires verification.

CIF comes only from Member Secure login ID, ordinal 7, length 64, derived positions 251–314. It remains a string, including numeric-only values beginning with 00 and values larger than JavaScript's integer precision. The previous all-file group count could double the customer list when keys differed; that behavior is removed. Unlinked records are visible separately and never inflate Member customer counts. Data quality > Customer master reconciliation reports linked/unlinked counts and matching reasons by file layout, without requiring raw customer records to be shared.

## Customer navigation and CIF

Start in Customers. The first column is CIF, taken from Member Secure login ID (64 characters, derived positions 251–314). CIF is DFS terminology confirmed by the user, not a vendor field rename. Search CIF, Member ID, Sponsor Member ID or name; all identifiers preserve leading zeros. Missing CIF stays explicitly absent; conflicting values are retained and warned. CIF never replaces sponsor/member source joins.

Open a customer for a full workspace with payees, duplicate payees, funding accounts, one-time payments, recurring instructions, supplied instances, future-dated supplied payments, and history. Open a payee for the same payment categories restricted to that customer/payee. Breadcrumbs return to the customer or customer search. Payment detail includes source evidence. No unsupplied payment is generated.

Duplicate payees is a separate customer tab and a global navigation entry. It flags repeated relationship keys and possible duplicates across different relationships with the same normalized name and exact full payee account in one customer. Normalization only changes name case and whitespace. Blank accounts and names are excluded from the latter heuristic; matching masked last four alone is insufficient. These are review rules, not proven duplicate entities. Nothing is merged or removed. Repeated-key source variants are available in Payee & source details; payment association remains ambiguous for those keys.

## Funding account filters and chart

The Funding accounts page shows account-row counts and percentages by the FI Account Type actually supplied in Consumer. The dropdown and clickable bars use the same scoped inventory; totals remain before search/type filters, within the selected customer when applicable. Counts include repeated Consumer rows, not deduplicated physical accounts.

DDA is Checking and SV is Savings according to the supplied layout. Other codes, including blank, are now retained with a warning and displayed as unmapped / Not supplied rather than rejected. No money-market code is inferred without source evidence. This can increase accepted-row counts relative to previous releases when undocumented type codes are present.

Use Account number to search a full number or any contiguous part; leading zeros are preserved. Combine it with account type and the existing text search. Full account and routing numbers are displayed and included in exported summaries, as explicitly requested by the user. Private lookup indexes are omitted. Reset filters clears the number, type and text query without losing the selected customer.

## Explore

- Every Overview metric opens a record explorer. Customer rows open the full customer workspace.
- Funding accounts show source reference, full account/routing, primary/secondary status and source line. Follow a reference to matching payment rows.
- Payees supports name, nickname, relationship and customer search. Inspect scheduled/history row counts and exact amounts; open a payee to view associated payment records.
- Payments supports single, model, instance, history, future, unresolved and unmatched/conflicting filters. Open any record for dates, amount, source codes and mapping evidence.
- Payment detail shows candidate, ambiguous, conflicting or unmatched payee/funding results. Source filename and line number make every observation traceable. These are source-to-source candidate matches, not target-system mappings.
- Data quality distinguishes excluded invalid records from retained warnings. Observed recurring identifier/frequency combinations are counted. Re-run from Data quality after changing the blank-model interpretation.
- Search/paging and payment-detail scans run in a worker. Up to 100 matched rows are sent to the interface at a time.

## Recurring rules

User-confirmed prior-project convention: blank identifier at 573–574 means recurring model. Enabled by default; optionally disable to inspect unresolved blanks. Identifier 1 means an instance. A populated documented instance frequency (0–8) is retained in diagnostics without a warning. Unsupported frequencies still raise a warning; the instance is retained. Numeric frequency padding is normalized (000004 -> 4); raw values stay visible. Other identifier values remain unresolved, outside known model/instance totals.

The current user-approved scope analyzes supplied records only. No projections are calculated or required. A delivery with models and no instances is valid; instructions remain inspectable and the instance view reports no instances supplied. Historical prior-project projection behavior is outside this dashboard scope. Models are excluded from instance/history amounts. No global payment deduplication is assumed.

Manual model-instance candidate grouping uses exact SponsorMemberID + PayeeRelationshipNumber + FIAccountNumber + FISRecurringRuleDB, additionally scoped by sponsor. The user explicitly says Rule DB equality across model/instance is unproven. A candidate is not a production-verified link, and no link is inferred from amount or dates.

## Mapping rules and limitations

Exact sponsor-scoped Member identity and unambiguous source aliases scope joins, as described above. Leading zeros are preserved. The headline and default customer explorer both use distinct sponsor + Member ID from Member only. The exported consumerCustomers metric separately retains the distinct sponsor + Member ID count from Consumer.

Payee association uses sponsor/member/relationship. Repeated keys are ambiguous; displayed metadata comes from the first row, and no records are automatically deduplicated. Search is over the Payee file name/nickname; independent Nickname identifiers are not automatically joined because their cross-file meaning remains unverified.

Funding first compares the customer's exact FI account reference, then exact routing/account if no reference candidate exists. Multiple matching Consumer rows remain ambiguous. A reference match with different supplied routing/account is a conflict. Account-reference drilldown lists the rows that use that reference; it does not prove all those rows have consistent account fields. Account and routing numbers are shown in full in UI/export. SSNs, tax IDs, emails, addresses and free-text memos are not selected for drilldown.

Source profile remains provisional: contiguous ASCII fixed width, space padding, LF/CRLF lines. No automatic header/trailer stripping. Only Nickname offsets are printed; others derive from ordered lengths. Observed layout revision February 17, 2010; approval/current applicability unknown. Missing files or invalid/unclassified rows mean incomplete coverage. Warning rows remain in totals.

History statuses are presented as supplied; successful processing, ACH transmission, settlement and cutover ownership are not inferred. Monetary aggregation uses integer minor units with two display decimals; currency is unspecified. Model amounts are never combined with instance/history amounts.

## Performance and privacy

No fixed file-size cap. One delivery at a time; one file per recognized layout; up to 300 selected files. Files stream in 1 MiB chunks. The worker retains customer, account and payee indexes and File handles, and re-reads payment files on demand for searches. New searches cancel previous scans. A scan over large payment files may take time even when only 100 rows are displayed.

Memory scales with unique customers and account/payee keys, not just record count. Richer indexes use more RAM than v0.3. The v0.7 700,000-row test with 100,000 customers took 3.36s in Node, observed process RSS about 864 MiB. Filtered history lookup took 0.48s. These are Windows observations, not Mac/browser guarantees.

No file uploads, telemetry, input modifications or persistent browser storage. Refresh clears the session. Summary export contains CIF values, names, identifiers, full account details and source locations; it does not include raw payment records or private lookup maps. Treat exports as sensitive.

## Source map

src/AnalysisApp.tsx and explorer.css implement navigation/details. src/core/record.mjs centralizes field selection/validation. analysis.mjs aggregates and indexes relationships. stream.mjs reads bounded chunks. explore.mjs pages entities and scans payment details. analysis.worker.ts coordinates work and cancellation. layouts.json contains the evidence catalog. server/index.mjs serves the prebuilt UI only on loopback. tests/ runs without external sample files.

## Version 0.8 reconciliation fix

The supplied v0.7 report showed 151 Consumer and 341 Payee rows unlinked because Member ID was not found, while payment/history rows linked through Sponsor Member ID. Version 0.8 permits the unique scoped alias fallback even when an unmatched Member ID is populated. True conflicts remain visible. Screenshot evidence establishes the rejected branch, not raw-file identifier equality; re-analysis is required to verify the actual delivery.

Funding ownership totals explicitly indicate incomplete linking when needed. Payment/model rows without a Payee-file relationship are counted, and missing payees do not open an empty payee page. The header separates records read, parsing errors, missing files, customer linking and recurring classification. The supplied 1,390 source-record count is not an error count.

## Version 0.10.0: Sponsor ID padding correction

Production diagnostic screenshots establish that all 151 Consumer and 341 Payee rows match a unique master when only numeric Sponsor ID zero-padding is reconciled. Both customer identifiers already match; the mismatch was sponsor formatting. The prior v0.8 fallback did not address it.

Exact joins run first. If neither exact path exists, a comparison-only Sponsor ID key removes leading zeros from digit-only sponsor strings. Raw Sponsor ID fields, Member IDs, Sponsor Member IDs, CIFs, account/routing numbers and master identities remain unchanged. A fallback with multiple master candidates or conflicting direct/alias identifiers remains unlinked. Match evidence explicitly reports Sponsor ID zero-padding reconciled. This delivery-driven compatibility rule is not a vendor-approved global identifier contract.

Update: stop the old server; extract this package separately and run npm start. For existing development installations, back up local edits and replace source/build files while preserving the Mac node_modules and enterprise registry settings, then restart npm run dev. Dependencies are unchanged. Refresh the browser, verify version 0.10.0 and select the delivery again. No sample datasets are included.

## Customer duplicate segmentation — 0.10.0

Customers offers All customers, Exactly 2, Exactly 3, Exactly 4 and 5+. Counts include each distinct payee relationship participating in possible duplicate groups once per customer; two separate pairs count as four. Repeated source rows for a single relationship remain visible through Data quality > Repeated payee keys and are excluded from the duplicate-payee total. Detection evidence and source rows are unchanged.

Filter counts reflect the current customer search and other customer filters before duplicate-count selection. Search combines with the segment. Click a customer duplicate count to open their duplicate-payee tab. The Customers breadcrumb or sidebar restores the saved segment, search and page. Clear search retains the segment; Reset filters returns to all Member customers. Choosing a new delivery or re-analyzing resets saved navigation.

The summary export remains a whole-delivery report. No sample datasets or node_modules are included; dependencies unchanged.

## Customer sorting — 0.10.0

Click Account rows, Linked payees, Duplicate payees, Payment instances, Models, History rows or History amount to sort ascending; click again for descending. Only one column is active. CIF, Customer, Member ID and Sponsor member ID remain unsortable. Sorting runs in the worker across all filtered customers before pagination. Equal values keep their original order. History amounts compare integer minor units without floating-point conversion.

Search and duplicate segmentation combine with sorting. Changing sort resets to page one; customer return navigation preserves sort, filters, search and page. Reset filters restores the original order. Source/customer arrays and summary export order are unchanged.
