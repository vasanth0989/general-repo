# Validation — 0.10.0

2026-10-05, Windows. 46 tests pass; TypeScript and Vite build pass; npm lockfile audit reports zero vulnerabilities.

Tests cover all seven numeric sort columns, both directions, amount differences beyond Number precision, source immutability, invalid sort keys, stable ties, filtered sorting before pagination over 205 customers, empty results and duplicate/search composition. Existing mapping tests remain green.

Browser verified ascending/descending Linked payees and returning from customer detail with descending sort retained. Screenshot uses synthetic records only. No datasets or node_modules shipped.
