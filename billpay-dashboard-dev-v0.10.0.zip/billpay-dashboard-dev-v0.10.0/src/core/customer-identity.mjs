const sponsor=r=>r['Sponsor Id']||r['Sponsor ID'];
const memberKey=r=>JSON.stringify(['member',sponsor(r),r['Member ID']]);
const sourceKey=r=>JSON.stringify([sponsor(r),r['Sponsor Member ID']||r['Sponsor Member id']||r['Sponsor member id']]);
// Delivery diagnostics (IMG_9929–9935) establish numeric Sponsor ID padding differences.
// Normalize only a comparison key, never the source field or a customer/account identifier.
const sponsorComparison=s=>/^\d+$/.test(s)?s.replace(/^0+(?=\d)/,''):s;
const comparisonKey=(r,id)=>JSON.stringify([sponsorComparison(sponsor(r)),id]);
const sponsorMember=r=>r['Sponsor Member ID']||r['Sponsor Member id']||r['Sponsor member id'];
const add=(map,key,value)=>{const keys=map.get(key)||new Set();keys.add(value);map.set(key,keys);};
export const createIdentity=()=>({members:new Map(),aliases:new Map(),paddedMembers:new Map(),paddedAliases:new Map()});
// Exact, sponsor-scoped source identifiers only. Never convert identifiers to numbers.
export function identifyCustomer(r,index,{master=false,register=false}={}){
 const raw=sourceKey(r),member=r['Member ID'],key=memberKey(r);
 if(master){index.members.set(key,key);add(index.aliases,raw,key);add(index.paddedMembers,comparisonKey(r,member),key);add(index.paddedAliases,comparisonKey(r,sponsorMember(r)),key);r._customerKey=key;r._customerMapping='Member master';return;}
 const direct=member?index.members.get(key):null,aliases=index.aliases.get(raw)||new Set();
 const conflict=aliases.size>1||(direct&&aliases.size===1&&!aliases.has(direct));
 if(conflict){r._customerMapping='Conflicting or ambiguous customer identifiers';}
 else if(direct){if(register&&aliases.size===0){index.aliases.set(raw,new Set([direct]));add(index.paddedAliases,comparisonKey(r,sponsorMember(r)),direct);}r._customerKey=direct;r._customerMapping='Exact sponsor + Member ID';return;}
 else if(aliases.size===1){r._customerKey=[...aliases][0];r._customerMapping=member?'Unique sponsor + Sponsor Member ID; Member ID differs':'Unique sponsor + Sponsor Member ID alias';return;}
 else {
  const members=member?index.paddedMembers.get(comparisonKey(r,member))||new Set():new Set();
  const sources=index.paddedAliases.get(comparisonKey(r,sponsorMember(r)))||new Set();
  const candidates=new Set([...members,...sources]);
  if(candidates.size===1){
   const matched=[...candidates][0];r._customerKey=matched;
   r._customerMapping=members.size?'Exact Member ID; Sponsor ID zero-padding reconciled':'Unique Sponsor Member ID; Sponsor ID zero-padding reconciled';
   if(register&&members.size){add(index.aliases,raw,matched);add(index.paddedAliases,comparisonKey(r,sponsorMember(r)),matched);}
   return;
  }
  r._customerMapping=candidates.size>1?'Conflicting or ambiguous customer identifiers after Sponsor ID padding comparison':member?'Member ID not found in Member file':'Sponsor Member ID not linked to Member file';
 }
 r._customerKey=JSON.stringify(['unlinked',raw,member||'']);
}
