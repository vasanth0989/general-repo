import {createIdentity,identifyCustomer} from './customer-identity.mjs';
import {validDate,prepareLayout,parseRecord,customerKey,payeeKey} from './record.mjs';
export {validDate} from './record.mjs';
export const aliases={Consumer:'consumer',Consumer_Payee:'payee',CSP_Member:'member',History:'payment_history',Payee_Nickname:'payee_nickname',Recurring_Payment:'recurring_payments',Single_Payment:'single_payments'};
export function identify(name){
 if(/(^|_)ebills(_|\.)/i.test(name))return 'excluded';
 return Object.entries(aliases).sort((a,b)=>b[0].length-a[0].length).find(([token])=>new RegExp('(^|_)'+token+'(_|\\.)','i').test(name))?.[1]||'';
}

export function fundingMatch(r,index){
 const key=customerKey(r),ref=r['FI Account Reference Number'],number=r['FI Account Number'],routing=r['FI R&T'];
 const candidates=ref?index.refs.get(JSON.stringify([key,ref]))||[]:[];
 const exact=number&&routing?index.numbers.get(JSON.stringify([key,routing,number]))||[]:[];
 const rows=candidates.length?candidates:exact;
 if(!rows.length)return {status:'Unmatched',basis:ref?'No matching customer + account reference':'No matching customer + routing/account',count:0};
 if(rows.length>1)return {status:'Ambiguous',basis:'Multiple Consumer rows match; no account chosen',count:rows.length};
 const a=rows[0];if(candidates.length&&((number&&number!==a.number)||(routing&&routing!==a.routing)))return {status:'Conflict',basis:'Reference matches but account/routing differs',count:1,source:a.source};
 return {status:'Candidate match',basis:candidates.length?'Customer + funding reference; supplied account/routing agree':'Customer + exact routing and account',count:1,source:a.source};
}
export function createAnalyzer(catalog,asOf,blankModels=false){
 if(!validDate(asOf))throw Error('Choose a valid analysis date.');
 const files=[],issues=[],seen=new Set(),consumerIds=new Set(),cspIds=new Set(),customers=new Map(),payees=new Map(),accounts=[],accountNumbers=[],historyDates={},recurringDiagnostics=new Map();
 const funding={refs:new Map(),numbers:new Map()},rules=new Map(),duplicateIdentity=new Map();
 const identity=createIdentity(),customerLinks={};
 let issueCount=0,warningCount=0,current=null;
 const metrics={customers:0,accounts:0,cspMembers:0,payees:0,uniqueRelationships:0,duplicateSurplus:0,nicknames:0,single:0,singleMinor:0n,pendingApproval:0,models:0,instances:0,unclassified:0,unclassifiedMinor:0n,instanceMinor:0n,future:0,today:0,history:0,historyMinor:0n,unmatchedRelationships:0,ambiguousRelationships:0,multiAccountCustomers:0,fundingUnmatched:0,fundingAmbiguous:0,fundingConflict:0};
 const ensure=r=>{const key=customerKey(r);let c=customers.get(key);if(!c){c={key,isMember:false,memberRows:0,memberSources:[],mapping:r._customerMapping,id:r['Sponsor Member ID']||r['Sponsor Member id']||r['Sponsor member id'],sponsor:r['Sponsor Id']||r['Sponsor ID'],memberId:r['Member ID']||'',memberIds:[],cifs:[],cifSources:[],name:'',accounts:0,payees:0,uniquePayees:0,duplicatePayees:0,future:0,single:0,models:0,instances:0,unclassified:0,history:0,historyMinor:0n};customers.set(key,c);}const name=r['Business Name']||r['Business name']||[r['First Name'],r['Last Name']||r['Last Name/Business Name']].filter(Boolean).join(' ');if(name&&!c.name)c.name=name;if(r['Member ID']&&!c.isMember){c.memberId=r['Member ID'];if(!c.memberIds.includes(r['Member ID']))c.memberIds.push(r['Member ID']);}return c;};
 const note=(message,severity)=>{if(severity==='rejected')issueCount++;else warningCount++;if(issues.length<200)issues.push({file:current.f.name,line:current.line,message,severity});};
 function begin(input){
  const id=identify(input.name)==='excluded'?'excluded':input.layout??identify(input.name),f={name:input.name,layout:id,rows:0,rejected:0,warnings:0,state:id==='excluded'?'Ebills excluded':!id?'Unrecognized — skipped':'Parsed'};
  files.push(f);current=null;if(!id||id==='excluded')return false;
  if(seen.has(id))throw Error('More than one file is assigned to '+id+'. Select one delivery at a time.');
  const layout=catalog.layouts.find(l=>l.id===id);if(!layout)throw Error('Unknown file layout.');
  seen.add(id);current={id,f,layout:prepareLayout(layout),line:0};return true;
 }
 function line(text){
  const {id,f,layout}=current;current.line++;const parsed=parseRecord(text,layout,blankModels);
  if(parsed.error){f.rejected++;f.state='Partial — review required';note(parsed.error,'rejected');return;}
  const r=parsed.record,kind=parsed.kind,source={file:f.name,line:current.line,layout:id};
  for(const warning of parsed.warnings){note(warning,'warning');f.warnings++;if(!f.rejected)f.state='Parsed with warnings';}
  f.rows++;
  if(id!=='payee_nickname'){identifyCustomer(r,identity,{master:id==='member',register:id==='consumer'||id==='payee'});const diag=customerLinks[id]??={linked:0,unlinked:0,reasons:{}};const linked=r._customerMapping==='Member master'||r._customerMapping.startsWith('Exact')||r._customerMapping.startsWith('Unique');diag[linked?'linked':'unlinked']++;diag.reasons[r._customerMapping]=(diag.reasons[r._customerMapping]||0)+1;}
  if(id==='consumer'){
   metrics.accounts++;consumerIds.add(JSON.stringify([r['Sponsor Id'],r['Member ID']]));const c=ensure(r);c.accounts++;
   const a={customerKey:c.key,customer:c.name,member:c.id,sponsor:c.sponsor,reference:r['FI Account Reference Number'],account:(r['FI Account Number']||'Not supplied'),routing:(r['FI R&T']||'Not supplied'),mapping:r._customerMapping,type:r['FI Account Type'],primary:r['Primary Account Indicator'],source};
   accounts.push(a);accountNumbers.push(r['FI Account Number']);const internal={number:r['FI Account Number'],routing:r['FI R&T'],source};
   const add=(map,key)=>{const list=map.get(key)||[];list.push(internal);map.set(key,list);};
   if(a.reference)add(funding.refs,JSON.stringify([c.key,a.reference]));if(internal.number&&internal.routing)add(funding.numbers,JSON.stringify([c.key,internal.routing,internal.number]));
  }
  if(id==='member'){cspIds.add(customerKey(r));const c=ensure(r),cif=r['Secure login ID'];c.isMember=true;c.memberRows++;c.memberSources.push(source);if(cif){if(!c.cifs.includes(cif))c.cifs.push(cif);c.cifSources.push({cif,source});if(c.cifs.length>1){note('Multiple CIF values for the same sponsor/member; all retained, no CIF chosen.','warning');f.warnings++;if(!f.rejected)f.state='Parsed with warnings';}}}
  if(id==='payee'){
   metrics.payees++;ensure(r).payees++;const key=payeeKey(r),old=payees.get(key);
   if(old){old.rows++;if(!old.variants)old.variants=[{name:old.name,account:old.account,nickname:old.nickname,source:old.source}];old.variants.push({name:r['Payee Name'],account:(r['Payee Account Number']||'Not supplied'),nickname:r['Payee Nickname'],source});if(old.name!==r['Payee Name']||old._account!==r['Payee Account Number'])old.conflicting=true;}
   else payees.set(key,{key,customerKey:customerKey(r),member:r['Sponsor Member id'],sponsor:r['Sponsor Id'],mapping:r._customerMapping,relationship:r['Payee Relationship Number'],name:r['Payee Name'],nickname:r['Payee Nickname'],account:(r['Payee Account Number']||'Not supplied'),electronic:r['Electronic Indicator'],internalId:r['Internal Payee Id'],rows:1,conflicting:false,_account:r['Payee Account Number'],possibleDuplicate:false,duplicateGroup:'',future:0,unclassified:0,single:0,instances:0,models:0,history:0,historyMinor:0n,scheduledMinor:0n,source});
   const name=r['Payee Name'].toUpperCase().replace(/\s+/g,' ').trim(),account=r['Payee Account Number'];if(name&&account){const k=JSON.stringify([customerKey(r),name,account]);let group=duplicateIdentity.get(k);if(!group){group=new Set();duplicateIdentity.set(k,group);}group.add(key);}
  }
  if(id==='payee_nickname')metrics.nicknames++;
  if(id==='single_payments'){metrics.single++;metrics.singleMinor+=BigInt(r['Payment Amount']);metrics.pendingApproval+=Number(r['Payment Status']==='50');ensure(r).single++;}
  if(id==='recurring_payments'){
   const pair=JSON.stringify([r['Recurring / Single Payment Identifier'],r['Payment Frequency']]);if(recurringDiagnostics.has(pair))recurringDiagnostics.get(pair).count++;else if(recurringDiagnostics.size<200)recurringDiagnostics.set(pair,{identifier:r['Recurring / Single Payment Identifier']||'(blank)',frequency:r['Payment Frequency']||'(blank)',kind,count:1});
   if(kind==='model'){metrics.models++;ensure(r).models++;}else if(kind==='instance'){metrics.instances++;metrics.instanceMinor+=BigInt(r['Payment Amount']);ensure(r).instances++;}else{metrics.unclassified++;metrics.unclassifiedMinor+=BigInt(r['Payment Amount']);ensure(r).unclassified++;}
   if(kind==='model'&&r['FIS Recurring Rule DB']&&r['FI Account Number']){const key=JSON.stringify([payeeKey(r),r['FI Account Number'],r['FIS Recurring Rule DB']]),entry=rules.get(key)||{count:0,sources:[]};entry.count++;if(entry.sources.length<10)entry.sources.push(source);rules.set(key,entry);}
  }
  if(id==='payment_history'){metrics.history++;const c=ensure(r),amount=BigInt(r['Payment Amount']);metrics.historyMinor+=amount;c.history++;c.historyMinor+=amount;historyDates[r['Payment Date']]=(historyDates[r['Payment Date']]||0)+1;}
  const scheduled=id==='single_payments'||kind==='instance',isPayment=['single_payments','recurring_payments','payment_history'].includes(id);
  if(scheduled){ensure(r).future+=Number(r['Payment Schedule Date']>asOf);metrics.future+=Number(r['Payment Schedule Date']>asOf);metrics.today+=Number(r['Payment Schedule Date']===asOf);}
  if(isPayment){
   const p=payees.get(payeeKey(r));if(!p)metrics.unmatchedRelationships++;if(p&&p.rows>1)metrics.ambiguousRelationships++;
   if(p){if(scheduled)p.future+=Number(r['Payment Schedule Date']>asOf);if(kind==='unclassified')p.unclassified++;if(id==='single_payments')p.single++;if(kind==='instance')p.instances++;if(kind==='model')p.models++;if(id==='payment_history'){p.history++;p.historyMinor+=BigInt(r['Payment Amount']);}if(scheduled)p.scheduledMinor+=BigInt(r['Payment Amount']);}
   const match=fundingMatch(r,funding);if(match.status==='Unmatched')metrics.fundingUnmatched++;if(match.status==='Ambiguous')metrics.fundingAmbiguous++;if(match.status==='Conflict')metrics.fundingConflict++;
  }
 }
 function finish(){
  metrics.customers=consumerIds.size;metrics.cspMembers=cspIds.size;metrics.uniqueRelationships=payees.size;metrics.duplicateSurplus=metrics.payees-payees.size;metrics.multiAccountCustomers=[...customers.values()].filter(c=>c.isMember&&c.accounts>1).length;
  let groupNumber=0;for(const group of duplicateIdentity.values()){if(group.size>1){groupNumber++;for(const key of group){const p=payees.get(key);p.possibleDuplicate=true;p.duplicateGroup+=(p.duplicateGroup?', ':'')+'D'+groupNumber;}}}duplicateIdentity.clear();
  metrics.possibleDuplicateGroups=groupNumber;metrics.duplicatePayees=0;
  for(const p of payees.values()){delete p._account;const c=customers.get(p.customerKey);c.uniquePayees++;if(p.possibleDuplicate){c.duplicatePayees++;metrics.duplicatePayees++;}}
  metrics.consumerCustomers=metrics.customers;metrics.customers=[...customers.values()].filter(c=>c.isMember).length;metrics.unlinkedCustomerGroups=[...customers.values()].filter(c=>!c.isMember).length;metrics.memberRows=[...customers.values()].reduce((n,c)=>n+c.memberRows,0);metrics.memberMissingCif=[...customers.values()].filter(c=>c.isMember&&!c.cifs.length).length;
  metrics.unlinkedAccountRows=accounts.filter(a=>!customers.get(a.customerKey)?.isMember).length;metrics.unlinkedPayeeRows=[...payees.values()].filter(p=>!customers.get(p.customerKey)?.isMember).reduce((n,p)=>n+p.rows,0);
  const resultMetrics={...metrics};for(const k of ['singleMinor','instanceMinor','historyMinor','unclassifiedMinor'])resultMetrics[k]=String(metrics[k]);if(!seen.has('payee'))resultMetrics.unmatchedRelationships=null;
  const customerRows=[],unlinkedCustomers=[];for(const c of customers.values()){c.historyMinor=String(c.historyMinor);(c.isMember?customerRows:unlinkedCustomers).push(c);}
  const payeeRows=[];for(const p of payees.values()){p.historyMinor=String(p.historyMinor);p.scheduledMinor=String(p.scheduledMinor);p.customer=customers.get(p.customerKey)?.name||'';payeeRows.push(p);}
  for(const a of accounts)a.customer=customers.get(a.customerKey)?.name||a.customer;
  consumerIds.clear();cspIds.clear();
  return {asOf,blankModels,metrics:resultMetrics,files,issues,issueCount,warningCount,customers:customerRows,unlinkedCustomers,customerLinks,payees:payeeRows,accounts,historyDates,recurringDiagnostics:[...recurringDiagnostics.values()],missing:catalog.layouts.filter(l=>!seen.has(l.id)).map(l=>l.title),partial:metrics.unlinkedCustomerGroups>0||issueCount>0||metrics.unclassified>0||seen.size<catalog.layouts.length,_identity:identity,_accountNumbers:accountNumbers,_customers:customers,_payees:payees,_funding:funding,_rules:rules};
 }
 return {begin,line,finish,get records(){return files.reduce((n,f)=>n+f.rows+f.rejected,0);}};
}
export function orderInputs(inputs){const rank={member:0,consumer:1,payee:2,single_payments:3,recurring_payments:4,payment_history:5,payee_nickname:6};return [...inputs].sort((a,b)=>(rank[a.layout??identify(a.name)]??9)-(rank[b.layout??identify(b.name)]??9));}
export function analyze(inputs,catalog,asOf,blankModels=false){const engine=createAnalyzer(catalog,asOf,blankModels);for(const input of orderInputs(inputs)){if(!engine.begin(input))continue;const lines=input.text.split(/\r?\n/);if(lines.at(-1)==='')lines.pop();for(const line of lines)engine.line(line);}return engine.finish();}
