import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {startServer} from '../server/index.mjs';
test('loopback server serves only compiled assets and health',async t=>{
 const s=await startServer(0);t.after(()=>new Promise(resolve=>s.close(resolve)));
 const base='http://127.0.0.1:'+s.address().port;
 const health=await fetch(base+'/api/health');assert.equal(health.status,200);assert.equal((await health.json()).storage,'browser-memory');
 const index=await fetch(base);assert.equal(index.status,200);assert.match(await index.text(),/Billpay/);assert.equal(index.headers.get('x-content-type-options'),'nosniff');assert.match(index.headers.get('content-security-policy'),/frame-ancestors 'none'/);
 assert.equal((await fetch(base+'/api/health',{method:'POST',body:'test'})).status,405);
 assert.equal((await fetch(base+'/src/App.tsx')).status,404);
 assert.equal((await fetch(base+'/%2e%2e%5cpackage.json')).status,403);
 const denied=await new Promise((resolve,reject)=>{http.get(base,{headers:{Host:'evil.example'}},r=>{r.resume();resolve(r.statusCode);}).on('error',reject);});
 assert.equal(denied,403);
});
