import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {analyze} from '../src/core/analysis.mjs';
import {parseRecord,prepareLayout} from '../src/core/record.mjs';
import {pageEntities,pagePayments,publicResult} from '../src/core/explore.mjs';
const catalog=JSON.parse(fs.readFileSync(new URL('../src/layouts.json',import.meta.url)));
const row=(id,values)=>catalog.layouts.find(l=>l.id===id).fields.map(f=>String(values[f.name]??'').padEnd(f.length)).join('');
const base={'Sponsor ID':'S','Sponsor Id':'S','Sponsor Member ID':'0001','Sponsor member id':'0001','Sponsor Member id':'0001','Member ID':'00001','First Name':'TEST','Last Name':'PERSON','Last Name/Business Name':'PERSON','Payee Relationship Number':'0001','Payee Name':'TEST UTILITY','Payee Nickname':'LIGHTS','Payee Account Number':'00009876','FI Account Number':'00001234','FI R&T':'000000001','FI Account Reference Number':'0007','FI Account Type':'DDA','Primary Account Indicator':'Y','Payment Amount':'12345','Payment Schedule Date':'20261003','Payment Date':'20260901','Payment Status':'1','Payment Frequency':'000004','Recurring / Single Payment Identifier':'','FIS Recurring Rule DB':'000009'};
const make=(id,values=base)=>({name:id+'.TXT',layout:id,text:row(id,values)+'\r\n'});
const inputs=[make('consumer'),make('payee'),make('recurring_payments'),make('member')];
test('blank model and padded numeric frequency retain original evidence',()=>{const p=parseRecord(row('recurring_payments',base),prepareLayout(catalog.layouts.find(l=>l.id==='recurring_payments')),true);assert.equal(p.kind,'model');assert.equal(p.record.frequencyLabel,'Monthly');assert.equal(p.record['Payment Frequency'],'000004');});
test('instance carrying model frequency is counted and warned, never discarded',()=>{const r=analyze([make('recurring_payments',{...base,'Recurring / Single Payment Identifier':'1'})],catalog,'20261002',true);assert.equal(r.issueCount,0);assert.equal(r.metrics.instances,1);assert.equal(r.metrics.instanceMinor,'12345');assert.ok(r.warningCount>0);});
test('unconfirmed blank model stays visible outside payment totals',()=>{const r=analyze(inputs,catalog,'20261002',false);assert.equal(r.metrics.unclassified,1);assert.equal(r.metrics.models,0);assert.equal(r.metrics.instances,0);assert.equal(r.issueCount,0);assert.equal(r.partial,true);});
test('payee name search, customer scoping and account row lookup',()=>{const r=analyze(inputs,catalog,'20261002',true);assert.equal(pageEntities(r,{entity:'Payees',query:'utility'}).total,1);assert.equal(pageEntities(r,{entity:'Payees',query:'LIGHTS'}).total,1);assert.equal(pageEntities(r,{entity:'Funding accounts',customerKey:r.customers[0].key}).total,1);assert.equal(r.accounts[0].primary,'Y');assert.match(r.accounts[0].account,/1234$/);});
test('payment drilldown links candidate payee, funding and model only with exact account',async()=>{
 const input=[...inputs,make('single_payments',{...base,'Payment Frequency':'','Payment ID':'00002'})];
 input[2]={...input[2],text:input[2].text+row('recurring_payments',{...base,'Recurring / Single Payment Identifier':'1'})+'\n'+row('recurring_payments',{...base,'Recurring / Single Payment Identifier':'1','FI Account Number':'99991234'})+'\n'};
 const result=analyze(input,catalog,'20261002',true),files=input.map(i=>({layout:i.layout,file:new File([i.text],i.name)}));
 const list=await pagePayments(files,catalog,result,{filter:'instance'});assert.equal(list.total,2);assert.equal(list.rows[0].modelCandidate.count,1);assert.equal(list.rows[1].modelCandidate.count,0);assert.equal(list.rows[0].funding.status,'Candidate match');assert.equal(list.rows[1].funding.status,'Conflict');assert.equal(list.rows[0].source.line,2);
 const searched=await pagePayments(files,catalog,result,{query:'utility',filter:'single'});assert.equal(searched.total,1);assert.equal(searched.amount,'12345');
 const exported=JSON.stringify(publicResult(result));assert.ok(!exported.includes('00001234'));assert.ok(!exported.includes('_funding'));assert.ok(!exported.includes('_rules'));
});
test('duplicate funding reference and payee key remain ambiguous',async()=>{
 const input=[make('consumer'),make('payee'),make('single_payments'),make('member')];input[0].text+=input[0].text;input[1].text+=input[1].text;
 const result=analyze(input,catalog,'20261002',true),files=input.map(i=>({layout:i.layout,file:new File([i.text],i.name)}));
 const list=await pagePayments(files,catalog,result,{});assert.equal(list.rows[0].funding.status,'Ambiguous');assert.match(list.rows[0].payeeMapping,/Ambiguous/);assert.equal(result.metrics.duplicateSurplus,1);
});

test('CIF preserves zeros, supports customer and payment search without changing join keys',async()=>{
 const input=[...inputs.filter(i=>i.layout!=='member'),make('member',{...base,'Secure login ID':'0000CIF7'}),make('single_payments')];
 const result=analyze(input,catalog,'20261002',true);
 assert.equal(pageEntities(result,{entity:'Customers',query:'0000cif7'}).total,1);
 assert.equal(pageEntities(result,{entity:'Customers',query:'00001'}).total,1);
 assert.deepEqual(result.customers[0].cifs,['0000CIF7']);
 assert.equal(result.customers[0].cifSources[0].source.line,1);
 const files=input.map(i=>({layout:i.layout,file:new File([i.text],i.name)}));
 assert.equal((await pagePayments(files,catalog,result,{query:'0000cif7',filter:'single'})).total,1);
 assert.ok(!JSON.stringify(publicResult(result)).includes('_customers'));
});
test('conflicting CIF values retained; reused CIF does not merge customers',()=>{
 const member=make('member',{...base,'Secure login ID':'0007'});
 member.text+=row('member',{...base,'Secure login ID':'0008'})+'\n'+row('member',{...base,'Sponsor Member ID':'0002','Member ID':'00002','Secure login ID':'0007'})+'\n';
 const result=analyze([member],catalog,'20261002',true);
 assert.equal(result.metrics.customers,2);assert.equal(pageEntities(result,{entity:'Customers',query:'0007'}).total,2);
 assert.deepEqual(result.customers[0].cifs,['0007','0008']);assert.ok(result.warningCount>0);
});
test('duplicate candidates use full account and customer scope, not masked last four or name alone',()=>{
 const payee=make('payee');
 for(const v of [
  {'Payee Relationship Number':'0002','Payee Name':'test   utility'},
  {'Payee Relationship Number':'0003','Payee Account Number':'11119876'},
  {'Payee Relationship Number':'0004','Sponsor Member id':'0002'},
  {'Payee Relationship Number':'0005','Payee Account Number':''}
 ])payee.text+=row('payee',{...base,...v})+'\n';
 const result=analyze([payee],catalog,'20261002',true);
 assert.equal(result.metrics.possibleDuplicateGroups,1);assert.equal(result.metrics.duplicatePayees,2);
 const first=result.unlinkedCustomers.find(c=>c.id==='0001');assert.equal(first.uniquePayees,4);assert.equal(first.duplicatePayees,2);
 assert.equal(pageEntities(result,{entity:'Payees',filter:'duplicates',customerKey:first.key}).total,2);
 assert.equal(pageEntities(result,{entity:'Payees',filter:'duplicates',customerKey:result.unlinkedCustomers.find(c=>c.id==='0002').key}).total,0);
 assert.ok(!JSON.stringify(publicResult(result)).includes('11119876'));
});
test('models-only delivery has inspectable instructions and zero actual instances',async()=>{
 const result=analyze(inputs,catalog,'20261002',true),files=inputs.map(i=>({layout:i.layout,file:new File([i.text],i.name)})),key=result.customers[0].key;
 const models=await pagePayments(files,catalog,result,{customerKey:key,payeeKey:result.payees[0].key,filter:'model'});
 assert.equal(models.total,1);assert.equal(models.amount,'0');assert.equal(models.rows[0].frequencyLabel,'Monthly');
 assert.equal((await pagePayments(files,catalog,result,{customerKey:key,filter:'instance'})).total,0);
 assert.equal(result.issueCount,0);assert.equal(result.customers[0].models,1);assert.equal(result.customers[0].future,0);
});
test('customer/payee history and future filters cannot escape their scope',async()=>{
 const payment=make('single_payments');payment.text+=row('single_payments',{...base,'Sponsor Member ID':'0002'})+'\n';payment.text+=row('single_payments',{...base,'Payee Relationship Number':'0002'})+'\n';
 const input=[...inputs,payment,make('payment_history')],result=analyze(input,catalog,'20261002',true),files=input.map(i=>({layout:i.layout,file:new File([i.text],i.name)}));
 const scope={customerKey:result.customers.find(c=>c.id==='0001').key,payeeKey:result.payees[0].key};
 assert.equal((await pagePayments(files,catalog,result,{...scope,filter:'future'})).total,1);
 assert.equal((await pagePayments(files,catalog,result,{...scope,filter:'history'})).total,1);
 assert.equal(result.payees[0].future,1);
});


test('funding type inventory retains unknown and blank codes, with scoped totals before filters',()=>{
 const input=make('consumer');
 for(const v of [{'FI Account Type':'SV'},{'FI Account Type':'MM'},{'FI Account Type':''},{'Sponsor member id':'0002','FI Account Type':'SV'}])input.text+=row('consumer',{...base,...v})+'\n';
 const result=analyze([input],catalog,'20261002',true);assert.equal(result.metrics.accounts,5);assert.equal(result.issueCount,0);assert.equal(result.warningCount,2);
 const key=result.unlinkedCustomers.find(c=>c.id==='0001').key;
 const list=pageEntities(result,{entity:'Funding accounts',customerKey:key,accountType:'MM'});
 assert.equal(list.total,1);assert.equal(list.rows[0].type,'MM');assert.equal(list.accountTypes.reduce((n,t)=>n+t.count,0),4);
 assert.equal(pageEntities(result,{entity:'Funding accounts',customerKey:key,accountType:''}).total,1);
 assert.equal(pageEntities(result,{entity:'Funding accounts',accountType:'SV'}).total,2);
});
test('account search uses original full number and combines with type, customer and text search',()=>{
 const input=make('consumer');input.text+=row('consumer',{...base,'FI Account Number':'99991234','FI Account Type':'SV'})+'\n';input.text+=row('consumer',{...base,'Sponsor member id':'0002','FI Account Number':'00001234'})+'\n';
 const result=analyze([input],catalog,'20261002',true),customerKey=result.unlinkedCustomers.find(c=>c.id==='0001').key;
 const exact=pageEntities(result,{entity:'Funding accounts',customerKey,accountQuery:'00001234'});assert.equal(exact.total,1);assert.equal(exact.rows[0].account,'••••1234');
 assert.equal(pageEntities(result,{entity:'Funding accounts',customerKey,accountQuery:'1234'}).total,2);
 assert.equal(pageEntities(result,{entity:'Funding accounts',customerKey,accountQuery:'00001234',accountType:'SV'}).total,0);
 assert.equal(pageEntities(result,{entity:'Funding accounts',customerKey,accountQuery:'9999',accountType:'SV',query:'PERSON'}).total,1);
 assert.equal(pageEntities(result,{entity:'Funding accounts',customerKey,accountQuery:'000012340'}).total,0);
 const exported=JSON.stringify(publicResult(result));assert.ok(!exported.includes('00001234'));assert.ok(!exported.includes('99991234'));assert.ok(!exported.includes('_accountNumbers'));
 assert.ok(!JSON.stringify(exact).includes('00001234'));
});

test('regression: 133 Member customers plus 151 Consumer accounts never become 266 customers',async()=>{
 const members=[],consumers=[],payees=[],history=[];
 for(let n=1;n<=133;n++){
  const member=String(n).padStart(22,'0'),masterId='M'+String(n).padStart(19,'0'),engineId='C'+String(n).padStart(19,'0'),cif='00'+String(9007199254740993n+BigInt(n));
  members.push(row('member',{...base,'Member ID':member,'Sponsor Member ID':masterId,'Secure login ID':cif}));
  const v={...base,'Member ID':member,'Sponsor member id':engineId,'Sponsor Member id':engineId,'Sponsor Member ID':engineId};
  consumers.push(row('consumer',v));if(n<=18)consumers.push(row('consumer',{...v,'Primary Account Indicator':'N','FI Account Reference Number':'0008','FI Account Number':'00005678'}));
  payees.push(row('payee',v));history.push(row('payment_history',v));
 }
 const input=[['consumer',consumers],['member',members],['payee',payees],['payment_history',history]].map(([layout,lines])=>({layout,name:layout+'.TXT',text:lines.join('\r\n')+'\r\n'}));
 const r=analyze(input,catalog,'20261002',true);assert.equal(r.metrics.customers,133);assert.equal(r.customers.length,133);assert.equal(r.metrics.accounts,151);assert.equal(r.metrics.unlinkedCustomerGroups,0);assert.equal(r.metrics.memberMissingCif,0);
 assert.equal(r.customers[0].accounts,2);assert.equal(r.customers[0].history,1);assert.equal(r.customers[0].uniquePayees,1);
 const cif='009007199254740994';assert.equal(r.customers[0].cifs[0],cif);assert.equal(pageEntities(r,{entity:'Customers',query:cif}).total,1);
 const files=input.map(i=>({layout:i.layout,file:new File([i.text],i.name)}));const payments=await pagePayments(files,catalog,r,{customerKey:r.customers[0].key,filter:'history'});assert.equal(payments.total,1);assert.equal(payments.rows[0].cifs[0],cif);assert.equal(payments.rows[0].funding.status,'Candidate match');
});
test('missing Member file cannot promote Consumer or payment rows to customers',()=>{
 const r=analyze([make('consumer'),make('payee'),make('single_payments')],catalog,'20261002',true);
 assert.equal(r.metrics.customers,0);assert.equal(pageEntities(r,{entity:'Customers'}).total,0);assert.equal(r.metrics.accounts,1);assert.equal(r.metrics.single,1);assert.ok(pageEntities(r,{entity:'Customers',filter:'unlinked'}).total>0);assert.equal(r.partial,true);
});
test('same name or different sponsor never joins a missing Member ID',()=>{
 const r=analyze([make('member'),make('consumer',{...base,'Member ID':'00002'}),make('payee',{...base,'Sponsor Id':'OTHER'})],catalog,'20261002',true);
 assert.equal(r.metrics.customers,1);assert.equal(r.customers[0].accounts,0);assert.equal(r.customers[0].uniquePayees,0);assert.equal(r.metrics.unlinkedCustomerGroups,2);assert.equal(r.customerLinks.consumer.unlinked,1);
});
test('ambiguous sponsor-member alias never assigns payment or CIF to either member',async()=>{
 const member=make('member',{...base,'Secure login ID':'001'});member.text+=row('member',{...base,'Member ID':'00002','Secure login ID':'002'})+'\n';
 const input=[member,make('single_payments')],r=analyze(input,catalog,'20261002',true);assert.equal(r.metrics.customers,2);assert.ok(r.customers.every(c=>c.single===0));
 const list=await pagePayments(input.map(i=>({layout:i.layout,file:new File([i.text],i.name)})),catalog,r,{});assert.deepEqual(list.rows[0].cifs,[]);assert.match(list.rows[0].customerMapping,/ambiguous/);
});
test('repeated Member master rows remain one customer, preserving source row counts',()=>{
 const input=make('member',{...base,'Secure login ID':'000000000000001'});input.text+=input.text;const r=analyze([input],catalog,'20261002',true);assert.equal(r.metrics.customers,1);assert.equal(r.metrics.memberRows,2);assert.equal(r.customers[0].memberSources.length,2);assert.deepEqual(r.customers[0].cifs,['000000000000001']);
});
