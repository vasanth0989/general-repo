import test from 'node:test';
import assert from 'node:assert/strict';
import {inspectBytes,validateSelection,MAX_FILE_BYTES} from '../src/core/inventory.mjs';
const stream=(text,chunk=3)=>{const bytes=new TextEncoder().encode(text);let i=0;return new ReadableStream({pull(c){if(i>=bytes.length)return c.close();c.enqueue(bytes.slice(i,i+=chunk));}});};
test('CRLF split across chunks excludes delimiter, keeps leading zeros',async()=>{const r=await inspectBytes(stream('0001\r\n0002\r\n',1),4);assert.equal(r.lines,2);assert.equal(r.matched,2);assert.equal(r.crlf,2);assert.equal(r.bytes,12);});
test('LF and final unterminated line counted once',async()=>{const r=await inspectBytes(stream('abcd\nefgh'),4);assert.equal(r.lines,2);assert.equal(r.matched,2);assert.equal(r.lf,1);});
test('empty input is zero lines, not a valid record',async()=>{const r=await inspectBytes(stream(''),4);assert.equal(r.lines,0);assert.equal(r.minWidth,0);});
test('blank lines and wrong widths remain visible',async()=>{const r=await inspectBytes(stream('\nabc\nabcde\n'),4);assert.equal(r.empty,1);assert.equal(r.mismatched,3);assert.deepEqual(r.examples,[{line:1,byteWidth:0},{line:2,byteWidth:3},{line:3,byteWidth:5}]);});
test('UTF8 and control bytes are flagged without decoding guesses',async()=>{const r=await inspectBytes(stream('é\u0000\n'),3);assert.equal(r.nonAscii,2);assert.equal(r.suspiciousControl,1);});
test('isolated CR is not silently treated as a line delimiter',async()=>{const r=await inspectBytes(stream('a\rb\r'),4);assert.equal(r.lines,1);assert.equal(r.suspiciousControl,2);});
test('bounded difference samples for large error sets',async()=>{const r=await inspectBytes(stream('x\n'.repeat(200)),4);assert.equal(r.mismatched,200);assert.equal(r.examples.length,5);});
test('progress reports consumed bytes',async()=>{const counts=[];const r=await inspectBytes(stream('abcd\n'),4,n=>counts.push(n));assert.equal(counts.at(-1),r.bytes);});
test('invalid width rejected',async()=>{await assert.rejects(inspectBytes(stream('a'),0));});
test('selection limits reject empty oversized and huge batches',()=>{assert.throws(()=>validateSelection([]));assert.throws(()=>validateSelection([{size:MAX_FILE_BYTES+1}]));assert.throws(()=>validateSelection(Array(301).fill({size:1})));validateSelection([{size:0},{size:400}]);});

