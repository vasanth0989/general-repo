import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {analyzeFiles,lineFramer,CHUNK_BYTES} from '../src/core/stream.mjs';
import {analyze} from '../src/core/analysis.mjs';
const catalog=JSON.parse(fs.readFileSync(new URL('../src/layouts.json',import.meta.url)));
test('line framing handles one-byte chunks, CRLF, blank, final line and BOM',()=>{
 const lines=[],f=lineFramer(l=>lines.push(l));for(const b of Buffer.from('abc\r\n\nxyz'))f.push(Uint8Array.of(b));f.finish();assert.deepEqual(lines,['abc','','xyz']);
 const bom=[],g=lineFramer(l=>bom.push(l));g.push(Uint8Array.of(239,187,191,65,10));g.finish();assert.equal(bom[0],'\ufeffA');
});
test('huge malformed line is discarded with bounded carry and later lines survive',()=>{
 const lines=[],f=lineFramer(l=>lines.push(l));for(let n=0;n<80;n++)f.push(new Uint8Array(CHUNK_BYTES).fill(65));f.push(Buffer.from('\nvalid\n'));f.finish();assert.deepEqual(lines,['','valid']);
});
test('cancel prevents more reads and duplicate delivery fails before opening files',async()=>{
 const abort=new AbortController();let reads=0;
 const file={name:'X_History_Test.TXT',size:CHUNK_BYTES*4,slice(){reads++;return {arrayBuffer:async()=>{abort.abort();return new ArrayBuffer(CHUNK_BYTES);}};}};
 await assert.rejects(analyzeFiles([{file}],catalog,'20261002',true,()=>{},abort.signal),{name:'AbortError'});assert.equal(reads,1);
 reads=0;await assert.rejects(analyzeFiles([{file},{file}],catalog,'20261002'),/More than one/);assert.equal(reads,0);
});
test('skipped and Ebills files are never opened',async()=>{
 const file=name=>({name,size:9e9,slice(){throw Error('Must not read');}});
 const r=await analyzeFiles([{file:file('X_Ebills_Live.TXT')},{file:file('X_Consumer_Live.TXT'),layout:''}],catalog,'20261002');assert.equal(r.performance.bytes,0);
});
