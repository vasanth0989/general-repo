export type IconName='grid'|'users'|'building'|'arrows'|'shield'|'folder'|'history'|'book'|'chevron'|'search'|'download'|'plus'|'close'|'arrow'|'check'|'clock'|'help'|'lock'|'file'|'alert'|'spark'|'dots'|'menu'|'refresh'|'external';
const paths:Record<IconName,string>={
grid:'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',
users:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M16 3a4 4 0 0 1 0 8 M22 21v-2a4 4 0 0 0-3-3.87 M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
building:'M3 21h18 M5 21V7l7-4 7 4v14 M9 9v1 M15 9v1 M9 13v1 M15 13v1 M10 21v-4h4v4',
arrows:'M4 7h16m-4-4 4 4-4 4 M20 17H4m4-4-4 4 4 4',
shield:'M12 3 3 7v5c0 5 9 9 9 9s9-4 9-9V7z M8 12l3 3 5-6',
folder:'M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
history:'M3 11a9 9 0 1 1 2 7 M3 4v7h7 M12 7v5l3 2',
book:'M12 5C8 2 3 3 3 3v16s5-1 9 2c4-3 9-2 9-2V3s-5-1-9 2z M12 5v16',
chevron:'m9 5 7 7-7 7',search:'M21 21l-5-5 M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',
download:'M12 3v12 m-5-5 5 5 5-5 M3 16v5h18v-5',plus:'M12 5v14 M5 12h14',
close:'m6 6 12 12 M6 18 18 6',arrow:'M4 12h16 m-6-6 6 6-6 6',check:'m5 12 4 4L19 6',
clock:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0 M12 7v5l3 2',
help:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0 M9 9a3 3 0 0 1 6 0c0 2-3 2-3 4 M12 16v1',
lock:'M5 10h14v11H5z M8 10V6a4 4 0 0 1 8 0v4',file:'M14 2H4v20h16V8z M14 2v6h6 M8 13h8 M8 17h5',
alert:'m12 3 10 18H2z M12 9v5 M12 17v1',spark:'m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z',
dots:'M5 12h.01 M12 12h.01 M19 12h.01',menu:'M3 6h18 M3 12h18 M3 18h18',
refresh:'M20 7V3l-3 3A8 8 0 1 0 3 13 M20 3v6h-6',external:'M14 3h7v7 M21 3 10 14 M10 3H3v18h18v-7'};
export default function Icon({name,size=19}:{name:IconName;size?:number}){return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]}/></svg>;}

