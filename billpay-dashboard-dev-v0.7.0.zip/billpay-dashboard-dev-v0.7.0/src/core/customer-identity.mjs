import {customerKey} from './record.mjs';
const sponsor=r=>r['Sponsor Id']||r['Sponsor ID'];
const memberKey=r=>JSON.stringify(['member',sponsor(r),r['Member ID']]);
const sourceKey=r=>JSON.stringify([sponsor(r),r['Sponsor Member ID']||r['Sponsor Member id']||r['Sponsor member id']]);
export const createIdentity=()=>({members:new Map(),aliases:new Map()});
// Exact, sponsor-scoped source identifiers only. Never convert identifiers to numbers.
export function identifyCustomer(r,index,{master=false,register=false}={}){
 const raw=sourceKey(r),member=r['Member ID'],key=memberKey(r);
 if(master){index.members.set(key,key);const keys=index.aliases.get(raw)||new Set();keys.add(key);index.aliases.set(raw,keys);r._customerKey=key;r._customerMapping='Member master';return;}
 const direct=member?index.members.get(key):null,aliases=index.aliases.get(raw)||new Set();
 if(register&&direct){aliases.add(direct);index.aliases.set(raw,aliases);}
 const conflict=aliases.size>1||(direct&&aliases.size===1&&!aliases.has(direct));
 if(conflict){r._customerMapping='Conflicting or ambiguous customer identifiers';}
 else if(direct){r._customerKey=direct;r._customerMapping='Exact sponsor + Member ID';return;}
 else if(!member&&aliases.size===1){r._customerKey=[...aliases][0];r._customerMapping='Unique sponsor + Sponsor Member ID alias';return;}
 else r._customerMapping=member?'Member ID not found in Member file':'Sponsor Member ID not linked to Member file';
 r._customerKey=JSON.stringify(['unlinked',raw,member||'']);
}
