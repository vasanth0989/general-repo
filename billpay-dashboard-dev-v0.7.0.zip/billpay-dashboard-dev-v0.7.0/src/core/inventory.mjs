// Structural checks only. Candidate byte widths are not approved vendor rules.
export const MAX_FILE_BYTES = 2 * 1024 ** 3;
export const MAX_BATCH_BYTES = 10 * 1024 ** 3;
export const MAX_FILES = 300;
export function validateSelection(files) {
  if (!files.length) throw new Error('Choose at least one file.');
  if (files.length > MAX_FILES) throw new Error('Choose up to 300 files per run.');
  if (files.some(f => f.size > MAX_FILE_BYTES)) throw new Error('A file exceeds the prototype limit of 2 GiB.');
  if (files.reduce((n,f) => n + f.size, 0) > MAX_BATCH_BYTES) throw new Error('The folder exceeds the prototype limit of 10 GiB.');
}
/** @param {ReadableStream<Uint8Array>} stream @param {number} candidateWidth @param {(bytes: number) => void} onProgress */
export async function inspectBytes(stream, candidateWidth, onProgress = (_bytes) => {}) {
  if (!Number.isInteger(candidateWidth) || candidateWidth < 1) throw new Error('A positive candidate width is required.');
  const reader = stream.getReader();
  let bytes=0, lines=0, width=0, matched=0, empty=0, nonAscii=0, last=-1, min=Infinity, max=0, lf=0, crlf=0, suspiciousControl=0;
  const examples=[];
  const endLine=(hasLf) => {
    const cr=hasLf && last===13, n=width-(cr ? 1 : 0);
    lines++;
    if(hasLf) { if(cr) crlf++; else lf++; }
    if(n===candidateWidth) matched++;
    else if(examples.length<5) examples.push({line:lines,byteWidth:n});
    if(!n) empty++;
    min=Math.min(min,n); max=Math.max(max,n); width=0; last=-1;
  };
  try {
    while(true) {
      const {value,done}=await reader.read(); if(done) break;
      for(const b of value) {
        if(b===10) endLine(true);
        else {
          if(b>127) nonAscii++;
          if(b<32 && b!==13) suspiciousControl++;
          if(last===13) suspiciousControl++;
          width++; last=b;
        }
      }
      bytes+=value.length; onProgress(bytes);
    }
    if(width) { if(last===13) suspiciousControl++; endLine(false); }
  } finally { reader.releaseLock(); }
  return {bytes,lines,matched,mismatched:lines-matched,empty,nonAscii,suspiciousControl,minWidth:lines?min:0,maxWidth:max,lf,crlf,examples};
}
