import {createAnalyzer,orderInputs,identify} from './analysis.mjs';
export const CHUNK_BYTES=1024*1024;
/** Byte-based line framing. Even a corrupt multi-GB line retains at most 1 KiB. */
export function lineFramer(onLine){
 const pending=new Uint8Array(1024),decoder=new TextDecoder('utf-8',{ignoreBOM:true});let used=0,overflow=false;
 const emit=(newline)=>{let n=used;if(newline&&n&&pending[n-1]===13)n--;onLine(overflow?'':decoder.decode(pending.subarray(0,n)));used=0;overflow=false;};
 return {push(bytes){let start=0;for(let i=0;i<bytes.length;i++){if(bytes[i]!==10)continue;append(bytes.subarray(start,i));emit(true);start=i+1;}append(bytes.subarray(start));},finish(){if(used||overflow)emit(false);}};
 function append(bytes){if(!bytes.length)return;if(used+bytes.length>pending.length)overflow=true;const n=Math.min(bytes.length,pending.length-used);pending.set(bytes.subarray(0,n),used);used+=n;}
}
export async function analyzeFiles(inputs,catalog,asOf,blankModels=false,onProgress=(_progress)=>{},signal){
 const ordered=orderInputs(inputs.map(i=>({...i,name:i.file.name}))),engine=createAnalyzer(catalog,asOf,blankModels);
 // Validate mappings before reading any bytes.
 const seen=new Set();for(const i of ordered){const id=identify(i.name)==='excluded'?'excluded':i.layout??identify(i.name);if(!id||id==='excluded')continue;if(seen.has(id))throw Error('More than one file is assigned to '+id+'. Select one delivery at a time.');seen.add(id);}
 const total=ordered.reduce((n,i)=>{const id=identify(i.name)==='excluded'?'excluded':i.layout??identify(i.name);return n+(id&&id!=='excluded'?i.file.size:0);},0);
 let bytes=0,last=0;const started=performance.now();
 for(const input of ordered){
  if(!engine.begin(input))continue;
  const framer=lineFramer(line=>engine.line(line));
  for(let offset=0;offset<input.file.size;offset+=CHUNK_BYTES){
   signal?.throwIfAborted();const chunk=new Uint8Array(await input.file.slice(offset,offset+CHUNK_BYTES).arrayBuffer());signal?.throwIfAborted();framer.push(chunk);bytes+=chunk.length;
   const now=performance.now();if(now-last>=200){onProgress({bytes,total,records:engine.records,name:input.name,seconds:(now-started)/1000});last=now;}
  }
  framer.finish();
 }
 signal?.throwIfAborted();onProgress({bytes,total,records:engine.records,name:'Finalizing',seconds:(performance.now()-started)/1000});
 const result=engine.finish();result.performance={bytes,records:engine.records,seconds:(performance.now()-started)/1000};return result;
}
