# Validation — 0.7.0

2026-10-02, Windows, Node 26.5.0.

- 33 tests passed, TypeScript check and Vite 8.3.1 build passed.
- Regression: 133 Member customers, 151 Consumer account rows, 133 Payee relationships and History rows, with different Member/Consumer Sponsor Member IDs. Result: 133 customers, not 266; CIF preserved and searchable; account/payee/history drilldowns linked.
- Numeric CIF 009007199254740994 preserved exactly, including leading zeros and digits beyond JavaScript's safe integer range.
- Tests cover missing Member file, differing sponsors, unmatched Member IDs, ambiguous sponsor-member aliases, repeated Member rows, CIF conflicts, funding search/masking, recurrence and streaming.
- Browser confirmed 133 customers, 151 accounts, numeric CIF search and source reconciliation 133 Member / 151 Consumer / 133 Payee / 133 History linked, zero rejected/unlinked in that synthetic fixture.
- Browser found and verified a fix for a pre-existing crash navigating from customer rows to Data quality: non-explorer pages no longer try to render customer rows as payment rows.
- 700,000-row benchmark: 3.360 seconds, observed process RSS 863.69 MiB; history scan 0.480 seconds. Correct totals and last-customer query passed. Mac performance not verified.
- No actual delivery available. Counting defect confirmed in code; the exact identifier mismatch in the user's delivery remains unconfirmed. New reconciliation diagnostics support that investigation.
- Native npm lockfile audit performed before packaging. No dependency additions. Test datasets/screenshots and node_modules excluded from ZIP.
