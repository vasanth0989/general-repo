import http from 'node:http';
import {createReadStream} from 'node:fs';
import {realpath,stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
export async function startServer(port=Number(process.env.PORT||4173)) {
  if(!Number.isInteger(port)||port<0||port>65535) throw new Error('Invalid port.');
  const root=await realpath(fileURLToPath(new URL('../dist/',import.meta.url)));
  const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json'};
  const server=http.createServer(async(req,res)=>{
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Cache-Control','no-store');
    const allowedHosts=['127.0.0.1:'+server.address().port,'localhost:'+server.address().port];
    if(!allowedHosts.includes(req.headers.host)){res.writeHead(403);return res.end('Forbidden');}
    if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,{Allow:'GET, HEAD'});return res.end();}
    try {
      const url=new URL(req.url,'http://127.0.0.1');
      if(url.pathname==='/api/health'){res.setHeader('Content-Type','application/json');return res.end(req.method==='HEAD'?'':JSON.stringify({status:'ok',version:'0.8.1',mode:'local-analysis',storage:'browser-memory',platform:process.platform}));}
      const name=decodeURIComponent(url.pathname),candidate=path.resolve(root,'.'+(name==='/'?'/index.html':name));
      if(!candidate.startsWith(root+path.sep)){res.writeHead(403);return res.end('Forbidden');}
      const resolved=await realpath(candidate);
      if(!resolved.startsWith(root+path.sep)||!(await stat(resolved)).isFile()){res.writeHead(404);return res.end('Not found');}
      res.setHeader('Content-Type',types[path.extname(resolved)]||'application/octet-stream');
      if(req.method==='HEAD')return res.end();
      createReadStream(resolved).on('error',()=>res.destroy()).pipe(res);
    }catch{res.writeHead(404);res.end('Not found');}
  });
  server.requestTimeout=15000;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
  return server;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  startServer().then(s=>console.log('\n  Billpay is ready → http://127.0.0.1:'+s.address().port+'\n  Local analysis · Press Ctrl+C to stop\n'))
    .catch(e=>{console.error(e.code==='EADDRINUSE'?'Port is in use. Close the other server or set PORT.':'Cannot start. Run npm run build first.');process.exitCode=1;});
}
