# Validation — 0.8.1

2026-10-02, Windows, Node 26.5.0.

- All 42 tests pass; TypeScript and Vite 8.3.1 build pass. Native npm lockfile audit reports zero vulnerabilities. Dependencies unchanged.
- Five additional regression tests verify sponsor-padding account/payee attachment and payment/history/model drilldowns, payment rescans, ambiguous master collision rejection, preservation of customer ID zeros and different sponsors, and conflicting identifier isolation.
- Existing tests cover 133-customer multi-account datasets, CIF precision, streaming, recurrence classification and full account display.
- Diagnostic screenshots IMG_9929–IMG_9935 show 151 Consumer and 341 Payee rows fail exact sponsor comparisons but each matches one master with Sponsor ID padding reconciled. No missing keys or width/encoding errors. This is user-run diagnostic evidence, not direct access to raw production files.
- Production rerun of 0.8.1 remains pending. No new Mac performance benchmark. Previous v0.7 700,000-row performance evidence remains historical.
- Package excludes node_modules, datasets, screenshots and local diagnostic reports.
